"""Conservative CDS reconstruction primitives. No network or file side effects."""
from dataclasses import dataclass


class Unresolved(ValueError):
    pass


@dataclass(frozen=True)
class Segment:
    start: int
    end: int
    phase: int
    sequence: str


@dataclass(frozen=True)
class Edit:
    pos: int
    ref: str
    alt: str
    gt: str


def reverse_complement(sequence):
    if any(b not in 'ACGT' for b in sequence):
        raise Unresolved('non-ACGT reference')
    return sequence.translate(str.maketrans('ACGT','TGCA'))[::-1]


def reference_cds(segments,strand):
    if strand not in ('+','-') or not segments:
        raise Unresolved('strand or segments missing')
    ordered=sorted(segments,key=lambda s:s.start)
    if any(s.start<1 or s.end<s.start or len(s.sequence)!=s.end-s.start+1 for s in ordered):
        raise Unresolved('segment length mismatch')
    if any(a.end>=b.start for a,b in zip(ordered,ordered[1:])):
        raise Unresolved('overlapping CDS segments')
    oriented=ordered if strand=='+' else ordered[::-1]
    pieces=[];length=0
    for s in oriented:
        # GFF phase marks bases completing the previous codon, not bases to discard.
        if s.phase!=(3-length%3)%3:
            raise Unresolved('partial CDS or phase inconsistency')
        reverse_complement(s.sequence)  # validate bases also on plus strand
        pieces.append(s.sequence if strand=='+' else reverse_complement(s.sequence))
        length+=len(s.sequence)
    cds=''.join(pieces)
    if len(cds)%3:raise Unresolved('partial terminal codon')
    return cds


def translate(sequence):
    if len(sequence)%3:raise Unresolved('partial terminal codon')
    alphabet='TCAG'
    amino='FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG'
    code={a+b+c:aa for (a,b,c),aa in zip(((a,b,c) for a in alphabet for b in alphabet for c in alphabet),amino)}
    try:return ''.join(code[sequence[i:i+3]] for i in range(0,len(sequence),3))
    except KeyError as error:raise Unresolved('ambiguous coding base') from error


def apply_homozygous_edits(segments,strand,edits):
    reference_cds(segments,strand)
    edits=sorted(edits,key=lambda e:e.pos)
    if any(a.pos+len(a.ref)>b.pos for a,b in zip(edits,edits[1:])):
        raise Unresolved('overlapping edits')
    grouped={s:[] for s in segments}
    for e in edits:
        if e.gt not in ('1/1','1|1'):raise Unresolved('missing or ambiguous diploid phase')
        if not e.ref or not e.alt or any(c not in 'ACGT' for c in e.ref+e.alt):
            raise Unresolved('unsupported allele')
        owners=[s for s in segments if s.start<e.pos and e.pos+len(e.ref)-1<s.end]
        # Deliberately conservative: terminal CDS bases/anchors need splice-aware handling.
        if len(owners)!=1:raise Unresolved('CDS boundary or noncoding edit needs review')
        s=owners[0];offset=e.pos-s.start
        if s.sequence[offset:offset+len(e.ref)]!=e.ref:raise Unresolved('REF mismatch')
        grouped[s].append(e)
    pieces=[]
    for s in sorted(segments,key=lambda x:x.start):
        sequence=s.sequence
        for e in reversed(grouped[s]):
            offset=e.pos-s.start
            sequence=sequence[:offset]+e.alt+sequence[offset+len(e.ref):]
        pieces.append(sequence)
    combined=''.join(pieces)
    return combined if strand=='+' else reverse_complement(combined)
