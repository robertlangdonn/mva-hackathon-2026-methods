"""Local-only Track 1 CSV preflight; never uploads or reads an answer key."""
import argparse
from collections import Counter
import csv
import json
import math
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
FIELDS = ['proband_id', 'chrom_1', 'pos_1', 'ref_1', 'alt_1',
          'chrom_2', 'pos_2', 'ref_2', 'alt_2', 'epcr', 'finding_type', 'notes']
CHROMS = {'chr' + c for c in [*[str(i) for i in range(1, 23)], 'X', 'Y']}


def validate(handle, expected_proband='PROBAND01'):
    errors, warnings = [], []
    def issue(destination, row, code):
        destination.append({'row': row, 'code': code})
    reader = csv.DictReader(handle, strict=True)
    if reader.fieldnames != FIELDS:
        return {'valid': False, 'rows': 0, 'errors': [{'row': 1, 'code': 'template_header_mismatch'}],
                'warnings': []}
    seen, allele_seen, epcrs = set(), set(), []
    counts = Counter()
    n = 0
    try:
        for n, row in enumerate(reader, 1):
            line = n + 1
            if None in row or any(v is None for v in row.values()):
                issue(errors, line, 'column_count'); continue
            if any(v != v.strip() for v in row.values()):
                issue(errors, line, 'surrounding_whitespace')
            if row['proband_id'] != expected_proband:
                issue(errors, line, 'unexpected_proband')
            counts[row['proband_id']] += 1
            variants = []
            for suffix in ('1', '2'):
                values = [row[f'{f}_{suffix}'] for f in ('chrom', 'pos', 'ref', 'alt')]
                if suffix == '2' and not any(values):
                    continue
                if not all(values):
                    issue(errors, line, 'incomplete_variant_' + suffix); continue
                chrom, pos, ref, alt = values
                if chrom not in CHROMS:
                    issue(errors, line, 'chromosome_spelling_' + suffix)
                if not re.fullmatch(r'[1-9][0-9]*', pos):
                    issue(errors, line, 'positive_integer_position_' + suffix); continue
                if not re.fullmatch('[ACGTN]+', ref) or not re.fullmatch('[ACGTN]+', alt):
                    issue(errors, line, 'unsupported_allele_representation_' + suffix)
                if ref == alt:
                    issue(errors, line, 'identical_ref_alt_' + suffix)
                variants.append((chrom, int(pos), ref, alt))
            if len(variants) == 2:
                if variants[0] == variants[1]:
                    issue(errors, line, 'pair_repeats_same_allele')
                if variants[0][0] != variants[1][0]:
                    issue(errors, line, 'pair_crosses_chromosomes')
                elif variants[0][1] == variants[1][1]:
                    issue(warnings, line, 'same_locus_pair_requires_review')
            identity = (row['proband_id'], tuple(sorted(variants)))
            if variants and identity in seen:
                issue(errors, line, 'duplicate_proposal_including_reversed_pair')
            seen.add(identity)
            if any(v in allele_seen for v in variants):
                issue(warnings, line, 'allele_reused_across_proposals')
            allele_seen.update(variants)
            try:
                epcr = float(row['epcr'])
                if not math.isfinite(epcr) or not 0 < epcr <= 1:
                    raise ValueError
                epcrs.append(epcr)
            except ValueError:
                issue(errors, line, 'epcr_outside_finite_0_to_1')
            if row['finding_type'] not in ('primary', 'secondary'):
                issue(errors, line, 'finding_type')
            elif row['finding_type'] == 'secondary':
                issue(warnings, line, 'secondary_scoring_ambiguity_unresolved')
            if row['notes'].startswith(('=', '+', '-', '@')):
                issue(warnings, line, 'spreadsheet_formula_prefix_in_notes')
    except csv.Error:
        issue(errors, n + 2, 'malformed_csv')
    if not n:
        issue(errors, 1, 'empty_submission')
    if any(count > 10 for count in counts.values()):
        issue(errors, 0, 'more_than_10_rows')
    if epcrs != sorted(epcrs, reverse=True):
        issue(warnings, 0, 'not_presorted_by_epcr')
    if len(epcrs) != len(set(epcrs)):
        issue(warnings, 0, 'epcr_ties_use_input_order')
    return {'valid': not errors, 'rows': n, 'errors': errors, 'warnings': warnings,
            'unverified': ['GRCh38_REF_and_normalization', 'clinical_evidence_and_phase',
                           'EPCR_calibration', 'report_repository_and_disclosures',
                           'live_rules_and_remaining_quota']}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--csv', required=True, type=Path)
    args = parser.parse_args()
    source = args.csv.resolve(strict=True)
    if not source.is_relative_to((ROOT / 'data/intermediate').resolve()):
        raise SystemExit('Submission CSV must stay in controlled intermediate storage')
    with source.open(newline='', encoding='utf-8-sig') as handle:
        result = validate(handle)
    print(json.dumps(result, sort_keys=True))  # Diagnostic codes only, never allele values.
    raise SystemExit(0 if result['valid'] else 1)
