import unittest
from scripts.population_evidence import source_evidence, combined_evidence


class PopulationEvidenceTests(unittest.TestCase):
    def test_absent_missing_and_not_queried_are_distinct(self):
        states = [source_evidence(False), source_evidence(True),
                  source_evidence(True, {'af_grpmax': '.'})]
        self.assertEqual(len({s['status'] for s in states}), 3)
        for state in states:
            evidence = combined_evidence(state, source_evidence(True))
            self.assertEqual(evidence['interpretation'], 'requires_review')
            self.assertEqual(evidence['observed_frequency_band'], 'no_observed_frequency')

    def test_common_genome_is_not_hidden_by_rare_exome(self):
        exome = source_evidence(True, {'af_grpmax': '0.00001', 'filter': 'PASS', 'an': '1000'})
        genome = source_evidence(True, {'af_grpmax': '0.02', 'filter': 'PASS', 'an': '2000'})
        self.assertEqual(combined_evidence(exome, genome)['observed_frequency_band'], 'common_ge_0.01')

    def test_low_af_does_not_hide_other_source_unknown(self):
        exome = source_evidence(True, {'af_grpmax': '0.00001', 'filter': 'PASS', 'an': '1000'})
        self.assertEqual(combined_evidence(exome, source_evidence(False))['interpretation'], 'requires_review')

    def test_bad_filter_or_an_remains_visible(self):
        row = source_evidence(True, {'af_grpmax': '0', 'filter': 'AS_VQSR', 'an': '.'})
        result = combined_evidence(row, row)
        self.assertEqual(len(result['limitations']), 4)

    def test_invalid_af_rejected(self):
        for value in ('nan', 'inf', '-0.1', '1.1', '0.1,0.2'):
            with self.assertRaises(ValueError):
                source_evidence(True, {'af_grpmax': value})


if __name__ == '__main__':
    unittest.main()
