"""Synthetic representation/observability gates, NOT a patient allele assessor."""
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


class IndelOracleTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='mva-synthetic-indels-')
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        for tool in ('samtools', 'bcftools'):
            if not shutil.which(tool):
                self.fail(f'{tool} required; validation cannot silently skip')

    def run_tool(self, *args, check=True):
        return subprocess.run(list(map(str, args)), capture_output=True,
                              text=True, timeout=15, check=check)

    def reference(self, sequence):
        ref = self.root/'ref.fa'
        ref.write_text('>synthetic\n'+sequence+'\n')
        self.run_tool('samtools', 'faidx', ref)
        return ref

    def normalize(self, sequence, variants, check=True):
        ref = self.reference(sequence)
        vcf = self.root/'input.vcf'
        vcf.write_text('##fileformat=VCFv4.2\n'
            f'##contig=<ID=synthetic,length={len(sequence)}>\n'
            '#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\n'+
            ''.join(f'synthetic\t{p}\tv{i}\t{r}\t{a}\t.\tPASS\t.\n'
                    for i, (p,r,a) in enumerate(variants)))
        result = self.run_tool('bcftools', 'norm', '-f', ref, '-c', 'e',
                              '--old-rec-tag', 'ORIGINAL', '-Ov', vcf, check=check)
        if not check:
            return result
        rows = [line.split('\t') for line in result.stdout.splitlines()
                if not line.startswith('#')]
        # Assert each representation has the same full synthetic haplotype,
        # not merely the same normalized text or a shared variant label.
        def edited(pos, ref, alt):
            self.assertEqual(sequence[pos-1:pos-1+len(ref)], ref)
            return sequence[:pos-1]+alt+sequence[pos-1+len(ref):]
        self.assertEqual(len(rows), len(variants))
        for fields in rows:
            original = variants[int(fields[2][1:])]
            self.assertEqual(edited(*original), edited(int(fields[1]), fields[3], fields[4]))
        return rows

    def test_homopolymer_insertions_equivalent(self):
        rows = self.normalize('CCGAAAAATCGG', [(4,'A','AA'), (7,'A','AA')])
        self.assertEqual([(r[1],r[3],r[4]) for r in rows], [('3','G','GA')]*2)
        self.assertTrue(all('ORIGINAL=' in r[7] for r in rows))

    def test_homopolymer_deletions_equivalent(self):
        rows = self.normalize('CCGAAAAATCGG', [(4,'AA','A'), (7,'AA','A')])
        self.assertEqual([(r[1],r[3],r[4]) for r in rows], [('3','GA','G')]*2)

    def test_tandem_repeat_insertions_equivalent(self):
        rows = self.normalize('CCGATATATCGG', [(5,'T','TAT'), (7,'T','TAT')])
        self.assertEqual([(r[1],r[3],r[4]) for r in rows], [('3','G','GAT')]*2)

    def test_substitution_and_complex_replacement_preserve_haplotype(self):
        rows = self.normalize('ACGTCAGTACGATCGT', [(5,'CA','TT'), (5,'CA','TTT')])
        self.assertEqual([(r[1],r[3],r[4]) for r in rows],
                         [('5','CA','TT'), ('5','CA','TTT')])

    def test_reference_mismatch_stops(self):
        result = self.normalize('ACGTCAGTACGATCGT', [(5,'GA','G')], check=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('Reference allele mismatch', result.stderr)

    def pileup(self, cigar, seq, *, flag=0, qual=None):
        reference = 'ACGTCAGTACGATCGT'
        ref = self.reference(reference)
        sam = self.root/'read.sam'
        sam.write_text('@HD\tVN:1.6\tSO:coordinate\n@SQ\tSN:synthetic\tLN:16\n'
            f'invented\t{flag}\tsynthetic\t1\t60\t{cigar}\t*\t0\t0\t{seq}\t'
            + (qual if qual is not None else 'I'*len(seq))+'\n')
        bam = self.root/'read.bam'
        self.run_tool('samtools', 'view', '-b', '-o', bam, sam)
        out = self.run_tool('samtools', 'mpileup', '-f', ref, '-B', '-A', '-x',
            '-q','20','-Q','20','--ff','3844','-d','1000','--no-output-ends',bam).stdout
        return {int(f[1]): (int(f[3]), f[4]) for f in
                (line.split('\t') for line in out.splitlines())}

    def test_insertion_anchor_sequence_and_reverse_orientation(self):
        for flag, expected in ((0,'.+2TT'), (16,',+2tt')):
            with self.subTest(flag=flag):
                p = self.pileup('5M2I11M', 'ACGTCTTAGTACGATCGT', flag=flag)
                self.assertEqual(p[5], (1,expected))
                self.assertEqual(p[6][0], 1)

    def test_deletion_is_event_plus_placeholders(self):
        p = self.pileup('5M2D9M', 'ACGTCTACGATCGT')
        self.assertEqual(p[5], (1,'.-2AG'))
        self.assertEqual(p[6], (1,'*'))
        self.assertEqual(p[7], (1,'*'))
        self.assertEqual(p[8], (1,'.'))

    def test_skip_is_not_deletion(self):
        p = self.pileup('5M2N9M', 'ACGTCTACGATCGT')
        self.assertEqual(p[5], (1,'.'))
        self.assertEqual(p[6], (1,'>'))

    def test_anchor_only_cannot_establish_reference_allele(self):
        p = self.pileup('5M', 'ACGTC')
        self.assertEqual(p[5], (1,'.'))
        self.assertNotIn(6, p)

    def test_softclip_is_not_insertion(self):
        p = self.pileup('5M2S', 'ACGTCTT')
        self.assertEqual(p[5], (1,'.'))
        self.assertNotIn(6, p)

    def test_low_quality_anchor_filters_event(self):
        p = self.pileup('5M2I11M', 'ACGTCTTAGTACGATCGT', qual='IIII!'+'I'*13)
        self.assertEqual(p[5][0], 0)

    def test_low_quality_inserted_bases_are_not_filtered_by_anchor_pileup(self):
        # Deliberate safety counterexample: pileup -Q is not a complete
        # inserted-sequence quality gate. A production assessor must inspect it.
        p = self.pileup('5M2I11M', 'ACGTCTTAGTACGATCGT', qual='IIIII!!'+'I'*11)
        self.assertEqual(p[5], (1,'.+2TT'))

    def test_low_quality_right_flank_does_not_hide_anchor_event(self):
        p = self.pileup('5M2D9M', 'ACGTCTACGATCGT', qual='IIIII!'+'I'*8)
        self.assertEqual(p[5], (1,'.-2AG'))
        self.assertEqual(p[8][0], 0)


if __name__ == '__main__':
    unittest.main()
