import csv
import io
import unittest
from scripts.validate_submission import FIELDS, validate


def row(**changes):
    r = dict.fromkeys(FIELDS, '')
    r.update(proband_id='SYNTHETIC', chrom_1='chr1', pos_1='10', ref_1='A', alt_1='G',
             epcr='.9', finding_type='primary')
    r.update(changes)
    return r


def check(rows):
    data = io.StringIO()
    writer = csv.DictWriter(data, fieldnames=FIELDS)
    writer.writeheader(); writer.writerows(rows)
    data.seek(0)
    return validate(data, expected_proband='SYNTHETIC')


class SubmissionTests(unittest.TestCase):
    def test_single_and_pair(self):
        self.assertTrue(check([row()])['valid'])
        self.assertTrue(check([row(chrom_2='chr1', pos_2='20', ref_2='C', alt_2='T')])['valid'])

    def test_bad_probands_and_positions(self):
        for changes in ({'proband_id': 'OTHER'}, {'pos_1': '0'}, {'pos_1': '1.5'},
                        {'pos_1': '-2'}, {'chrom_1': '1'}, {'ref_1': ''}, {'alt_1': 'A'}):
            self.assertFalse(check([row(**changes)])['valid'])

    def test_epcr_edge_cases(self):
        for value in ('0', '-1', '1.1', 'nan', 'inf', ''):
            self.assertFalse(check([row(epcr=value)])['valid'])
        self.assertTrue(check([row(epcr='1')])['valid'])

    def test_partial_second_and_identical_pair(self):
        self.assertFalse(check([row(chrom_2='chr1')])['valid'])
        self.assertFalse(check([row(chrom_2='chr1', pos_2='10', ref_2='A', alt_2='G')])['valid'])

    def test_reversed_pair_duplicate(self):
        a = row(chrom_2='chr1', pos_2='20', ref_2='C', alt_2='T')
        b = row(pos_1='20', ref_1='C', alt_1='T', chrom_2='chr1', pos_2='10', ref_2='A', alt_2='G')
        self.assertFalse(check([a, b])['valid'])

    def test_limits_and_empty(self):
        self.assertFalse(check([])['valid'])
        self.assertTrue(check([row(pos_1=str(i+1)) for i in range(10)])['valid'])
        self.assertFalse(check([row(pos_1=str(i+1)) for i in range(11)])['valid'])

    def test_secondary_order_and_ties_warn(self):
        result = check([row(epcr='.2'), row(pos_1='20', epcr='.9', finding_type='secondary'),
                        row(pos_1='30', epcr='.9')])
        self.assertTrue(result['valid'])
        self.assertEqual({r['code'] for r in result['warnings']},
                         {'not_presorted_by_epcr', 'epcr_ties_use_input_order', 'secondary_scoring_ambiguity_unresolved'})

    def test_header_and_extra_columns(self):
        self.assertFalse(validate(io.StringIO('proband_id,epcr\nX,.9\n'))['valid'])
        text = ','.join(FIELDS) + '\n' + ','.join(row().values()) + ',extra\n'
        self.assertFalse(validate(io.StringIO(text))['valid'])

    def test_diagnostics_do_not_echo_values(self):
        result = check([row(pos_1='PRIVATE_VALUE')])
        self.assertNotIn('PRIVATE_VALUE', str(result))
