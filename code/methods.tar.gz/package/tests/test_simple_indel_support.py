import unittest
from scripts.simple_indel_support import prepare, assess, summarize
from tests import test_synthetic_indel_oracles as oracle_fixtures

REFERENCE = 'ACGTCAGTACGATCGT'


def record(cigar='16M', seq=REFERENCE, qual=None, flag=0, name='invented', mq=60):
    return [name,str(flag),'synthetic','1',str(mq),cigar,'*','0','0',seq,
            qual if qual is not None else 'I'*len(seq)]


class SimpleIndelTests(unittest.TestCase):
    def target(self, deletion=False):
        target, reason = prepare('synthetic',5,'CAG' if deletion else 'C',
                                 'C' if deletion else 'CTT',REFERENCE)
        self.assertEqual(reason,'READY')
        return target

    def insertion(self, **kwargs):
        return record('5M2I11M','ACGTCTTAGTACGATCGT',**kwargs)

    def deletion(self, **kwargs):
        return record('5M2D9M','ACGTCTACGATCGT',**kwargs)

    def test_ref_and_alt_for_both_types(self):
        for deletion, fields in ((False,self.insertion()),(True,self.deletion())):
            t = self.target(deletion)
            self.assertEqual(assess(fields,t),'ALT')
            self.assertEqual(assess(record(),t),'REF')

    def test_reverse_strand_not_complemented_twice(self):
        self.assertEqual(assess(self.insertion(flag=16),self.target()),'ALT')

    def test_inserted_base_quality_checked(self):
        self.assertEqual(assess(self.insertion(qual='IIIII!!'+'I'*11),self.target()),
                         'UNINFORMATIVE_QUALITY')

    def test_every_required_base_quality_checked(self):
        for deletion, fields in ((False,self.insertion()),(True,self.deletion())):
            t = self.target(deletion)
            # Entire emitted local haplotype: 5 left bases, event if inserted,
            # and five right bases. Test each independently, including anchor.
            for i in range(len(t.alternate)):
                with self.subTest(deletion=deletion,index=i):
                    f = fields.copy(); q = list(f[10]); q[i]='4'; f[10]=''.join(q)
                    self.assertEqual(assess(f,t),'UNINFORMATIVE_QUALITY')

    def test_quality_boundary(self):
        f=self.insertion(qual='5'*18)
        self.assertEqual(assess(f,self.target()),'ALT')

    def test_anchor_only_and_clipped_are_uninformative(self):
        for f in (record('5M','ACGTC'),record('5M2S','ACGTCTT')):
            self.assertEqual(assess(f,self.target()),'UNINFORMATIVE_SPAN')

    def test_clipping_outside_complete_span_allowed(self):
        f=record('2S5M2I11M','NNACGTCTTAGTACGATCGT')
        self.assertEqual(assess(f,self.target()),'ALT')

    def test_skip_not_deletion(self):
        self.assertEqual(assess(record('5M2N9M','ACGTCTACGATCGT'),self.target(True)),
                         'UNINFORMATIVE_SPAN')

    def test_adjacent_change_and_wrong_insert_unresolved(self):
        for seq in ('ACGTCTTATTACGATCGT','ACGTCCCAGTACGATCGT'):
            self.assertEqual(assess(record('5M2I11M',seq),self.target()),
                             'AMBIGUOUS_LOCAL_EVENT')

    def test_extra_boundary_insertion_unresolved(self):
        self.assertEqual(assess(record('10M1I6M',REFERENCE[:10]+'A'+REFERENCE[10:]),
                                self.target()),'AMBIGUOUS_LOCAL_EVENT')

    def test_low_quality_boundary_mate_cannot_override_alt(self):
        alt=self.insertion()
        bad=record('10M1I6M',REFERENCE[:10]+'A'+REFERENCE[10:],qual='!'*17)
        self.assertEqual(assess(bad,self.target()),'UNINFORMATIVE_QUALITY')
        r=summarize(['\t'.join(f)+'\n' for f in (alt,bad)],self.target())
        self.assertEqual(r['fragment_name_counts'],{'ALT':1})

    def test_boundary_insert_sequence_quality_itself_is_checked(self):
        for cigar,seq,offset in (('1I16M','T'+REFERENCE,0),
                                 ('10M1I6M',REFERENCE[:10]+'A'+REFERENCE[10:],10)):
            q=list('I'*len(seq));q[offset]='!'
            self.assertEqual(assess(record(cigar,seq,qual=''.join(q)),self.target()),
                             'UNINFORMATIVE_QUALITY')

    def test_compensating_events_not_reference_support(self):
        self.assertEqual(assess(record('5M1D1I10M'),self.target()),
                         'AMBIGUOUS_LOCAL_EVENT')

    def test_filtering(self):
        for flag in (4,256,512,1024,2048):
            self.assertEqual(assess(self.insertion(flag=flag),self.target()),'UNINFORMATIVE_FILTER')
        for mq in (19,255):
            self.assertEqual(assess(self.insertion(mq=mq),self.target()),'UNINFORMATIVE_FILTER')
        self.assertEqual(assess(self.insertion(mq=20),self.target()),'ALT')

    def test_missing_quality(self):
        self.assertEqual(assess(self.insertion(qual='*'),self.target()),'UNINFORMATIVE_QUALITY')

    def test_invalid_cigar_and_reference_fail(self):
        with self.assertRaises(ValueError):
            assess(record('15M'),self.target())
        with self.assertRaises(ValueError):
            prepare('synthetic',5,'GA','G',REFERENCE)

    def test_repeats_and_complex_are_explicitly_unassessed(self):
        for pos,ref,alt in ((6,'A','AA'),(6,'AA','A')):
            self.assertEqual(prepare('s',pos,ref,alt,'CCCGAAAAATCGGCCC')[1],
                             'REPEAT_SHIFT_AMBIGUITY')
        for ref,alt in (('CA','TT'),('CA','TTT'),('C','<INS>')):
            self.assertEqual(prepare('s',5,ref,alt,REFERENCE)[1],'UNSUPPORTED_ALLELE')

    def test_right_shift_only_repeat_rejected(self):
        self.assertEqual(prepare('s',5,'C','CA',REFERENCE)[1],'REPEAT_SHIFT_AMBIGUITY')

    def test_context_and_size_caps(self):
        self.assertEqual(prepare('s',1,'A','ATT',REFERENCE)[1],'INSUFFICIENT_FLANK_CONTEXT')
        self.assertEqual(prepare('s',5,'C','C'+'T'*51,REFERENCE)[1],'UNSUPPORTED_ALLELE')
        with self.assertRaises(ValueError):
            prepare('s',5,'C','CTT','A'*10001)

    def test_context_offset(self):
        target, reason=prepare('synthetic',105,'C','CTT',REFERENCE,101)
        self.assertEqual(reason,'READY')
        f=self.insertion();f[3]='101'
        self.assertEqual(assess(f,target),'ALT')

    def test_indel_mates_and_ambiguity(self):
        alt=self.insertion();ref=record();low=self.insertion(qual='!'*18)
        ambiguous=record('5M2I11M','ACGTCCCAGTACGATCGT')
        cases=[([alt,alt],{'ALT':1}),([alt,ref],{'CONFLICT':1}),
               ([alt,low],{'ALT':1}),([alt,ambiguous],{'AMBIGUOUS':1}),
               ([alt,self.insertion(name='other')],{'ALT':2})]
        for rows, expected in cases:
            result=summarize(['\t'.join(f)+'\n' for f in rows],self.target())
            self.assertEqual(result['fragment_name_counts'],expected)

    def test_independent_pileup_events_and_quality_counterexamples(self):
        # Reuse only fixture IO, not the assessor's CIGAR/projection code.
        oracle=oracle_fixtures.IndelOracleTests();oracle.setUp();self.addCleanup(oracle.doCleanups)
        for deletion,fields,event in ((False,self.insertion(),'.+2TT'),
                                      (True,self.deletion(),'.-2AG')):
            p=oracle.pileup(fields[5],fields[9])
            self.assertEqual(p[5],(1,event))
            self.assertEqual(assess(fields,self.target(deletion)),'ALT')
        low=self.insertion(qual='IIIII!!'+'I'*11)
        p=oracle.pileup(low[5],low[9],qual=low[10])
        self.assertEqual(p[5],(1,'.+2TT'))
        self.assertEqual(assess(low,self.target()),'UNINFORMATIVE_QUALITY')
        low=self.deletion(qual='IIIII!'+'I'*8)
        p=oracle.pileup(low[5],low[9],qual=low[10])
        self.assertEqual(p[5],(1,'.-2AG'))
        self.assertEqual(assess(low,self.target(True)),'UNINFORMATIVE_QUALITY')


if __name__ == '__main__':
    unittest.main()
