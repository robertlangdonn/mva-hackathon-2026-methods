import unittest
from scripts.cds_reconstruction import Segment,Edit,Unresolved,reference_cds,translate,apply_homozygous_edits,reverse_complement


class CDSTests(unittest.TestCase):
    def test_translation(self):
        self.assertEqual(translate('ATGAAATAA'),'MK*')

    def test_split_codon_phase(self):
        self.assertEqual(reference_cds([Segment(1,4,0,'ATGA'),Segment(10,14,2,'AATAA')],'+'),'ATGAAATAA')

    def test_negative_strand(self):
        self.assertEqual(reference_cds([Segment(1,5,2,'TTATT'),Segment(10,13,0,'TCAT')],'-'),'ATGAAATAA')

    def test_phase_rejected(self):
        with self.assertRaises(Unresolved):reference_cds([Segment(1,9,1,'ATGAAATAA')],'+')

    def test_compensated_indels(self):
        s=[Segment(1,12,0,'ATGAAACCCTAA')]
        edits=[Edit(4,'A','AT','1/1'),Edit(7,'CC','C','1/1')]
        combined=apply_homozygous_edits(s,'+',edits)
        self.assertEqual(combined,'ATGATAACCTAA')
        self.assertEqual(translate(combined),'MIT*')
        self.assertNotEqual(combined,s[0].sequence)

    def test_negative_edit(self):
        s=[Segment(1,12,0,'TTAGGGTTTCAT')]
        result=apply_homozygous_edits(s,'-',[Edit(5,'G','A','1/1')])
        self.assertEqual(result,reverse_complement('TTAGAGTTTCAT'))

    def test_stop_survives_length_restoration(self):
        sequence=apply_homozygous_edits([Segment(1,12,0,'ATGAAACCCTAA')],'+',
            [Edit(3,'G','GT','1/1'),Edit(7,'CC','C','1/1')])
        self.assertEqual(sequence,'ATGTAAACCTAA')
        self.assertEqual(len(sequence)%3,0)
        self.assertIn('*',translate(sequence)[:-1])

    def test_ref_overlap_boundary_and_phase_rejected(self):
        s=[Segment(1,12,0,'ATGAAACCCTAA')]
        for edits in ([Edit(4,'G','T','1/1')], [Edit(1,'A','AT','1/1')],
                      [Edit(4,'AA','A','1/1'),Edit(5,'A','T','1/1')],
                      [Edit(4,'A','T','0/1')],[Edit(4,'A','T','./.')],
                      [Edit(12,'A','T','1/1')]):
            with self.subTest(edits=edits),self.assertRaises(Unresolved):apply_homozygous_edits(s,'+',edits)

    def test_spanning_intron_rejected(self):
        s=[Segment(1,3,0,'ATG'),Segment(10,15,0,'AAATAA')]
        with self.assertRaises(Unresolved):apply_homozygous_edits(s,'+',[Edit(2,'TGAAAAAAA','T','1/1')])

    def test_incomplete_and_ambiguous_translation(self):
        for sequence in ('ATGA','ATN'):
            with self.assertRaises(Unresolved):translate(sequence)
