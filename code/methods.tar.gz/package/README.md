# Portable synthetic methods bundle — LOCAL REVIEW ONLY

Four unchanged implementation modules cover simple-indel read assessment,
population-evidence semantics, conservative CDS reconstruction and CSV structure.
Five test modules use invented data. No controlled inputs, results, reference
sequences, binaries, credentials or workflow runners are bundled.

Requirements: Python 3.10+, samtools and bcftools on PATH. No Python packages
outside the standard library. See environment.json for versions actually tested;
this is not a complete environment lock or cross-platform certification.

From the extracted directory: python3 verify_and_test.py

The verifier checks each allowlisted artifact hash, rejects unlisted files,
then runs only the synthetic tests in isolated Python mode. Tests create small
temporary invented FASTA/SAM/VCF files. They do not download or align patient reads.

This is NOT an end-to-end VCF-to-ranking reproduction. It excludes normalization,
annotation acquisition, population joins, ranking orchestration, full alignment,
patient-specific review runners and submission outputs. Passing tests is not
clinical validation, phase evidence, or server acceptance. CSV semantics require
a current official-rule check before use; the CLI's controlled-path guard remains.

Source bytes match the production modules' reviewed hashes. No portability edits
were made to frozen production sources. License/ownership/third-party attribution
review and permission to publish remain pending. This file grants no license.
The local archive must not be represented as an approved public release.
