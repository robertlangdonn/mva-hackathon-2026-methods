# Private synthetic replay package

Run: python3 -I -B verify_and_test.py
Requirements: Python >=3.11, POSIX (fcntl), bcftools and samtools on PATH.
environment.json records tested versions, not a complete binary/environment lock.
No network, acquisition controller or alignment is invoked by this test command.
Import isolation is not an OS filesystem/network sandbox.

The verifier checks the exact allowlisted files and hashes before running nine
tests. One test invents 24 tiny contigs and 48 variants; it exercises real
normalization, local-mode consequence generation, join CLI/intersection oracles,
phenotype CLI, explicit-contract export preparation CLI and ranking CLI.
The fixture also normalizes/indexes an invented ClinVar-style VCF and uses real
bcftools annotate to transfer five INFO fields by allele. Tests verify unchanged
keys/consequences/genotypes, absent/wrong-ALT nonmatches, retained conflicting
assertions and condition/review fields. Downstream stages consume that output.
This is not a reconstruction of historical ClinVar preprocessing or general
validation of multiallelic clinical records, assertion semantics or disease cause.
The same fixture now starts with both original intake CLIs and passes their real
phenotype output to scoring/preparation; source hashes are checked. Tool discovery
is deliberately disabled during intake. Minimal Word XML is invented, not a full
Word rendering test. The GRCh38 header is a toy label, not human sequence proof.
Temporary fixtures are removed afterward. No patient inputs/results are bundled.

Required/tested entry points:
- prepare_population.prepare: normalization function only, NOT its SSD-only CLI.
- bcftools norm/csq --local-csq/index/query/isec and samtools faidx.
- scripts.join_population CLI, called for all 24 contigs explicitly.
- scripts.phenotype_similarity CLI.
- generated scripts.export_prepare_ranking_inputs CLI (hash-pinned resources).
- scripts.run_ranking CLI, all-24 completeness gate.

Support modules are present because of imports, not permission to run their CLIs.
In particular download_population and population_runtime retain original host
defaults; do not execute their acquisition/control functions from this package.
The frozen prepare_ranking_inputs module supplies source to the export generator;
do not run its historical CLI. The historical remaining-run controller, paused
old alignment and corrected alignment are not included or restarted.

Not covered: acquisition/storage-controller portability, real clinical documents,
full ClinVar preprocessing, complex/negative-strand/haplotype consequences, full alignment,
patient-specific evidence review or final submission. The toy fixture uses the
ranking schema's GRCh38 label, NOT actual human reference sequences. Unresolved
frequency, phase and X/Y limitations must remain unresolved.

PRIVATE REVIEW ONLY. This is neither full-pipeline reproduction nor a public
release. Source/privacy/license review and user publication approval remain open.
No license is granted by this README. Hashes detect drift, not malicious rewriting
of the manifest; retain the externally recorded archive hash for identity.
