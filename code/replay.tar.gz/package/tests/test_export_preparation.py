import json
from pathlib import Path
import tempfile
import unittest
from scripts.export_preparation_resources import NAMES, digest, load_resources
from scripts.stage_preparation_adapter import render


class ExportPreparationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.controlled = self.root / 'controlled'; self.controlled.mkdir()
        self.inputs = {}
        for name in NAMES:
            p = self.controlled / name; p.write_text('invented')
            self.inputs[name] = p
        self.inputs['phenotype'].write_text(json.dumps({'source': {
            'name': 'phenotype_source', 'sha256': digest(self.inputs['phenotype_source'])}}))
        self.spec = dict(schema='mva-export-preparation-v1', controlled_root=str(self.controlled),
                         inputs={n:dict(path=str(p),sha256=digest(p)) for n,p in self.inputs.items()})
        self.contract = self.controlled / 'resources.json'
        self.output = self.controlled / 'output'

    def load(self):
        self.contract.write_text(json.dumps(self.spec))
        return load_resources(self.contract, self.output)

    def test_valid_contract_pins_contract_and_does_not_create_output(self):
        output, _, paths, pins = self.load()
        self.assertEqual(output, self.output)
        self.assertEqual(paths['resource_contract'], self.contract)
        self.assertEqual(pins['resource_contract']['sha256'], digest(self.contract))
        self.assertFalse(output.exists())

    def test_tampered_resource(self):
        self.inputs['ontology'].write_text('changed')
        with self.assertRaisesRegex(ValueError, 'hash mismatch'): self.load()
        self.assertFalse(self.output.exists())

    def test_missing_resource(self):
        del self.spec['inputs']['fai']
        with self.assertRaisesRegex(ValueError, 'exact resource'): self.load()

    def test_relative_resource(self):
        self.spec['inputs']['fai']['path'] = 'fai'
        with self.assertRaisesRegex(ValueError, 'absolute'): self.load()

    def test_symlink_escape(self):
        outside = self.root / 'outside'; outside.write_text('invented')
        self.inputs['fai'].unlink(); self.inputs['fai'].symlink_to(outside)
        with self.assertRaisesRegex(ValueError, 'controlled local'): self.load()

    def test_output_escape_and_existing(self):
        self.output = self.root / 'escape'
        with self.assertRaisesRegex(ValueError, 'output must remain'): self.load()
        self.output = self.controlled / 'exists'; self.output.mkdir()
        with self.assertRaisesRegex(ValueError, 'already exists'): self.load()

    def test_source_identity(self):
        self.inputs['phenotype'].write_text(json.dumps({'source': {'name':'other','sha256':'0'*64}}))
        self.spec['inputs']['phenotype']['sha256'] = digest(self.inputs['phenotype'])
        with self.assertRaisesRegex(ValueError, 'source integrity'): self.load()

    def test_export_computation_tail_unchanged(self):
        source = (Path(__file__).resolve().parents[1] / 'scripts/prepare_ranking_inputs.py').read_text()
        result = render(source)
        tail = source.split('    output.mkdir()\n', 1)[1].split("\n\nif __name__", 1)[0]
        self.assertIn('    output.mkdir()\n' + tail, result)
        self.assertIn("'--resources', required=True", result)
        with self.assertRaises(ValueError): render(source.replace('    output.mkdir()', '    output.mkdir(parents=True)'))
