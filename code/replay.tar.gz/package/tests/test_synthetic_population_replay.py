"""Invented 24-contig fixture with real consequence generation, joins and ranking."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile
from scripts.prepare_population import prepare
from scripts import run_ranking as runner
from scripts.ranking_adapter import CHROMS
from scripts.stage_preparation_adapter import render
from scripts.inventory_release_dependencies import closure


class SyntheticPopulationReplay(unittest.TestCase):
    def test_normalize_join_and_rank_all_24(self):
        for tool in ('bcftools','samtools'):
            self.assertIsNotNone(shutil.which(tool),'Required oracle must not silently skip')
        with tempfile.TemporaryDirectory(prefix='mva-invented-replay-') as temp:
            root=Path(temp); data=root/'data/intermediate';data.mkdir(parents=True)
            (root/'config').mkdir()
            original=Path(__file__).resolve().parents[1]
            policy=root/'config/ranking-policy-v1.json'
            shutil.copyfile(original/'config/ranking-policy-v1.json',policy)
            ref=data/'reference.fa';ref.write_text(''.join(f'>{c}\nATGCAAAAAAGTTTTTAA\n' for c in CHROMS))
            def cmd(*args):
                return subprocess.run(list(map(str,args)),check=True,capture_output=True,text=True,timeout=30).stdout
            cmd('samtools','faidx',ref)
            headers=['##fileformat=VCFv4.2']+[f'##contig=<ID=chr{c},length=18>' for c in CHROMS]
            for name,num,kind in [('AC','A','Integer'),('AN','1','Integer'),('AF','A','Float'),('AF_grpmax','A','Float'),('nhomalt','A','Integer'),('fafmax_faf95_max','A','Float')]:
                headers.append(f'##INFO=<ID={name},Number={num},Type={kind},Description="Invented">')
            headers.append('#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO')
            sites={}
            for source in ('exomes','genomes'):
                lines=[]
                for c in CHROMS:
                    for pos,r,a in [(7,'AA','A'),(11,'G','A,C'),(13,'T','C')]:
                        if source=='genomes' and c=='22' and pos==13:continue
                        n=len(a.split(','));values=lambda x:','.join([x]*n)
                        info=f'AC={values("1")};AN=10000;AF={values("0.0001")};AF_grpmax={values("0.0001")};nhomalt={values("0")};fafmax_faf95_max={values("0.0001")}'
                        lines.append(f'chr{c}\t{pos}\t.\t{r}\t{a}\t.\tPASS\t{info}')
                raw=data/f'{source}.vcf';raw.write_text('\n'.join(headers+lines)+'\n')
                sites[source]=data/f'{source}.bcf';prepare(raw,ref,sites[source])
            normalized=cmd('bcftools','query','-r','22','-f','%POS\t%REF\t%ALT\n',sites['exomes']).splitlines()
            self.assertEqual(normalized,['4\tCA\tC','11\tG\tA','11\tG\tC','13\tT\tC'])
            gff=data/'toy.gff3'
            gff.write_text('##gff-version 3\n'+''.join(
                f'{c}\tx\tgene\t1\t18\t.\t+\t.\tID=gene:g{c};Name=TOY{c};biotype=protein_coding\n'
                f'{c}\tx\tmRNA\t1\t18\t.\t+\t.\tID=transcript:tx{c};Parent=gene:g{c};transcript_id=tx{c};biotype=protein_coding;tag=MANE_Select\n'
                f'{c}\tx\texon\t1\t18\t.\t+\t.\tParent=transcript:tx{c}\n'
                f'{c}\tx\tCDS\t1\t18\t.\t+\t0\tParent=transcript:tx{c}\n' for c in CHROMS))
            h=['##fileformat=VCFv4.2','##reference=GRCh38']+[f'##contig=<ID={c},length=18>' for c in CHROMS]
            for name,num,kind in [('GT','1','String'),('DP','1','Integer'),('GQ','1','Integer'),('AD','R','Integer')]:
                h.append(f'##FORMAT=<ID={name},Number={num},Type={kind},Description="Invented">')
            h.append('#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tSYNTHETIC')
            rows=[f'{c}\t{pos}\t.\t{r}\t{a}\t.\tPASS\t.\tGT:DP:GQ:AD\t0/1:20:30:10,10' for c in CHROMS for pos,r,a in [(11,'G','A'),(13,'T','C')]]
            rawdir=root/'data/raw';rawdir.mkdir()
            raw=rawdir/'input.vcf';raw.write_text('\n'.join(h+rows)+'\n');bcf=data/'input.bcf'
            (root/'scripts').mkdir()
            for name in ('intake.py','phenotype_intake.py'):
                shutil.copyfile(original/'scripts'/name,root/'scripts'/name)
            document=rawdir/'invented.docx'
            def xmlrow(values):
                return '<w:tr>'+''.join('<w:tc><w:p><w:r><w:t>'+v+'</w:t></w:r></w:p></w:tc>' for v in values)+'</w:tr>'
            xml='<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:tbl>'
            xml+=xmlrow(['Clinical feature','HPO term','HPO ID','Presentation / notes'])
            xml+=xmlrow(['Invented','Invented A','HP:9000001','Synthetic only'])+'</w:tbl></w:body></w:document>'
            with zipfile.ZipFile(document,'w') as archive:archive.writestr('word/document.xml',xml)
            intake_env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME')};intake_env['PATH']=''
            phenotype=data/'phenotype.json'
            for name,args in [('intake.py',['--vcf',raw,'--phenotype',document]),
                              ('phenotype_intake.py',['--phenotype',document,'--output',phenotype])]:
                p=subprocess.run([sys.executable,'-B',str(root/'scripts'/name),*map(str,args)],
                    cwd=root,env=intake_env,capture_output=True,text=True,timeout=30)
                self.assertEqual(p.returncode,0,p.stderr)
            intake=json.loads((data/'intake_manifest.json').read_text())
            self.assertEqual(next(r['sha256'] for r in intake['files'] if r['role']=='source_vcf'),runner.sha(raw))
            self.assertEqual(json.loads(phenotype.read_text())['source']['sha256'],runner.sha(document))
            normalized_bcf=data/'normalized.bcf'
            cmd('bcftools','norm','-f',ref,'-c','e','-m','-any','-Ob','-o',normalized_bcf,raw)
            # Local consequences do not assume phase or validate combined haplotypes.
            cmd('bcftools','csq','--local-csq','-f',ref,'-g',gff,'-Ob','-o',bcf,normalized_bcf)
            cmd('bcftools','index',bcf)
            generated=cmd('bcftools','query','-f','%CHROM\t%POS\t%BCSQ[\t%GT]\n',bcf).splitlines()
            self.assertEqual(len(generated),48)
            for line in generated:
                c,pos,csq,gt=line.split('\t')
                # Explicit codon oracle: AGT -> AAT (S>N), TTT -> CTT (F>L).
                protein='4S>4N' if pos=='11' else '5F>5L'
                self.assertEqual(csq.split('|')[:6],['missense',f'TOY{c}',f'tx{c}','protein_coding','+',protein])
                self.assertEqual(gt,'0/1')
            # Invented ClinVar-style source: exact matches, conflicts, and a
            # same-position wrong ALT that must NOT transfer its assertion.
            clinical=data/'invented-clinical.vcf'
            fields=['ALLELEID','CLNSIG','CLNREVSTAT','CLNDN','CLNDISDB']
            clinical_headers=['##fileformat=VCFv4.2']+[f'##contig=<ID={c},length=18>' for c in CHROMS]
            clinical_headers += [f'##INFO=<ID={n},Number=.,Type=String,Description="Invented test only">' for n in fields]
            clinical_headers += ['#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO']
            clinical_rows=[]
            for c in CHROMS:
                if c=='Y':continue  # Truly absent source record.
                significance='Conflicting_classifications_of_pathogenicity' if c=='2' else 'Uncertain_significance'
                alt='C' if c=='1' else 'A'
                info=f'ALLELEID=9001;CLNSIG={significance};CLNREVSTAT=criteria_provided;CLNDN=Invented_condition;CLNDISDB=MedGen:TEST'
                clinical_rows.append(f'{c}\t11\t.\tG\t{alt}\t.\tPASS\t{info}')
            clinical.write_text('\n'.join(clinical_headers+clinical_rows)+'\n')
            clinical_bcf=data/'clinical.bcf'
            cmd('bcftools','norm','-f',ref,'-c','e','-m','-any','-Ob','-o',clinical_bcf,clinical)
            cmd('bcftools','index',clinical_bcf)
            before=cmd('bcftools','query','-f','%CHROM\t%POS\t%REF\t%ALT\t%BCSQ[\t%GT]\n',bcf)
            annotated=data/'annotated.bcf'
            cmd('bcftools','annotate','-a',clinical_bcf,'-c',','.join('INFO/'+n for n in fields),
                '-Ob','-o',annotated,bcf)
            cmd('bcftools','index',annotated)
            self.assertEqual(cmd('bcftools','query','-f','%CHROM\t%POS\t%REF\t%ALT\t%BCSQ[\t%GT]\n',annotated),before)
            assertions=cmd('bcftools','query','-f','%CHROM\t%POS\t%CLNSIG\t%CLNREVSTAT\t%CLNDN\t%CLNDISDB\n',annotated).splitlines()
            self.assertEqual(len(assertions),48)
            for line in assertions:
                c,pos,sig,review,condition,disease=line.split('\t')
                if pos=='13' or c in ('1','Y'):
                    self.assertEqual([sig,review,condition,disease],['.']*4)
                else:
                    self.assertEqual(sig,'Conflicting_classifications_of_pathogenicity' if c=='2' else 'Uncertain_significance')
                    self.assertEqual([review,condition,disease],['criteria_provided','Invented_condition','MedGen:TEST'])
            bcf=annotated  # Downstream joins/ranking consume the real annotation output.
            pin=lambda p:dict(path=str(p),sha256=runner.sha(p))
            # Resolve ROOT from the relocated module itself, without monkeypatches.
            for item in closure(original,('join_population','run_ranking','phenotype_similarity')).values():
                dest=root/item['path'];dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(original/item['path'],dest)
            (root/'scripts/__init__.py').touch()
            def cli(module,*args):
                code="import runpy,sys;sys.path.insert(0,sys.argv.pop(1));m=sys.argv.pop(1);sys.argv[0]=m;runpy.run_module(m,run_name='__main__')"
                env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','MVA_RANK_PROGRESS')}
                return subprocess.run([sys.executable,'-I','-B','-c',code,str(root),module,*map(str,args)],cwd=root,env=env,capture_output=True,text=True,timeout=30)
            chromosomes={}
            for c in CHROMS:
                output=data/f'chr{c}.jsonl'
                argv=['--patient',str(bcf),'--exomes',str(sites['exomes']),'--genomes',str(sites['genomes']),'--output',str(output),'--chromosome',c]
                p=cli('scripts.join_population',*argv)
                self.assertEqual(p.returncode,0,p.stderr)
                manifest=output.with_suffix('.manifest.json');m=json.loads(manifest.read_text())
                self.assertEqual(m['counts']['rows'],2)
                self.assertEqual(m['counts']['exomes_independent_isec_matches'],2)
                self.assertEqual(m['counts']['genomes_independent_isec_matches'],1 if c=='22' else 2)
                chromosomes[c]={'output':pin(output),'manifest':pin(manifest)}
            self.assertNotEqual(cli('scripts.join_population',*argv).returncode,0)
            escape=root/'outside-controlled.jsonl'
            p=cli('scripts.join_population','--patient',bcf,'--exomes',sites['exomes'],
                  '--genomes',sites['genomes'],'--output',escape,'--chromosome','22')
            self.assertNotEqual(p.returncode,0)
            self.assertIn('registered controlled',p.stderr)
            self.assertFalse(escape.exists())
            missing=json.loads((data/'chr22.jsonl').read_text().splitlines()[1])
            self.assertEqual(missing['genomes']['status'],'no_matching_allele_coverage_unknown')
            self.assertTrue(missing['limitations'])
            self.assertEqual(len(runner.coverage_gate(chromosomes)[0]),24)
            with self.assertRaisesRegex(ValueError,'all 24'):
                runner.coverage_gate({c:v for c,v in chromosomes.items() if c!='22'})
            cache=root/'data/cache/hpo-v2026-06-23';cache.mkdir(parents=True)
            ontology=cache/'hp.obo'
            ontology.write_text('format-version: 1.2\n\n[Term]\nid: HP:9000000\nname: Invented root\n\n[Term]\nid: HP:9000001\nname: Invented A\nis_a: HP:9000000\n\n[Term]\nid: HP:9000002\nname: Invented B\nis_a: HP:9000000\n')
            annotations=cache/'genes_to_phenotype.txt'
            annotations.write_text('gene_symbol\thpo_id\tfrequency\n'+''.join(f'TOY{c}\tHP:900000{1 if c=="22" else 2}\t1/1\n' for c in CHROMS))
            p=cli('scripts.phenotype_similarity','--phenotype',phenotype,'--ontology',ontology,'--gene-annotations',annotations,'--output',data/'hpo_gene_ranking.tsv')
            self.assertEqual(p.returncode,0,p.stderr)
            exported=root/'scripts/export_prepare_ranking_inputs.py'
            exported.write_text(render((original/'scripts/prepare_ranking_inputs.py').read_text()))
            shutil.copyfile(original/'scripts/export_preparation_resources.py',root/'scripts/export_preparation_resources.py')
            resources=data/'preparation-resources.json'
            spec=dict(schema='mva-export-preparation-v1',controlled_root=str(root/'data'),inputs={
                n:pin(p) for n,p in [('phenotype',phenotype),('phenotype_source',document),
                ('ontology',ontology),('gene_annotations',annotations),('prior_hpo',data/'hpo_gene_ranking.tsv'),
                ('bcf',bcf),('fai',Path(str(ref)+'.fai'))]})
            resources.write_text(json.dumps(spec))
            prepared=data/'prepared-inputs'
            p=cli('scripts.export_prepare_ranking_inputs','--resources',resources,'--output',prepared)
            self.assertEqual(p.returncode,0,p.stderr)
            self.assertNotEqual(cli('scripts.export_prepare_ranking_inputs','--resources',resources,'--output',prepared).returncode,0)
            original_ontology=ontology.read_text()
            ontology.write_text(original_ontology+'\n! altered fixture\n')
            p=cli('scripts.export_prepare_ranking_inputs','--resources',resources,'--output',data/'must-not-exist')
            self.assertNotEqual(p.returncode,0)
            self.assertIn('resource hash mismatch',p.stderr)
            self.assertFalse((data/'must-not-exist').exists())
            ontology.write_text(original_ontology)
            self.assertEqual(runner.sha(ontology),spec['inputs']['ontology']['sha256'])
            hpo=prepared/'hpo.json';ploidy=prepared/'ploidy.json'
            scores=json.loads(hpo.read_text());meta=json.loads(ploidy.read_text())
            self.assertGreater(scores['all_terms']['TOY22'],scores['all_terms']['TOY1'])
            self.assertTrue(all(v==0 for v in scores['leave_one_out']['HP:9000001'].values()))
            self.assertEqual(meta['unresolved_contigs'],['X','Y'])
            self.assertEqual(len(meta['intervals']),22)
            self.assertEqual(json.loads((prepared/'manifest.json').read_text())['variant_rows_audited'],48)
            manifest=json.loads((prepared/'manifest.json').read_text())
            self.assertEqual(manifest['inputs']['resource_contract']['sha256'],runner.sha(resources))
            self.assertEqual(manifest['code_sha256'],runner.sha(exported))
            contract=data/'contract.json';contract.write_text(json.dumps(dict(schema='mva-ranking-inputs-v1',chromosomes=chromosomes,output=str(data/'result'),**{n:pin(p) for n,p in [('bcf',bcf),('bcf_index',Path(str(bcf)+'.csi')),('gff',gff),('policy',policy),('ploidy',ploidy),('hpo',hpo)]})))
            p=cli('scripts.run_ranking','--contract',contract)
            self.assertEqual(p.returncode,0,p.stderr)
            result=json.loads((data/'result/manifest.json').read_text())
            with self.subTest(stage='ranking_outputs'):
                self.assertEqual(result['provenance']['counts'],{c:2 for c in CHROMS})
                self.assertEqual(result['status'],'complete_review_not_causal_validation')
                configs=[json.loads(l) for l in (data/'result/configurations/review.jsonl').read_text().splitlines()]
                pairs=[r for r in configs if r['configuration']=='possible_pair']
                self.assertTrue(pairs);self.assertTrue(all(r['phase']=='unresolved' for r in pairs))
                self.assertTrue(any(r['gene']=='TOY22' and r['frequency_lane']=='frequency_unresolved' for r in pairs))
                self.assertFalse(any(r['gene'] in ('TOYX','TOYY') for r in configs))
                self.assertNotEqual(cli('scripts.run_ranking','--contract',contract).returncode,0)
            # Mutation must fail even when the declared count was previously valid.
            (data/'chr22.jsonl').write_text('tampered synthetic output')
            with self.assertRaises(ValueError):runner.coverage_gate(chromosomes)
