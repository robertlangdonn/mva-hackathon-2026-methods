#!/usr/bin/env python3
"""Project and normalize a verified public sites VCF for local allele joins."""
import argparse
import fcntl
import json
import hashlib
import re
from pathlib import Path
import shutil
import subprocess
import tempfile
import time

try:
    from scripts.download_population import verify, check_space
    from scripts.population_runtime import atomic_json
except ModuleNotFoundError:
    from download_population import verify, check_space
    from population_runtime import atomic_json

TAGS = ('AC', 'AN', 'AF', 'AF_grpmax', 'nhomalt', 'fafmax_faf95_max')


def clear_owned_scratch(parent, output_name):
    for path in parent.glob('population-*'):
        if path.is_symlink() or not path.is_dir() or path.resolve().parent != parent.resolve():
            continue
        owner = path / 'owner.json'
        if not owner.is_file():
            continue
        data = json.loads(owner.read_text())
        if data == {'kind': 'mva_public_scratch_v1', 'output_name': output_name}:
            shutil.rmtree(path)  # exact owned, regenerable public scratch only
            print('removed interrupted public scratch: ' + path.name, flush=True)


def prepare(source, reference, output):
    """Public inputs only. REF mismatches and malformed arrays are fatal."""
    if output.exists() or Path(str(output) + '.csi').exists():
        raise ValueError('output already exists; preserve it and select a new path')
    output.parent.mkdir(parents=True, exist_ok=True)
    clear_owned_scratch(output.parent, output.name)
    with tempfile.TemporaryDirectory(prefix='population-', dir=output.parent) as tmp:
        scratch = Path(tmp)
        atomic_json(scratch / 'owner.json', {'kind': 'mva_public_scratch_v1', 'output_name': output.name})
        rename = scratch / 'contigs.tsv'
        rename.write_text(''.join(f'chr{c}\t{c}\n' for c in list(range(1, 23)) + ['X', 'Y']))
        selected = scratch / 'selected.bcf'
        normalized = scratch / 'normalized.bcf'
        sorted_bcf = scratch / 'sorted.bcf'
        header = subprocess.check_output(['bcftools', 'view', '-h', str(source)], text=True)
        info = set(re.findall(r'^##INFO=<ID=([^,]+),', header, re.MULTILINE))
        if not set(TAGS) <= info:
            raise ValueError('required population fields missing from source header')
        # Enumerate removals: bcftools rejects a keep-list when nothing can be removed.
        remove = sorted(info - set(TAGS))
        removal = ['-x', ','.join('INFO/' + t for t in remove)] if remove else []
        subprocess.run(['bcftools', 'annotate', '--rename-chrs', str(rename), *removal,
                        '-Ob', '-o', str(selected), str(source)], check=True)
        subprocess.run(['bcftools', 'norm', '-f', str(reference), '-c', 'e',
                        '-m', '-any', '-Ob', '-o', str(normalized), str(selected)], check=True)
        subprocess.run(['bcftools', 'sort', '-m', '256M', '-T', str(scratch / 'sort'),
                        '-Ob', '-o', str(sorted_bcf), str(normalized)], check=True)
        subprocess.run(['bcftools', 'index', str(sorted_bcf)], check=True)
        sorted_bcf.rename(output)
        Path(str(sorted_bcf) + '.csi').rename(Path(str(output) + '.csi'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--reference', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source = args.source.resolve()
    output = args.output.resolve()
    root = Path('/Volumes/MVA_WORK').resolve()
    public = root / 'public-resources' / 'gnomad'
    if not root.is_mount() or not source.is_relative_to(public) or not output.is_relative_to(public):
        raise SystemExit('source and output must be on the mounted public resource workspace')
    config = json.loads(args.config.read_text())
    specs = [s for s in config['files'] if Path(s['name']).name == source.name]
    if len(specs) != 1 or not source.name.endswith('.vcf.bgz'):
        raise SystemExit('source must match one complete pinned public sites object')
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.with_suffix('.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        check_space(shutil.disk_usage(output.parent).free, source.stat().st_size * 4,
                    config['minimum_free_after_job_bytes'])
        started = time.time()
        digest = verify(source, specs[0])
        prepare(source, args.reference.resolve(), output)
        with output.open('rb') as handle:
            output_hash = hashlib.file_digest(handle, 'sha256').hexdigest()
        with args.reference.open('rb') as handle:
            reference_hash = hashlib.file_digest(handle, 'sha256').hexdigest()
        manifest = {'source': specs[0], 'source_sha256': digest,
                    'output_sha256': output_hash, 'reference_sha256': reference_hash,
                    'reference': str(args.reference.resolve()), 'output': str(output),
                    'output_bytes': output.stat().st_size, 'elapsed_seconds': time.time() - started,
                    'tool': subprocess.check_output(['bcftools', '--version'], text=True).splitlines()[0],
                    'status': 'prepared_not_join_validated'}
        atomic_json(output.with_suffix('.manifest.json'), manifest)
        print('public resource prepared; local join validation still required')


if __name__ == '__main__':
    main()
