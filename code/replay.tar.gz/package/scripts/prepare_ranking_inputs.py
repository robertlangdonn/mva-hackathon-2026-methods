"""Prepare controlled phenotype sensitivity and conservative ploidy inputs.

Does not run variant ranking. No external queries; emits only aggregate status.
"""
import argparse
from collections import Counter, defaultdict
import csv
from functools import lru_cache
import json
import os
from pathlib import Path
import subprocess

from scripts.phenotype_similarity import (load_ontology, load_gene_annotations,
    make_ancestor_lookup, information_content, term_similarity, bma_score)
from scripts.run_ranking import sha, hpo_views, validate_intervals
from scripts.ranking_adapter import ROOT, CHROMS

HPO_HASHES = {
    'hp.obo': 'a5092cbdf605f568403cf7380d9173014015692433b2cc631bc5c1b053876b1b',
    'genes_to_phenotype.txt': '26cb7ee00c73b5777f6e5ad43323c941e1fcef1d191592f332d7929f3ea1ab3f'}


def sensitivity(terms, parents, genes):
    terms = sorted(set(terms))
    if not terms or set(terms) - parents.keys():
        raise ValueError('missing or unknown phenotype terms')
    ancestors = make_ancestor_lookup(parents)
    ic = information_content(genes, ancestors)
    @lru_cache(maxsize=None)
    def sim(q, t):
        return term_similarity(q, t, ancestors, ic)
    def score(query, target):
        if not query or not target:
            return 0.0
        return (sum(max(sim(q, t) for t in target) for q in query) / len(query) +
                sum(max(sim(q, t) for q in query) for t in target) / len(target)) / 2
    def view(query):
        return {g: score(query, sorted(target)) for g, target in sorted(genes.items())}
    return {'terms': terms, 'all_terms': view(terms),
            'leave_one_out': {q: view([t for t in terms if t != q]) for q in terms}}


def verify_baseline(scores, path):
    with path.open() as handle:
        rows = list(csv.DictReader(handle, delimiter='\t'))
    if len(rows) != len(scores) or {r['gene'] for r in rows} != scores.keys():
        raise ValueError('baseline gene set mismatch')
    if any(abs(scores[r['gene']] - float(r['resnik_bma'])) > 1e-8 for r in rows):
        raise ValueError('baseline phenotype score mismatch')


def audit_ploidy(lines):
    counts = defaultdict(Counter)
    for line in lines:
        fields = line.rstrip('\n').split('\t')
        if len(fields) != 2 or fields[0] not in CHROMS:
            raise ValueError('expected canonical single-sample GT audit')
        alleles = fields[1].replace('|', '/').split('/')
        category = 'missing_or_partial' if any(a in ('', '.') for a in alleles) else f'called_ploidy_{len(alleles)}'
        counts[fields[0]][category] += 1
    return dict(counts)


def save(path, data):
    with path.open('x') as handle:
        json.dump(data, handle, sort_keys=True, allow_nan=False)
        handle.flush()
        os.fsync(handle.fileno())


def prepare(output):
    controlled = (ROOT / 'data/intermediate').resolve()
    output = output.resolve()
    if output == controlled or not output.is_relative_to(controlled):
        raise ValueError('output must be under controlled storage')
    phenotype_path = controlled / 'phenotype.json'
    phenotype = json.loads(phenotype_path.read_text())
    source = (ROOT / 'data/raw' / phenotype['source']['name']).resolve()
    if not source.is_relative_to((ROOT / 'data/raw').resolve()) or sha(source) != phenotype['source']['sha256']:
        raise ValueError('phenotype source integrity mismatch')
    cache = ROOT / 'data/cache/hpo-v2026-06-23'
    for name, expected in HPO_HASHES.items():
        if sha(cache / name) != expected:
            raise ValueError('pinned HPO resource mismatch')
    paths = {'phenotype': phenotype_path, 'phenotype_source': source,
             'ontology': cache / 'hp.obo', 'gene_annotations': cache / 'genes_to_phenotype.txt',
             'prior_hpo': controlled / 'hpo_gene_ranking.tsv',
             'bcf': controlled / 'genomewide.canonical.csq.clinvar.bcf',
             'fai': ROOT / 'data/cache/ensembl-116/Homo_sapiens.GRCh38.dna.primary_assembly.fa.fai'}
    pins = {n: {'path': str(p), 'sha256': sha(p)} for n, p in paths.items()}
    output.mkdir()
    (output / 'INCOMPLETE').touch(exist_ok=False)
    terms = [r['hpo_id'] for r in phenotype['phenotypes']]
    data = sensitivity(terms, load_ontology(paths['ontology']), load_gene_annotations(paths['gene_annotations']))
    verify_baseline(data['all_terms'], paths['prior_hpo'])
    hpo_views(data)
    save(output / 'hpo.json', data)
    print('HPO sensitivity generated; baseline score equivalence passed', flush=True)
    with (output / 'ploidy-query.log').open('x') as log:
        proc = subprocess.Popen(['bcftools', 'query', '-f', '%CHROM\t[%GT]\n', str(paths['bcf'])],
                                stdout=subprocess.PIPE, stderr=log, text=True)
        try:
            counts = audit_ploidy(proc.stdout)
            if proc.wait() != 0:
                raise ValueError('ploidy query failed')
        finally:
            proc.stdout.close()
            if proc.poll() is None:
                proc.terminate()
                proc.wait()
    # Diploid autosomal review is an explicit model, not a karyotype conclusion.
    lengths = {f[0]: int(f[1]) for line in paths['fai'].read_text().splitlines()
               if (f := line.split('\t'))[0] in CHROMS}
    if set(lengths) != set(CHROMS):
        raise ValueError('canonical reference lengths incomplete')
    metadata = {'build': 'GRCh38', 'source': pins,
                'audit_note': 'Autosomal diploid analytical model only. GT audit does not establish cellular karyotype. X/Y expected ploidy left unresolved; no sex or PAR inference.',
                'intervals': [{'chrom': c, 'start': 1, 'end': lengths[c], 'ploidy': 2}
                              for c in CHROMS[:22]],
                'unresolved_contigs': ['X', 'Y'], 'genotype_audit': counts}
    validate_intervals(metadata)
    save(output / 'ploidy.json', metadata)
    for n, p in paths.items():
        if sha(p) != pins[n]['sha256']:
            raise ValueError('input changed during preparation')
    save(output / 'manifest.json', {'status': 'prepared_with_explicit_XY_limitations',
         'inputs': pins, 'code_sha256': sha(Path(__file__)),
         'hpo_sha256': sha(output / 'hpo.json'), 'ploidy_sha256': sha(output / 'ploidy.json'),
         'baseline_equivalence': 'passed_tolerance_1e-8',
         'gene_count': len(data['all_terms']), 'phenotype_view_count': 1 + len(data['terms']),
         'variant_rows_audited': sum(sum(v.values()) for v in counts.values())})
    (output / 'INCOMPLETE').unlink()
    print('Input preparation complete; X/Y interpretation explicitly unresolved; no variant ranking run')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    prepare(parser.parse_args().output)
