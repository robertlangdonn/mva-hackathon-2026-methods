#!/usr/bin/env python3
"""Stream exact chr22 allele joins locally; write only into controlled storage."""
import argparse
from collections import Counter
from contextlib import contextmanager
import hashlib
import itertools
import json
from pathlib import Path
import subprocess
import time
try:
    from scripts.population_evidence import source_evidence, combined_evidence
    from scripts.population_runtime import atomic_json
except ModuleNotFoundError:
    from population_evidence import source_evidence, combined_evidence
    from population_runtime import atomic_json

ROOT = Path(__file__).resolve().parents[1]
PUBLIC_FORMAT = '%CHROM\t%POS\t%REF\t%ALT\t%FILTER\t%AC\t%AN\t%AF\t%AF_grpmax\t%nhomalt\t%fafmax_faf95_max\n'


@contextmanager
def query(path, fmt, log, chrom='22'):
    process = subprocess.Popen(['bcftools', 'query', '-r', chrom, '-f', fmt, str(path)],
                               stdout=subprocess.PIPE, stderr=log, text=True)
    try:
        yield (line.rstrip('\n').split('\t') for line in process.stdout)
        if process.wait() != 0:
            raise RuntimeError('local query failed; inspect controlled log')
    finally:
        process.stdout.close()
        if process.poll() is None:
            process.terminate()
            process.wait()


def groups(rows, chrom='22'):
    previous = -1
    for pos, group in itertools.groupby(rows, key=lambda row: int(row[1])):
        if pos <= previous:
            raise ValueError('resource positions not sorted')
        previous = pos
        alleles = {}
        for row in group:
            if row[0] != chrom or ',' in row[3]:
                raise ValueError('expected normalized biallelic chr22 rows')
            key = (row[2], row[3])
            alleles.setdefault(key, []).append(row)
        yield pos, alleles


class Lookup:
    def __init__(self, rows, chrom='22'):
        self.iterator = iter(groups(rows, chrom))
        self.current = next(self.iterator, None)
        self.previous = -1

    def at(self, pos):
        if pos < self.previous:
            raise ValueError('patient positions not sorted')
        self.previous = pos
        while self.current is not None and self.current[0] < pos:
            self.current = next(self.iterator, None)
        return self.current[1] if self.current is not None and self.current[0] == pos else {}

    def finish(self):
        for _ in self.iterator:
            pass


def evidence(rows):
    if rows is None:
        return source_evidence(True)
    if any(len(row) != 11 for row in rows):
        raise ValueError('population query schema mismatch')
    records = [source_evidence(True, dict(zip(
        ('filter', 'ac', 'an', 'af', 'af_grpmax', 'nhomalt', 'faf95'), row[4:]))) for row in rows]
    if len(records) == 1:
        return records[0]
    values = [r['af_grpmax'] for r in records if r['af_grpmax'] is not None]
    return {'status': 'matched_multiple_records', 'records': records,
            'af_grpmax': max(values) if values else None,
            'filter': 'multiple_records_requires_review', 'an': '.'}


def join(patient, exomes, genomes, output, chrom='22'):
    ex, ge = Lookup(exomes, chrom), Lookup(genomes, chrom)
    counts = Counter()
    previous = -1
    seen = set()
    for row in patient:
        if len(row) != 4 or row[0] != chrom or ',' in row[3]:
            raise ValueError('patient allele query schema mismatch')
        pos = int(row[1])
        if pos != previous:
            seen = set()
        key = tuple(row[2:4])
        if key in seen:
            raise ValueError('duplicate patient normalized key')
        seen.add(key)
        previous = pos
        a, b = evidence(ex.at(pos).get(key)), evidence(ge.at(pos).get(key))
        result = combined_evidence(a, b)
        output.write(json.dumps({'chrom': chrom, 'pos': pos, 'ref': key[0], 'alt': key[1],
                                 'exomes': a, 'genomes': b, **result}, separators=(',', ':')) + '\n')
        counts['rows'] += 1
        counts['exomes_' + a['status']] += 1
        counts['genomes_' + b['status']] += 1
        counts[result['observed_frequency_band']] += 1
        counts[result['interpretation']] += 1
    ex.finish()
    ge.finish()
    return dict(counts)


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b''):
            digest.update(block)
    return digest.hexdigest()


def oracle_count(patient, resource, log, chrom='22'):
    process = subprocess.Popen(['bcftools', 'isec', '-r', chrom, '-c', 'none',
                                '-n=2', '-w1', '-Ou', str(patient), str(resource)],
                               stdout=subprocess.PIPE, stderr=log)
    counter = subprocess.Popen(['bcftools', 'query', '-f', '%POS\n'],
                               stdin=process.stdout, stdout=subprocess.PIPE, stderr=log, text=True)
    process.stdout.close()
    count = sum(1 for _ in counter.stdout)
    counter.stdout.close()
    query_status, isec_status = counter.wait(), process.wait()
    if query_status or isec_status:
        raise RuntimeError('independent intersection failed; inspect controlled log')
    return count


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('patient', 'exomes', 'genomes', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--chromosome', default='22', choices=[str(i) for i in range(1, 23)] + ['X', 'Y'])
    args = parser.parse_args()
    controlled = (ROOT / 'data/intermediate').resolve()
    if not args.patient.resolve().is_relative_to(controlled) or not args.output.resolve().is_relative_to(controlled):
        raise SystemExit('patient and output paths must be in registered controlled intermediate storage')
    output = args.output.resolve()
    if output.exists():
        raise SystemExit('output already exists; preserve it')
    partial = output.with_suffix(output.suffix + '.partial')
    started = time.time()
    with partial.open('x') as handle, output.with_suffix('.log').open('a') as log:
        with query(args.patient, '%CHROM\t%POS\t%REF\t%ALT\n', log, args.chromosome) as patient, \
             query(args.exomes, PUBLIC_FORMAT, log, args.chromosome) as exomes, \
             query(args.genomes, PUBLIC_FORMAT, log, args.chromosome) as genomes:
            counts = join(patient, exomes, genomes, handle, args.chromosome)
        for name in ('exomes', 'genomes'):
            observed = oracle_count(args.patient, getattr(args, name), log, args.chromosome)
            expected = sum(counts.get(name + '_' + status, 0)
                           for status in ('matched_af_available', 'matched_af_missing', 'matched_multiple_records'))
            if observed != expected:
                raise RuntimeError('independent allele intersection count differs')
            counts[name + '_independent_isec_matches'] = observed
    manifest = {'counts': counts, 'elapsed_seconds': time.time() - started,
                'inputs': {name: {'path': str(getattr(args, name).resolve()),
                                 'sha256': sha256(getattr(args, name))}
                           for name in ('patient', 'exomes', 'genomes')},
                'output_sha256': sha256(partial), 'status': 'joined_match_counts_oracle_verified'}
    atomic_json(output.with_suffix('.manifest.json'), manifest)
    partial.rename(output)
    print(json.dumps(counts, sort_keys=True))


if __name__ == '__main__':
    main()
