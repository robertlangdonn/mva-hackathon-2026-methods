"""Generate a preparation export copy; preserve computation and production source."""
import ast
import json
import os
from pathlib import Path
import time
from scripts import export_preparation_resources


def render(source):
    tree = ast.parse(source)
    functions = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'prepare']
    if len(functions) != 1:
        raise ValueError('expected one preparation function')
    fn = functions[0]
    lines = source.splitlines(keepends=True)
    mkdir = [n for n in fn.body if ast.dump(n) == ast.dump(ast.parse('output.mkdir()').body[0])]
    if len(mkdir) != 1:
        raise ValueError('expected one output boundary')
    # Only resource resolution before output creation is replaced. Everything
    # from mkdir through the final integrity checks remains byte-identical.
    start, end = fn.lineno - 1, mkdir[0].lineno - 1
    old = ''.join(lines[start:end])
    replacement = ('def prepare(output, resource_contract):\n'
                   '    from scripts.export_preparation_resources import load_resources\n'
                   '    output, phenotype, paths, pins = load_resources(resource_contract, output)\n')
    tail = "    prepare(parser.parse_args().output)\n"
    new_tail = ("    parser.add_argument('--resources', required=True, type=Path)\n"
                "    args = parser.parse_args()\n"
                "    prepare(args.output, args.resources)\n")
    if source.count(tail) != 1:
        raise ValueError('unexpected CLI layout')
    result = source.replace(old, replacement, 1).replace(tail, new_tail, 1)
    if result.replace(replacement, old, 1).replace(new_tail, tail, 1) != source:
        raise ValueError('change outside export interface')
    compile(result, '<preparation-export>', 'exec')
    return result


def main():
    os.umask(0o077)
    root = Path(__file__).resolve().parents[1]
    source = root / 'scripts/prepare_ranking_inputs.py'
    before = export_preparation_resources.digest(source)
    out = root / f'data/intermediate/preparation-adapter-{time.time_ns()}'
    out.mkdir(); (out / 'INCOMPLETE').touch()
    copy = out / 'export-copy/scripts'; copy.mkdir(parents=True)
    (copy / source.name).write_text(render(source.read_text()))
    helper = Path(export_preparation_resources.__file__)
    (copy / helper.name).write_bytes(helper.read_bytes())
    result = {'production_sha256': before, 'builder_sha256': export_preparation_resources.digest(Path(__file__)),
              'computation_tail_unchanged': True, 'complete_package': False,
              'artifacts': {str(p.relative_to(out)): export_preparation_resources.digest(p) for p in copy.iterdir()}}
    if export_preparation_resources.digest(source) != before:
        raise ValueError('production drift')
    (out / 'result.json').write_text(json.dumps(result, indent=2))
    (out / 'INCOMPLETE').unlink()
    print(out.relative_to(root))


if __name__ == '__main__':
    main()
