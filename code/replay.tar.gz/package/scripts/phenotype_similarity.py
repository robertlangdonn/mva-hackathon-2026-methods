#!/usr/bin/env python3
"""Rank genes by local HPO semantic similarity using a transparent Resnik BMA."""

from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
from collections import Counter, defaultdict
from functools import lru_cache
from pathlib import Path


def load_ontology(path: Path) -> dict[str, set[str]]:
    parents: dict[str, set[str]] = defaultdict(set)
    current: str | None = None
    obsolete = False
    with path.open(encoding="utf-8") as handle:
        for raw in handle:
            line = raw.rstrip("\n")
            if line == "[Term]":
                current = None
                obsolete = False
            elif line.startswith("id: HP:"):
                current = line.removeprefix("id: ")
                parents.setdefault(current, set())
            elif line == "is_obsolete: true":
                obsolete = True
                if current:
                    parents.pop(current, None)
                    current = None
            elif current and line.startswith("is_a: HP:"):
                parents[current].add(line.split()[1])
            elif line.startswith("[") and line != "[Term]":
                current = None
    return dict(parents)


def make_ancestor_lookup(parents: dict[str, set[str]]):
    @lru_cache(maxsize=None)
    def ancestors(term: str) -> frozenset[str]:
        if term not in parents:
            return frozenset()
        result = {term}
        for parent in parents[term]:
            result.update(ancestors(parent))
        return frozenset(result)

    return ancestors


def zero_frequency(raw: str) -> bool:
    value = raw.strip()
    if value == "0":
        return True
    if "/" in value:
        numerator, _, denominator = value.partition("/")
        return numerator.strip() == "0" and denominator.strip().isdigit()
    return False


def load_gene_annotations(path: Path) -> dict[str, set[str]]:
    genes: dict[str, set[str]] = defaultdict(set)
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            if not zero_frequency(row["frequency"]):
                genes[row["gene_symbol"]].add(row["hpo_id"])
    return dict(genes)


def information_content(
    genes: dict[str, set[str]], ancestor_lookup
) -> dict[str, float]:
    counts: Counter[str] = Counter()
    for terms in genes.values():
        propagated = set()
        for term in terms:
            propagated.update(ancestor_lookup(term))
        counts.update(propagated)
    total = len(genes)
    return {term: -math.log(count / total) for term, count in counts.items() if count}


def term_similarity(left: str, right: str, ancestor_lookup, ic: dict[str, float]) -> float:
    common = ancestor_lookup(left) & ancestor_lookup(right)
    return max((ic.get(term, 0.0) for term in common), default=0.0)


def bma_score(query: set[str], target: set[str], ancestor_lookup, ic: dict[str, float]) -> float:
    if not query or not target:
        return 0.0
    query_best = [max(term_similarity(q, t, ancestor_lookup, ic) for t in target) for q in query]
    target_best = [max(term_similarity(t, q, ancestor_lookup, ic) for q in query) for t in target]
    return (sum(query_best) / len(query_best) + sum(target_best) / len(target_best)) / 2


def rank_for_gene(
    gene: str, query: set[str], genes: dict[str, set[str]], ancestor_lookup, ic: dict[str, float]
) -> int:
    focus_score = bma_score(query, genes[gene], ancestor_lookup, ic)
    return 1 + sum(
        1
        for other_gene, terms in genes.items()
        if other_gene != gene
        and (
            bma_score(query, terms, ancestor_lookup, ic) > focus_score
            or (
                bma_score(query, terms, ancestor_lookup, ic) == focus_score
                and other_gene < gene
            )
        )
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phenotype", required=True, type=Path)
    parser.add_argument("--ontology", required=True, type=Path)
    parser.add_argument("--gene-annotations", required=True, type=Path)
    parser.add_argument("--focus-variants", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    phenotype = json.loads(args.phenotype.read_text(encoding="utf-8"))
    query = {row["hpo_id"] for row in phenotype["phenotypes"]}
    parents = load_ontology(args.ontology)
    missing = sorted(query - parents.keys())
    if missing:
        raise ValueError(f"phenotype terms absent from pinned ontology: {', '.join(missing)}")
    ancestor_lookup = make_ancestor_lookup(parents)
    genes = load_gene_annotations(args.gene_annotations)
    ic = information_content(genes, ancestor_lookup)
    ranked = sorted(
        ((gene, bma_score(query, terms, ancestor_lookup, ic), len(terms)) for gene, terms in genes.items()),
        key=lambda row: (-row[1], row[0]),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, delimiter="\t")
        writer.writerow(["rank", "gene", "resnik_bma", "direct_annotation_count"])
        for rank, (gene, score, count) in enumerate(ranked, 1):
            writer.writerow([rank, gene, f"{score:.8f}", count])

    print(f"phenotype_terms={len(query)}")
    print(f"ranked_genes={len(ranked)}")
    if args.focus_variants:
        with args.focus_variants.open(newline="", encoding="utf-8") as handle:
            focus_genes = {
                gene
                for row in csv.DictReader(handle, delimiter="\t")
                for gene in row["genes"].split(",")
                if gene
            }
        rank_by_gene = {gene: rank for rank, (gene, _, _) in enumerate(ranked, 1)}
        focus_ranks = sorted(rank_by_gene[gene] for gene in focus_genes if gene in rank_by_gene)
        print(f"focus_genes_with_annotations={len(focus_ranks)}")
        if focus_ranks:
            print(f"focus_best_rank={focus_ranks[0]}")
        leave_one_out_ranks = []
        for gene in sorted(focus_genes & genes.keys()):
            for omitted in sorted(query):
                reduced_query = query - {omitted}
                leave_one_out_ranks.append(
                    rank_for_gene(gene, reduced_query, genes, ancestor_lookup, ic)
                )
        if leave_one_out_ranks:
            print(f"focus_leave_one_out_best_rank={min(leave_one_out_ranks)}")
            print(f"focus_leave_one_out_median_rank={statistics.median(leave_one_out_ranks):g}")
            print(f"focus_leave_one_out_worst_rank={max(leave_one_out_ranks)}")


if __name__ == "__main__":
    main()
