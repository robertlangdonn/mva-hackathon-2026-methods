"""Explicit local resource contract for export copies, not production defaults."""
import hashlib
import json
from pathlib import Path
import re

NAMES = {'phenotype', 'phenotype_source', 'ontology', 'gene_annotations',
         'prior_hpo', 'bcf', 'fai'}


def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def absolute(value):
    path = Path(value)
    if not path.is_absolute() or '..' in path.parts:
        raise ValueError('explicit absolute path required')
    return path.resolve()


def load_resources(contract_path, output):
    contract_path = absolute(contract_path)
    before = digest(contract_path)
    contract = json.loads(contract_path.read_text())
    if set(contract) != {'schema', 'controlled_root', 'inputs'} or contract['schema'] != 'mva-export-preparation-v1':
        raise ValueError('unknown resource contract')
    controlled = absolute(contract['controlled_root'])
    if controlled == Path('/') or not controlled.is_dir():
        raise ValueError('existing dedicated controlled directory required')
    if not contract_path.is_relative_to(controlled):
        raise ValueError('contract must remain controlled')
    output = absolute(output)
    if output == controlled or not output.is_relative_to(controlled):
        raise ValueError('output must remain controlled')
    if output.exists():
        raise ValueError('output already exists')
    if set(contract['inputs']) != NAMES:
        raise ValueError('exact resource set required')
    paths, pins = {}, {}
    for name, row in contract['inputs'].items():
        if set(row) != {'path', 'sha256'} or not isinstance(row['sha256'], str) or not re.fullmatch('[0-9a-f]{64}', row['sha256']):
            raise ValueError('invalid resource pin')
        path = absolute(row['path'])
        if not path.is_relative_to(controlled) or not path.is_file():
            raise ValueError('resource must be a controlled local file')
        if digest(path) != row['sha256']:
            raise ValueError('resource hash mismatch')
        paths[name] = path
        pins[name] = {'path': str(path), 'sha256': row['sha256']}
    phenotype = json.loads(paths['phenotype'].read_text())
    source = phenotype['source']
    if source['name'] != paths['phenotype_source'].name or source['sha256'] != pins['phenotype_source']['sha256']:
        raise ValueError('phenotype source integrity mismatch')
    if digest(contract_path) != before:
        raise ValueError('resource contract changed')
    # The unchanged preparation tail rechecks every input, including the contract.
    paths['resource_contract'] = contract_path
    pins['resource_contract'] = {'path': str(contract_path), 'sha256': before}
    return output, phenotype, paths, pins
