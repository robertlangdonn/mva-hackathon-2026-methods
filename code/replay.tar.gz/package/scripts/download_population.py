#!/usr/bin/env python3
"""Resume pinned public resources; promote .part files only after size/hash checks."""
import argparse
import base64
import fcntl
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time
from urllib.parse import quote
try:
    from scripts.population_runtime import atomic_json
except ModuleNotFoundError:
    from population_runtime import atomic_json


def verify(path, spec):
    if path.stat().st_size != spec['size']:
        raise ValueError('resource size mismatch: ' + path.name)
    md5, sha = hashlib.md5(), hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b''):
            md5.update(block)
            sha.update(block)
    if base64.b64encode(md5.digest()).decode() != spec['md5_base64']:
        raise ValueError('resource checksum mismatch: ' + path.name)
    return sha.hexdigest()


def check_space(free, remaining, reserve):
    if remaining < 0 or free < remaining + reserve:
        raise ValueError('insufficient space for downloads plus reserve')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--volume', type=Path, default=Path('/Volumes/MVA_WORK'))
    args = parser.parse_args()
    volume = args.volume.resolve()
    if not volume.is_mount():
        raise SystemExit('expected mounted data volume is unavailable')
    config = json.loads(args.config.read_text())
    if config['bucket'] != 'gcp-public-data--gnomad':
        raise SystemExit('only the public gnomAD bucket is supported')
    chrom = str(config.get('chromosome', '22'))
    if chrom not in [str(i) for i in range(1, 23)] + ['X', 'Y']:
        raise SystemExit('invalid canonical chromosome')
    dest = volume / 'public-resources' / 'gnomad' / ('chr' + chrom)
    dest.mkdir(parents=True, exist_ok=True)
    with (dest / '.download.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        run(config, dest)


def run(config, dest):
    specs = config['files']
    names = [Path(s['name']).name for s in specs]
    if len(names) != len(set(names)):
        raise ValueError('duplicate destination basename')
    remaining = 0
    for spec in specs:
        final = dest / Path(spec['name']).name
        part = final.with_name(final.name + '.part')
        existing = final if final.exists() else part
        size = existing.stat().st_size if existing.exists() else 0
        if size > spec['size']:
            raise ValueError('existing resource is larger than pinned object')
        remaining += spec['size'] - size
    check_space(shutil.disk_usage(dest).free, remaining,
                config['minimum_free_after_job_bytes'])
    manifest = {'resource': config['resource'], 'started_unix': time.time(),
                'status': 'running', 'verified': []}
    def checkpoint():
        path = dest / 'download-manifest.json'
        atomic_json(path, manifest)
    checkpoint()
    try:
        for spec in specs:
            final = dest / Path(spec['name']).name
            part = final.with_name(final.name + '.part')
            started = time.monotonic()
            if not final.exists():
                check_space(shutil.disk_usage(dest).free,
                            spec['size'] - (part.stat().st_size if part.exists() else 0),
                            config['minimum_free_after_job_bytes'])
                url = ('https://storage.googleapis.com/' + config['bucket'] + '/'
                       + quote(spec['name'], safe='/') + '?generation=' + spec['generation'])
                print('downloading ' + final.name, flush=True)
                if not part.exists() or part.stat().st_size != spec['size']:
                    subprocess.run(['curl', '--fail', '--location', '--silent', '--show-error',
                                    '--retry', '5', '--connect-timeout', '30',
                                    '--speed-limit', '1024', '--speed-time', '120',
                                    '--continue-at', '-', '--output', str(part), url], check=True)
                digest = verify(part, spec)
                part.rename(final)
            else:
                digest = verify(final, spec)
            manifest['verified'].append(dict(spec, local_name=final.name, sha256=digest,
                                            elapsed_seconds=time.monotonic() - started))
            checkpoint()
            print('verified ' + final.name, flush=True)
        manifest['status'] = 'complete'
    except BaseException as exc:
        manifest['status'] = 'interrupted_or_failed'
        manifest['error_type'] = type(exc).__name__
        raise
    finally:
        manifest['finished_unix'] = time.time()
        checkpoint()


if __name__ == '__main__':
    main()
