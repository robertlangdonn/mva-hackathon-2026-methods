# Private read-evidence demonstration

Run python3 -I -B verify_and_test.py from a clean extracted directory.
Python >=3.11 and POSIX are required. No Python third-party packages are required.
The shared builder probes samtools/bcftools versions; these read-only toy tests do
not execute either binary. No BWA, network or patient processing is performed.

Tests exercise real SNV/indel algorithms on invented aligned SAM, verified chunk
and reference context handling, and exported consolidation after relocation.
They cover v1's unchanged 100 MiB total-input cap and v2's explicit, separate
reference byte budget (at most 6 GiB), exact expected size, streaming hash,
bounded read blocks and repeated identity checks. All other inputs remain capped
at 100 MiB. Each reference hash pass has a checked 300-second time budget;
blocked filesystem reads are not forcibly interrupted.

No full-size human reference is tested or bundled. Streaming digest tests use a
2.4 MB invented file. The theoretical size cap is not measured scalability proof.
The reference is rehashed for each validation phase, with corresponding I/O cost.
The separate export_read_assessment CLI regenerates assessments using pinned
method sources, an explicit target list and the verified retained snapshot; it
requires no supplied assessment reports. Its synthetic integration checks exact
agreement with the original function-based fixture and rejects missing scope,
source drift, artifact drift and output reuse. At most 100 targets are accepted;
assessment work checks a 300-second deadline and decompressed input limits.
Census/offset metadata are invented. Production reader
mains, storage controllers, alignment and acquisition are not exercised.

Sources and policy are included only by dependency allowlist. Import-only support
modules retain historical constants/defaults; do not run their controllers.
No controlled input, patient-derived fixture, tool binary or public reference is
included. Integrity checks are not an OS sandbox, scientific validation or proof
of license ownership. PRIVATE REVIEW ONLY; no release/license approval is implied.
