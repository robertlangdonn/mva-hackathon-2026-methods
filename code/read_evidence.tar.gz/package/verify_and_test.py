import hashlib,json,os,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
if sys.version_info < (3,11): raise SystemExit('Python >=3.11 required')
manifest=json.loads((root/'manifest.json').read_text())
expected=set(manifest['artifacts'])|{'manifest.json'}
if any(p.is_symlink() for p in root.rglob('*')): raise SystemExit('Symlink rejected')
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
if actual!=expected: raise SystemExit('Unexpected or missing package file')
for name,digest in manifest['artifacts'].items():
 p=root/name
 if not p.resolve().is_relative_to(root): raise SystemExit('Unsafe package path')
 if hashlib.sha256(p.read_bytes()).hexdigest()!=digest: raise SystemExit('Artifact hash mismatch')
env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','MVA_RANK_PROGRESS')}
code="import sys,unittest;sys.path.insert(0,sys.argv[1]);s=unittest.defaultTestLoader.loadTestsFromNames(sys.argv[2:]);r=unittest.TextTestRunner(verbosity=2).run(s);sys.exit(not r.wasSuccessful())"
raise SystemExit(subprocess.run([sys.executable,'-I','-B','-c',code,str(root)]+manifest['tests'],cwd=root,env=env).returncode)
