#!/usr/bin/env python3
"""User controls: status, pause, resume. A manual pause is persistent."""
import argparse
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import uuid
try:
    from scripts import population_runtime as rt
except ModuleNotFoundError:
    import population_runtime as rt


def group_members(pgid):
    result = subprocess.run(['ps', '-axo', 'pid=,pgid=,stat=,command='], capture_output=True, text=True, check=True)
    members = []
    for line in result.stdout.splitlines():
        parts = line.strip().split(None, 3)
        if len(parts) == 4 and int(parts[1]) == pgid and not parts[2].startswith('Z'):
            members.append((int(parts[0]), parts[3]))
    return members


def managed_members(worker):
    pgid = worker.get('pgid')
    if not pgid or pgid != worker.get('pid'):
        return []
    members = group_members(pgid)
    if not members:
        return []
    anchors = (str(rt.ROOT / 'scripts'), str(rt.VOLUME / 'public-resources/gnomad'))
    allowed = {'Python', 'python3', 'python3.14', 'curl', 'bcftools', 'caffeinate'}
    if not any(any(anchor in command for anchor in anchors) for _, command in members):
        return []  # stale/reused PID: never signal unrelated processes
    if any(Path(command.split()[0]).name not in allowed for _, command in members):
        raise RuntimeError('unexpected process in recorded worker group; review before stopping')
    return members


def stop_group(worker):
    for sig, seconds in ((signal.SIGINT, 10), (signal.SIGTERM, 5), (signal.SIGKILL, 3)):
        if not managed_members(worker):
            return
        os.killpg(worker['pgid'], sig)
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            # Exiting processes may have transient command strings on macOS.
            # The group was verified before signaling; poll membership, not its changing argv.
            if not group_members(worker['pgid']):
                return
            time.sleep(0.25)
    if managed_members(worker):
        raise RuntimeError('worker group has not stopped; do not eject yet')


def pause():
    rt.atomic_json(rt.DATA / 'population-control.json', {'paused': True, 'requested_unix': time.time()})
    rt.event('pause_requested')
    worker = rt.read_json(rt.DATA / 'population-worker.json')
    if worker:
        stop_group(worker)
    if rt.running():
        raise RuntimeError('worker lock still held; do not eject yet')
    rt.event('paused')
    rt.render_tracker()
    print('PAUSED. Saved downloads are retained. You can now eject the SSD or shut down.')


def resume():
    if rt.running():
        print('A worker is already active or stopping; no duplicate was started.')
        return
    previous = rt.read_json(rt.DATA / 'population-worker.json')
    if previous:
        stop_group(previous)  # clean up verified orphan children after an abrupt parent death
    rt.ensure_volume()
    rt.atomic_json(rt.DATA / 'population-control.json', {'paused': False, 'requested_unix': time.time()})
    logs = rt.DATA / 'population-logs'
    logs.mkdir(parents=True, exist_ok=True)
    log = logs / (time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8] + '.log')
    with log.open('ab') as output:
        environment = dict(os.environ)
        environment['PATH'] = '/opt/homebrew/bin:' + environment.get('PATH', '/usr/bin:/bin')
        process = subprocess.Popen([sys.executable, str(rt.ROOT / 'scripts/run_population.py'), '--log', str(log)],
                                   cwd=rt.ROOT, stdout=output, stderr=subprocess.STDOUT,
                                   stdin=subprocess.DEVNULL, env=environment, start_new_session=True)
    rt.event('resume_launched', pid=process.pid, log=str(log))
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(f'worker exited during startup; inspect {log}')
        worker = rt.read_json(rt.DATA / 'population-worker.json')
        if rt.running() and worker.get('pid') == process.pid:
            rt.render_tracker()
            print(f'RUNNING. Log: {log}')
            return
        time.sleep(0.1)
    raise RuntimeError('startup status uncertain; inspect tracker before another start')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('status', 'pause', 'resume'))
    parser.add_argument('--watch', action='store_true')
    args = parser.parse_args()
    if args.action == 'status':
        while True:
            if args.watch and sys.stdout.isatty():
                print('\033[2J\033[H', end='')
            print(rt.render_tracker())
            if not args.watch:
                break
            time.sleep(10)
    else:
        with rt.exclusive(rt.DATA / 'population-controller.lock'):
            (pause if args.action == 'pause' else resume)()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass  # closing the status viewer never stops the independent worker
