#!/usr/bin/env python3
"""Extract BED intervals for a pinned gene panel from an Ensembl GFF3 file."""

from __future__ import annotations

import argparse
import csv
import gzip
from pathlib import Path
from urllib.parse import unquote


def parse_attributes(raw: str) -> dict[str, str]:
    attributes: dict[str, str] = {}
    for item in raw.rstrip().split(";"):
        if not item:
            continue
        key, separator, value = item.partition("=")
        if separator:
            attributes[key] = unquote(value)
    return attributes


def load_symbols(panel_path: Path) -> list[str]:
    with panel_path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if "gene" not in (reader.fieldnames or []):
            raise ValueError("panel must contain a 'gene' column")
        symbols = [row["gene"].strip() for row in reader if row["gene"].strip()]
    if len(symbols) != len(set(symbols)):
        raise ValueError("panel contains duplicate gene symbols")
    return symbols


def extract_regions(gff_path: Path, symbols: list[str], padding: int) -> list[tuple[str, int, int, str]]:
    wanted = set(symbols)
    found: dict[str, tuple[str, int, int, str]] = {}
    opener = gzip.open if gff_path.suffix == ".gz" else open
    with opener(gff_path, "rt", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("#"):
                continue
            fields = line.rstrip("\n").split("\t")
            if len(fields) != 9 or fields[2] != "gene":
                continue
            attributes = parse_attributes(fields[8])
            symbol = attributes.get("Name")
            if symbol not in wanted:
                continue
            if symbol in found:
                raise ValueError(f"multiple gene features found for {symbol}")
            start_1based = int(fields[3])
            end_1based = int(fields[4])
            # BED is zero-based, half-open. Padding is clamped at contig start.
            found[symbol] = (
                fields[0],
                max(0, start_1based - 1 - padding),
                end_1based + padding,
                symbol,
            )
    missing = [symbol for symbol in symbols if symbol not in found]
    if missing:
        raise ValueError(f"genes absent from GFF3: {', '.join(missing)}")
    return sorted(found.values(), key=lambda row: (row[0], row[1], row[2], row[3]))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--gff", required=True, type=Path)
    parser.add_argument("--panel", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--padding", type=int, default=50)
    args = parser.parse_args()
    if args.padding < 0:
        parser.error("--padding must be non-negative")

    regions = extract_regions(args.gff, load_symbols(args.panel), args.padding)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="") as handle:
        for row in regions:
            handle.write("\t".join(map(str, row)) + "\n")
    print(f"wrote {len(regions)} public gene intervals")


if __name__ == "__main__":
    main()
