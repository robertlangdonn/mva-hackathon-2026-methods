#!/usr/bin/env python3
"""Build a controlled preliminary genome-wide coding/splice candidate screen."""

from __future__ import annotations

import argparse
import csv
import json
import subprocess
from collections import Counter, defaultdict
from pathlib import Path

try:
    from scripts.positive_control_rank import genotype_class, severity
except ModuleNotFoundError:  # Direct script execution.
    from positive_control_rank import genotype_class, severity


def basic_qc(gt_class: str, dp: str, gq: str, ad: str) -> bool:
    if dp in {"", "."} or gq in {"", "."}:
        return False
    try:
        depth, quality = int(dp), int(gq)
        values = [int(value) for value in ad.split(",")]
    except ValueError:
        return False
    if len(values) != 2 or any(value < 0 for value in values) or sum(values) == 0:
        return False
    balance = values[1] / sum(values[:2])
    if gt_class == "heterozygous":
        balance_ok = 0.2 <= balance <= 0.8
    elif gt_class == "hom_alt_or_hemizygous":
        balance_ok = balance >= 0.8
    else:
        return False
    return depth >= 10 and quality >= 20 and balance_ok


def clinvar_plp(significance: str) -> bool:
    value = significance.lower()
    return (
        "pathogenic" in value
        and "conflict" not in value
        and "uncertain" not in value
    )


def consequence_evidence(bcsq: str) -> list[dict[str, object]]:
    """Keep severity attached to its gene and transcript, including lower effects."""
    evidence = []
    for annotation in bcsq.split(','):
        fields = annotation.split('|')
        if len(fields) < 3 or not fields[1]:
            continue
        level, consequence = severity(annotation)
        evidence.append({
            'gene': fields[1], 'transcript': fields[2],
            'severity': level, 'consequence': consequence,
        })
    return evidence


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bcf", required=True, type=Path)
    parser.add_argument("--phenotype-ranking", required=True, type=Path)
    parser.add_argument("--panel", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    with args.phenotype_ranking.open(newline="", encoding="utf-8") as handle:
        hpo_rank = {row["gene"]: int(row["rank"]) for row in csv.DictReader(handle, delimiter="\t")}
    with args.panel.open(newline="", encoding="utf-8") as handle:
        panel = {row["gene"] for row in csv.DictReader(handle, delimiter="\t")}

    query = (
        "%CHROM\t%POS\t%REF\t%ALT\t%FILTER\t[%GT\t%DP\t%GQ\t%AD]"
        "\t%INFO/BCSQ\t%INFO/ALLELEID\t%INFO/CLNSIG\t%INFO/CLNREVSTAT\t%INFO/CLNDN\n"
    )
    process = subprocess.Popen(
        ["bcftools", "query", "-f", query, str(args.bcf)],
        stdout=subprocess.PIPE, text=True, encoding="utf-8",
    )
    assert process.stdout is not None
    fields = [
        "chrom", "pos", "ref", "alt", "filter", "gt", "dp", "gq", "ad",
        "genes", "severity", "consequence", "genotype_class", "hpo_best_rank",
        "clinvar_allele_id", "clinvar_significance", "clinvar_review_status",
        "clinvar_disease_names", "population_frequency_status", "consequence_evidence",
    ]
    counts: Counter[str] = Counter()
    gene_genotypes: dict[str, Counter[str]] = defaultdict(Counter)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        for line in process.stdout:
            values = line.rstrip("\n").split("\t")
            if len(values) != 14:
                raise ValueError("unexpected bcftools query column count")
            chrom, pos, ref, alt, filt, gt, dp, gq, ad, bcsq, allele_id, sig, review, disease = values
            level, consequence = severity(bcsq)
            gt_class = genotype_class(gt)
            if level < 2 or filt not in {"PASS", "."} or not basic_qc(gt_class, dp, gq, ad):
                continue
            evidence = consequence_evidence(bcsq)
            # Only protein-altering genes enter this coding screen's HPO/count summaries.
            genes = ','.join(sorted({str(item['gene']) for item in evidence if item['severity'] >= 2}))
            gene_list = [gene for gene in genes.split(",") if gene]
            ranks = [hpo_rank[gene] for gene in gene_list if gene in hpo_rank]
            best_rank = min(ranks) if ranks else None
            writer.writerow({
                "chrom": chrom, "pos": pos, "ref": ref, "alt": alt, "filter": filt,
                "gt": gt, "dp": dp, "gq": gq, "ad": ad, "genes": genes,
                "severity": level, "consequence": consequence,
                "genotype_class": gt_class,
                "hpo_best_rank": best_rank if best_rank is not None else ".",
                "clinvar_allele_id": allele_id, "clinvar_significance": sig,
                "clinvar_review_status": review, "clinvar_disease_names": disease,
                "population_frequency_status": "not_yet_annotated_genomewide",
                "consequence_evidence": json.dumps(evidence, separators=(',', ':')),
            })
            counts["review_rows"] += 1
            counts[f"filter_{'pass' if filt == 'PASS' else 'not_evaluated'}"] += 1
            counts[f"severity_{level}"] += 1
            counts[f"genotype_{gt_class}"] += 1
            if clinvar_plp(sig):
                counts["clinvar_plp_no_conflict"] += 1
            if best_rank is not None and best_rank <= 100:
                counts["hpo_top_100"] += 1
            if set(gene_list) & panel:
                counts["positive_control_panel"] += 1
            for gene in gene_list:
                gene_genotypes[gene][gt_class] += 1
    if process.wait() != 0:
        raise RuntimeError("bcftools query failed")

    counts["genes_with_hom_alt_or_hemizygous"] = sum(
        counter["hom_alt_or_hemizygous"] > 0 for counter in gene_genotypes.values()
    )
    counts["genes_with_two_or_more_heterozygous"] = sum(
        counter["heterozygous"] >= 2 for counter in gene_genotypes.values()
    )
    print("controlled preliminary genome-wide screen written")
    for key in sorted(counts):
        print(f"{key}={counts[key]}")


if __name__ == "__main__":
    main()
