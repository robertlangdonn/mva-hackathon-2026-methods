"""Resumable exact-range downloads. Production credentials/SSD checks live in caller.

Each request is conservatively charged in full before opening the connection.
Only fsynced, hashed byte ranges advance the checkpoint. An uncommitted suffix
of our own partial input is truncated on recovery, never accepted as complete.
"""
import hashlib
import json
import os
from pathlib import Path


class DownloadError(RuntimeError):
    pass


def atomic_json(path, value):
    path = Path(path)
    temp = path.with_name(path.name+'.tmp')
    with temp.open('w') as handle:
        json.dump(value, handle, indent=2)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp, path)
    fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


class Store:
    def __init__(self, folder, checkpoint, inputs, transfer_cap, opener,
                 guard=lambda: None, progress=lambda value: None,
                 chunk_size=64*1024**2):
        self.folder, self.checkpoint = Path(folder), Path(checkpoint)
        self.inputs, self.cap = inputs, transfer_cap
        self.opener, self.guard, self.progress = opener, guard, progress
        self.chunk_size = chunk_size
        self.guard()
        if chunk_size < 1 or transfer_cap < sum(x['size'] for x in inputs):
            raise DownloadError('invalid budget')
        if self.checkpoint.exists():
            self.state = json.loads(self.checkpoint.read_text())
            if self.state['inputs'] != inputs or self.state['transfer_cap'] != transfer_cap:
                raise DownloadError('input/budget checkpoint drift')
        else:
            if self.folder.exists() and any(self.folder.iterdir()):
                raise DownloadError('existing input folder without checkpoint')
            self.folder.mkdir(exist_ok=True)
            self.state = {'inputs': inputs, 'transfer_cap': transfer_cap,
                          'charged_bytes': 0, 'request_count': 0,
                          'files': [{'chunks': [], 'complete': False} for _ in inputs],
                          'recovered_uncommitted_bytes': 0}
            self.save()

    def save(self):
        atomic_json(self.checkpoint, self.state)

    def path(self, index):
        return self.folder/f'R{index+1}.fastq.gz'

    def recover(self, index):
        """Verify ALL committed chunks before discarding only an uncommitted tail."""
        self.guard()
        path, entry = self.path(index), self.state['files'][index]
        if path.is_symlink():
            raise DownloadError('symlink input refused')
        expected = sum(c['size'] for c in entry['chunks'])
        if not path.exists():
            if expected or entry['complete']:
                raise DownloadError('committed input missing')
            path.touch(mode=0o600, exist_ok=False)
        whole = hashlib.sha256()
        with path.open('rb') as handle:
            for chunk in entry['chunks']:
                self.guard()
                left = chunk['size']; hashed = hashlib.sha256()
                while left:
                    data = handle.read(min(left, 1024**2))
                    if not data:
                        raise DownloadError('committed input truncated')
                    whole.update(data); hashed.update(data); left -= len(data)
                if hashed.hexdigest() != chunk['sha256']:
                    raise DownloadError('committed input hash changed')
        if expected > self.inputs[index]['size']:
            raise DownloadError('checkpoint beyond input size')
        tail = path.stat().st_size-expected
        if tail < 0:
            raise DownloadError('partial input shorter than checkpoint')
        if tail:
            self.guard()
            with path.open('r+b') as handle:
                handle.truncate(expected); handle.flush(); os.fsync(handle.fileno())
            self.state['recovered_uncommitted_bytes'] += tail
            self.save()
        if entry['complete'] and (expected != self.inputs[index]['size'] or
                                  whole.hexdigest() != self.inputs[index]['sha256']):
            raise DownloadError('completed input mismatch')
        return expected, whole

    def download(self):
        for i, item in enumerate(self.inputs):
            offset, whole = self.recover(i)
            entry = self.state['files'][i]
            while offset < item['size']:
                self.guard()
                n = min(self.chunk_size, item['size']-offset)
                # 64 KiB additional charge per request allows conservative overhead.
                charge = n+65536
                if self.state['charged_bytes']+charge > self.cap:
                    raise DownloadError('transfer budget exhausted; approval required')
                self.state['charged_bytes'] += charge
                self.state['request_count'] += 1
                self.save()  # charge survives crash before/during HTTP request
                self.progress({'file': i+1, 'committed_bytes': offset,
                               'file_bytes': item['size'], 'charged_bytes': self.state['charged_bytes']})
                # Exceptions deliberately stop, no hidden retry loop.
                with self.opener(item['url'], offset, offset+n-1) as response:
                    if response.status != 206:
                        raise DownloadError('server ignored byte range; body not read')
                    if response.headers.get('Content-Range') != f'bytes {offset}-{offset+n-1}/{item["size"]}':
                        raise DownloadError('wrong Content-Range; body not read')
                    if response.headers.get('Content-Encoding', 'identity') != 'identity':
                        raise DownloadError('unexpected Content-Encoding; body not read')
                    if int(response.headers.get('Content-Length', '-1')) != n:
                        raise DownloadError('wrong Content-Length; body not read')
                    hashed = hashlib.sha256(); left = n
                    with self.path(i).open('r+b') as handle:
                        handle.seek(offset)
                        while left:
                            self.guard()
                            data = response.read(min(left, 1024**2))
                            if not data:
                                raise DownloadError('short range response')
                            handle.write(data)
                            whole.update(data); hashed.update(data); left -= len(data)
                        handle.flush(); os.fsync(handle.fileno())
                entry['chunks'].append({'size': n, 'sha256': hashed.hexdigest()})
                self.save()
                offset += n
            if whole.hexdigest() != item['sha256']:
                raise DownloadError('publisher SHA-256 mismatch; do not use input')
            entry['complete'] = True
            self.save()
        self.progress({'stage': 'INPUTS_VERIFIED', 'charged_bytes': self.state['charged_bytes'],
                       'downloaded_bytes': sum(x['size'] for x in self.inputs)})
