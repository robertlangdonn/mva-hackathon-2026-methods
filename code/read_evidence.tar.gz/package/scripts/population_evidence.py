"""Conservative local population evidence; absence of a sites row is not coverage."""
import math


def source_evidence(queried, row=None):
    if not queried:
        if row is not None:
            raise ValueError('a match requires a queried resource')
        return {'status': 'not_queried', 'af_grpmax': None}
    if row is None:
        return {'status': 'no_matching_allele_coverage_unknown', 'af_grpmax': None}
    result = dict(row)
    raw = row.get('af_grpmax')
    value = None if raw in (None, '', '.') else float(raw)
    if value is not None and (not math.isfinite(value) or not 0 <= value <= 1):
        raise ValueError('invalid allele-specific population frequency')
    result.update(status='matched_af_missing' if value is None else 'matched_af_available',
                  af_grpmax=value)
    return result


def combined_evidence(exomes, genomes):
    sources = (exomes, genomes)
    values = [s['af_grpmax'] for s in sources if s['af_grpmax'] is not None]
    maximum = max(values) if values else None
    if maximum is None:
        observed_band = 'no_observed_frequency'
    elif maximum >= 0.01:
        observed_band = 'common_ge_0.01'
    elif maximum >= 0.0001:
        observed_band = 'rare_lt_0.01'
    else:
        observed_band = 'ultra_rare_lt_0.0001'
    blockers = []
    for name, source in zip(('exomes', 'genomes'), sources):
        if source['status'] != 'matched_af_available':
            blockers.append(name + ':' + source['status'])
        if source['status'].startswith('matched'):
            if source.get('filter') != 'PASS':
                blockers.append(name + ':filter_not_pass')
            try:
                adequate_an = int(source.get('an', 0)) > 0
            except (ValueError, TypeError):
                adequate_an = False
            if not adequate_an:
                blockers.append(name + ':an_missing_or_zero')
    return {'max_observed_af_grpmax': maximum, 'observed_frequency_band': observed_band,
            'limitations': blockers,
            'interpretation': 'requires_review' if blockers else 'frequency_observed_in_both'}
