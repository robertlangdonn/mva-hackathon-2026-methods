"""Join verified full-input evidence without pooling counts or inferring phase."""
import argparse
from collections import Counter
import json
import os
from pathlib import Path
import time
from scripts.interim_read_support import CONTROL
from scripts.usage_break_checkpoint import ROOT,digest
from scripts.bounded_read_download import atomic_json


def merge(snv,indel,complete):
    expected=complete['journal_sha256']
    for report in (snv,indel):
        if report['captured_journal_sha256']!=expected:
            raise ValueError('snapshot mismatch')
        if report['summary']['snapshot_pairs']!=complete['total_pairs'] or report['summary']['snapshot_chunks']!=complete['chunks']:
            raise ValueError('incomplete input')
    if snv['plan_sha256']!=indel['pins']['plan.json'] or snv['scope_sha256']!=indel['pins']['scope-contract.json']:
        raise ValueError('plan/scope mismatch')
    additions={tuple(r['key']):r for r in indel['sites']}
    if len(additions)!=len(indel['sites']):raise ValueError('duplicate indel key')
    rows=[]; seen=set()
    for original in snv['sites']:
        key=tuple(original['key'])
        if key in seen:raise ValueError('duplicate SNV key')
        seen.add(key);row=dict(original)
        if original['status']=='UNASSESSED_NON_SNV':
            supplement=additions.pop(key)
            row['indel_review']=supplement
            if supplement['eligibility']!='READY':row['combined_status']='UNASSESSED_REPEAT_OR_UNSUPPORTED'
            else:
                f=supplement['evidence']['fragment_name_counts']
                row['combined_status']=('ALT_OBSERVED_PROVISIONAL' if f.get('ALT',0) else
                    'AMBIGUOUS_OBSERVATIONS' if f.get('AMBIGUOUS',0) or f.get('CONFLICT',0) else
                    'REF_ONLY_IN_SNAPSHOT' if f.get('REF',0) else 'NO_INFORMATIVE_OBSERVATION')
        else:row['combined_status']=original['status']
        rows.append(row)
    if additions:raise ValueError('unmatched indel keys')
    return rows


def read_report(folder):
    folder=folder.resolve(strict=True)
    if not folder.is_relative_to((ROOT/'data/intermediate').resolve()) or (folder/'INCOMPLETE').exists():
        raise ValueError('invalid report folder')
    m=json.loads((folder/'manifest.json').read_text())
    if set(m['artifacts'])!={'result.json','journal-snapshot.json'}:raise ValueError('artifact set')
    for n,h in m['artifacts'].items():
        if (folder/n).is_symlink() or digest(folder/n)!=h:raise ValueError('report hash mismatch')
    report=json.loads((folder/'result.json').read_text())
    if report['captured_journal_sha256']!=digest(CONTROL/'journal.json'):raise ValueError('current journal mismatch')
    if json.loads((folder/'journal-snapshot.json').read_text())!=json.loads((CONTROL/'journal.json').read_text()):
        raise ValueError('saved journal mismatch')
    return report


def main():
    os.umask(0o077)
    p=argparse.ArgumentParser();p.add_argument('snv',type=Path);p.add_argument('indel',type=Path);a=p.parse_args()
    complete=json.loads((CONTROL/'complete.json').read_text())
    if complete['journal_sha256']!=digest(CONTROL/'journal.json'):raise ValueError('completion drift')
    snv,indel=read_report(a.snv),read_report(a.indel)
    rows=merge(snv,indel,complete)
    summary=dict(sites=len(rows),site_statuses=dict(Counter(r['combined_status'] for r in rows)),
        snapshot_pairs=complete['total_pairs'],snapshot_chunks=complete['chunks'],
        phase_established=False,causality_established=False,ranks_changed=False,old_counts_pooled=False)
    out=ROOT/'data/intermediate'/f'full-read-review-{time.time_ns()}';out.mkdir();(out/'INCOMPLETE').touch()
    atomic_json(out/'result.json',dict(summary=summary,sites=rows,
        completion_sha256=digest(CONTROL/'complete.json'),journal_sha256=complete['journal_sha256'],
        inputs={str(a.snv):digest(a.snv/'result.json'),str(a.indel):digest(a.indel/'result.json')},
        script_sha256=digest(Path(__file__))))
    atomic_json(out/'manifest.json',{'artifacts':{'result.json':digest(out/'result.json')}})
    (out/'INCOMPLETE').unlink()
    print(json.dumps(summary));print('private_report',out/'result.json')
    for gene in ('BUB1B','ZNF418','CRYAA','PRODH','DGCR6','HLA-C','HLA-DQA1','MRPL23'):
        selected=[r for r in rows if gene in r.get('genes',[])]
        if selected:print(json.dumps({'gene':gene,'site_states':dict(Counter(r['combined_status'] for r in selected))}))


if __name__=='__main__':main()
