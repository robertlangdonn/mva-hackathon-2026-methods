"""Synthetic-tested ranking adapter. No CLI or automatic patient execution.

Input variants must be freshly exported from the full normalized annotated BCF,
not the preliminary filtered screen. Metadata and HPO views are supplied by an
audited caller. Production export/coverage authorization is intentionally absent.
"""
from collections import Counter
from itertools import zip_longest
import hashlib
import json
import math
from pathlib import Path

from scripts.population_evidence import combined_evidence
from scripts.ranking_policy import (qc_reasons, frequency_lane, transcript_effects,
                                    review_sort_key)

CHROMS = [str(i) for i in range(1, 23)] + ['X', 'Y']
ROOT = Path(__file__).resolve().parents[1]
VAR_FIELDS = {'chrom', 'pos', 'ref', 'alt', 'gt', 'dp', 'gq', 'ad', 'filter', 'bcsq'}
POP_FIELDS = {'chrom', 'pos', 'ref', 'alt', 'exomes', 'genomes',
              'max_observed_af_grpmax', 'observed_frequency_band',
              'limitations', 'interpretation'}


def key(row):
    if (row['chrom'] not in CHROMS or type(row['pos']) is not int or row['pos'] < 1
            or not isinstance(row['ref'], str) or not row['ref']
            or not isinstance(row['alt'], str) or not row['alt'] or ',' in row['alt']):
        raise ValueError('invalid canonical normalized key')
    return (CHROMS.index(row['chrom']), row['pos'], row['ref'], row['alt'])


def checked(rows, fields):
    previous_pos, seen = None, set()
    for row in rows:
        if set(row) != fields:
            raise ValueError('input schema drift')
        k = key(row)
        if previous_pos is not None and k[:2] < previous_pos:
            raise ValueError('unsorted input')
        if k[:2] != previous_pos:
            seen.clear()
        if k in seen:
            raise ValueError('duplicate normalized allele')
        seen.add(k)
        previous_pos = k[:2]
        yield row


def positional_groups(rows):
    """Buffer one position so ALT record order need not match between inputs."""
    from itertools import groupby
    for position, group in groupby(rows, key=lambda r: key(r)[:2]):
        yield position, {key(row): row for row in group}


def aligned(variants, population):
    left = positional_groups(checked(variants, VAR_FIELDS))
    right = positional_groups(checked(population, POP_FIELDS))
    for a, b in zip_longest(left, right):
        if a is None or b is None or a[0] != b[0] or a[1].keys() != b[1].keys():
            raise ValueError('missing or extra population allele')
        for k in sorted(a[1]):
            variant, pop = a[1][k], b[1][k]
            for source in (pop['exomes'], pop['genomes']):
                validate_source(source)
            # Recompute derived fields rather than trusting cached interpretation.
            combined = combined_evidence(pop['exomes'], pop['genomes'])
            if any(pop[name] != value for name, value in combined.items()):
                raise ValueError('inconsistent population summary')
            yield variant, pop


def validate_source(source):
    status, af = source['status'], source['af_grpmax']
    allowed = {'not_queried', 'no_matching_allele_coverage_unknown',
               'matched_af_missing', 'matched_af_available', 'matched_multiple_records'}
    if status not in allowed:
        raise ValueError('unknown population status')
    if af is not None and (not math.isfinite(af) or not 0 <= af <= 1):
        raise ValueError('invalid source AF')
    if (status == 'matched_af_available') != (af is not None) and status != 'matched_multiple_records':
        raise ValueError('inconsistent source AF status')
    if status == 'matched_multiple_records':
        records = source['records']
        if len(records) < 2 or any(r['status'] == status for r in records):
            raise ValueError('invalid duplicate source evidence')
        for record in records:
            validate_source(record)
        values = [r['af_grpmax'] for r in records if r['af_grpmax'] is not None]
        if af != (max(values) if values else None):
            raise ValueError('inconsistent duplicate maximum')


def ploidy_at(row, intervals):
    """Intervals: explicit 1-based inclusive bounds; absent coverage is unknown.

    Production caller must pin source/build and audit PAR/karyotype assumptions.
    There is no sex inference and no hardcoded PAR table in this adapter.
    """
    matches = []
    for region in intervals:
        if (region['chrom'] not in CHROMS or region['start'] < 1
                or region['end'] < region['start'] or region['ploidy'] not in (1, 2)):
            raise ValueError('invalid ploidy interval')
        if region['chrom'] == row['chrom'] and region['start'] <= row['pos'] <= region['end']:
            matches.append(region['ploidy'])
    if len(matches) > 1:
        raise ValueError('overlapping ploidy intervals')
    return matches[0] if matches else None


def adapt(variants, population, policy, transcripts, ploidy_intervals):
    """Yield auditable per-effect/per-setting rows, preserving all exclusions."""
    settings = {'baseline': policy['baseline']}
    settings.update({name: dict(policy['baseline'], **overrides)
                     for name, overrides in policy['sensitivity_overrides'].items()})
    for variant, pop in aligned(variants, population):
        effects = transcript_effects(variant['bcsq'])
        supported = all(set(variant[field]) <= set('ACGTN') for field in ('ref', 'alt'))
        for setting_name, setting in settings.items():
            reasons = qc_reasons(variant['gt'], variant['dp'], variant['gq'], variant['ad'],
                                 setting, ploidy_at(variant, ploidy_intervals))
            if not supported:
                reasons = reasons + ['unsupported_allele_class']
            if not effects:
                reasons = reasons + ['no_resolved_protein_altering_effect']
            if any('+' in e.split('|')[-1] for e in variant['bcsq'].split(',')):
                reasons = reasons + ['linked_haplotype_effect_manual_review']
            filt = ('pass' if variant['filter'] == 'PASS' else
                    'not_evaluated' if variant['filter'] == '.' else 'filtered')
            for (gene, tx), severity in sorted(effects.items()) or [(('', ''), 0)]:
                meta = transcripts.get(tx)
                if meta is not None and (meta['gene'] != gene or type(meta['preferred']) is not bool):
                    raise ValueError('transcript metadata mismatch')
                for view in policy['transcript_views']:
                    why = list(reasons)
                    if view == 'mane_select_or_gencode_primary':
                        if meta is None:
                            why.append('preferred_transcript_unknown')
                        elif not meta['preferred']:
                            why.append('nonpreferred_transcript')
                    gt = variant['gt'].replace('|', '/')
                    model = ('haploid_alt' if gt == '1' else 'homozygous_alt' if gt == '1/1'
                             else 'heterozygous_hypothesis' if gt in ('0/1', '1/0') else 'unsupported')
                    stable = json.dumps([variant[x] for x in ('chrom', 'pos', 'ref', 'alt')]
                                        + [gene, tx], separators=(',', ':'))
                    yield {'stable_id': stable, 'setting': setting_name, 'transcript_view': view,
                           'gene': gene, 'transcript': tx, 'severity': severity,
                           'model': model, 'filter_lane': filt, 'reasons': why,
                           'frequency_lane': frequency_lane(pop, setting['max_af']),
                           'population_limitations': list(pop['limitations']),
                           'phase': 'unresolved'}


def ordered_views(rows, hpo_views):
    """Small review table only; preserves model/FILTER/settings as separate lanes.

    HPO scores are supplied per gene; caller must provide all declared LOTO views.
    Higher score sorts earlier, only after frequency/consequence evidence tiers.
    """
    rows = list(rows)
    results = {}
    for name, scores in {'disabled': {}, **hpo_views}.items():
        if name == 'disabled' and scores:
            raise ValueError('disabled phenotype view must have no scores')
        if any(not math.isfinite(s) for s in scores.values()):
            raise ValueError('nonfinite phenotype score')
        def order(row):
            tier = review_sort_key(row)
            score = scores.get(row['gene'])
            return (row['setting'], row['transcript_view'], row['model'], row['filter_lane'],
                    bool(row['reasons']), tier[:2], score is None,
                    -score if score is not None else 0, tier[2])
        results[name] = sorted(rows, key=order)
    return results


def write_bundle(directory, rows, provenance, controlled_root=None):
    """Exclusive directory, incomplete marker and hashes; interruption stays visible.

    controlled_root is a fixture injection for tests. No production CLI exposed.
    """
    root = (controlled_root or ROOT / 'data/intermediate').resolve()
    target = Path(directory).resolve()
    if target == root or not target.is_relative_to(root):
        raise ValueError('output must be under controlled intermediate storage')
    target.mkdir()  # exclusive: never overwrite an earlier or interrupted bundle
    marker = target / 'INCOMPLETE'
    marker.touch(exist_ok=False)
    digest, counts = hashlib.sha256(), Counter()
    with (target / 'review.jsonl').open('xb') as handle:
        for row in rows:
            raw = (json.dumps(row, sort_keys=True, allow_nan=False) + '\n').encode()
            handle.write(raw)
            digest.update(raw)
            counts['rows'] += 1
            counts['requires_review' if row['reasons'] else 'qc_eligible'] += 1
        handle.flush()
        import os
        os.fsync(handle.fileno())
    manifest = {'status': 'adapter_complete_not_causal_validation', 'counts': dict(counts),
                'output_sha256': digest.hexdigest(), 'provenance': provenance}
    with (target / 'manifest.json').open('x') as handle:
        json.dump(manifest, handle, sort_keys=True, allow_nan=False)
        handle.flush()
        os.fsync(handle.fileno())
    marker.unlink()
    return manifest
