"""Bounded streaming identity check; not FASTA validation or reference acquisition."""
import hashlib
import time

MAX_REFERENCE_BYTES=6*1024**3
BLOCK_BYTES=1024**2


def streaming_digest(path, *, byte_limit, expected_bytes=None, seconds=300):
    if type(byte_limit) is not int or not 0<byte_limit<=MAX_REFERENCE_BYTES:
        raise ValueError('invalid reference byte budget')
    before=path.stat()
    if not 0<before.st_size<=byte_limit or (expected_bytes is not None and before.st_size!=expected_bytes):
        raise ValueError('reference size/budget mismatch')
    started=time.monotonic();total=0;h=hashlib.sha256()
    with path.open('rb') as handle:
        while True:
            if time.monotonic()-started>seconds:raise ValueError('reference hashing time budget exceeded')
            block=handle.read(BLOCK_BYTES)
            if not block:break
            total+=len(block)
            if total>byte_limit:raise ValueError('reference grew beyond budget')
            h.update(block)
    after=path.stat()
    if total!=before.st_size or (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns):
        raise ValueError('reference changed while hashing')
    return h.hexdigest()
