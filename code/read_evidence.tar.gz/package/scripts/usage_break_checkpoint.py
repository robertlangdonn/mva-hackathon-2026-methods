"""Seal/check selected checkpoint files locally; no jobs, network or AI calls."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SEAL=ROOT/'data/intermediate/usage-break-20260913.json'


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda:handle.read(1024*1024),b''): h.update(block)
    return h.hexdigest()


def verify(root, records):
    for name, expected in records.items():
        path=(root/name).resolve()
        if not path.is_relative_to(root.resolve()): raise ValueError('path outside project')
        if not path.is_file() or digest(path)!=expected: return False
    return True


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seal',action='store_true');args=parser.parse_args()
    if args.seal:
        paths=[ROOT/'docs/RESUME-AFTER-USAGE-RESET.md',
               ROOT/'data/intermediate/offline-completion.json',ROOT/'data/intermediate/ranking-control.json',
               ROOT/'data/intermediate/challenge-file-inventory-20260913.json',
               ROOT/'data/cache/gnomad-genomes-all-sites-an-inventory-20260913.json']
        evidence=ROOT/'data/intermediate/candidate-evidence-20260913'
        paths.extend(evidence/n for n in ('manifest.json','calls.json','configuration-evidence-review.json',
            'shared-transcript-audit.json','condition-assertion-match-v2.json','phase-resource-audit.json'))
        paths.extend(ROOT/'scripts'/n for n in ('usage_break_checkpoint.py','audit_phase_resources.py',
            'inventory_public_an.py','inventory_challenge_files.py','audit_shared_transcripts.py',
            'match_public_clinvar_locally.py','review_configuration_evidence.py','fetch_public_gene_clinvar.py'))
        records={str(p.relative_to(ROOT)):digest(p) for p in paths}
        with SEAL.open('x') as handle: json.dump({'files':records,'scope':'selected checkpoint files; not full genome audit'},handle,indent=2)
    data=json.loads(SEAL.read_text());ok=verify(ROOT,data['files'])
    print('CHECKPOINT_OK' if ok else 'CHECKPOINT_CHANGED_OR_MISSING: inspect locally; do not restart pipelines automatically')
    print('No jobs launched. No network or AI calls. Scope: selected checkpoint files, not all genomic inputs.')
    if not ok: raise SystemExit(1)


if __name__=='__main__': main()
