"""Durable controls, event journal and derived tracker for the population run."""
from contextlib import contextmanager
import fcntl
import json
import os
from pathlib import Path
import plistlib
import shutil
import subprocess
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data/intermediate'
VOLUME = Path('/Volumes/MVA_WORK')


def read_json(path, default=None):
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        return {} if default is None else default


def atomic_json(path, value):
    atomic_text(path, json.dumps(value, indent=2) + '\n')


def atomic_text(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp-' + uuid.uuid4().hex)
    with temporary.open('x') as handle:
        handle.write(value)
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(path)


def event(kind, **details):
    DATA.mkdir(parents=True, exist_ok=True)
    payload = (json.dumps(dict(time=time.time(), event=kind, **details)) + '\n').encode()
    fd = os.open(DATA / 'population-events.jsonl', os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    try:
        os.write(fd, payload)
        os.fsync(fd)
    finally:
        os.close(fd)


@contextmanager
def exclusive(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield handle


def running():
    try:
        with exclusive(DATA / 'population-worker.lock'):
            return False
    except BlockingIOError:
        return True


def paused():
    return read_json(DATA / 'population-control.json').get('paused', False)


def volume_uuid():
    if not VOLUME.is_mount():
        raise RuntimeError('MVA_WORK is not mounted; reconnect the SSD')
    result = subprocess.run(['diskutil', 'info', '-plist', str(VOLUME)],
                            capture_output=True, check=True)
    value = plistlib.loads(result.stdout).get('VolumeUUID')
    if not value:
        raise RuntimeError('cannot identify the SSD volume UUID')
    return value


def ensure_volume():
    actual = volume_uuid()
    path = DATA / 'population-volume.json'
    identity = read_json(path)
    if identity and identity['uuid'] != actual:
        raise RuntimeError('MVA_WORK volume identity changed; refuse the wrong drive')
    if not identity:
        atomic_json(path, {'uuid': actual, 'registered_unix': time.time()})
    return actual


def quarantine(paths, parent):
    existing = [p for p in paths if p.exists()]
    if not existing:
        return None
    destination = parent / 'interrupted' / (time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8])
    destination.mkdir(parents=True)
    for path in existing:
        if path.is_symlink() or path.parent.resolve() != parent.resolve():
            raise ValueError('unexpected interrupted artifact path')
        path.rename(destination / path.name)
    event('incomplete_stage_preserved', path=str(destination), files=len(existing))
    return destination


def snapshot():
    state = read_json(DATA / 'population-run-state.json')
    worker = read_json(DATA / 'population-worker.json')
    live = running()
    mounted = VOLUME.is_mount()
    status = ('pausing' if live else 'paused') if paused() else (
        'running' if live else 'complete' if state.get('stage') == 'complete_remaining_chromosomes'
        else 'interrupted / stopped')
    rows = []
    for chrom in [str(i) for i in range(1, 23)] + ['X', 'Y']:
        config = read_json(ROOT / f'config/population/chr{chrom}.json')
        dest = VOLUME / f'public-resources/gnomad/chr{chrom}'
        result = DATA / f'chr{chrom}.population.jsonl'
        manifest = read_json(result.with_suffix('.manifest.json'))
        done = result.exists() and manifest.get('status') == 'joined_match_counts_oracle_verified'
        specs = config.get('files', [])
        total = sum(s['size'] for s in specs)
        present = 0
        if mounted:
            for spec in specs:
                path = dest / Path(spec['name']).name
                part = path.with_name(path.name + '.part')
                chosen = path if path.exists() else part
                try:
                    present += min(chosen.stat().st_size, spec['size'])
                except FileNotFoundError:
                    pass
        phase = 'join verified' if done else state.get('stage', 'queued') if state.get('chromosome') == chrom else 'queued'
        rows.append({'chromosome': chrom, 'phase': phase, 'done': done,
                     'bytes': total if done else present, 'total': total,
                     'rows': manifest.get('counts', {}).get('rows', 0) if done else None})
    return {'status': status, 'worker_live': live, 'mounted': mounted, 'state': state,
            'log': worker.get('log'), 'updated': time.time(), 'chromosomes': rows,
            'free': shutil.disk_usage(VOLUME).free if mounted else None}


def render_tracker():
    data = snapshot()
    rows = data['chromosomes']
    total = sum(r['total'] for r in rows)
    received = sum(r['bytes'] for r in rows)
    lines = ['# MVA research tracker', '',
             f"Updated: {time.strftime('%Y-%m-%d %H:%M:%S')} (local time)", '',
             f"**Run: {data['status']}** · SSD: {'connected' if data['mounted'] else 'DISCONNECTED'}", '',
             f"Chromosome joins verified: **{sum(r['done'] for r in rows)}/24**", '',
             f"Source bytes acquired/retired: **{received/1024**3:.2f} / {total/1024**3:.2f} GiB**", '',
             'This is download progress, not scientific completion. Verified sources may have been evicted.', '',
             f"SSD free: {data['free']/1024**3:.1f} GiB" if data['free'] is not None else 'Reconnect the original MVA_WORK SSD before resuming.', '',
             '## Research milestones', '',
             '| Work | Status |', '|---|---|']
    for milestone in read_json(ROOT / 'config/research-milestones.json', []):
        status = milestone['status']
        if milestone['id'] == 'population':
            status = f"{sum(r['done'] for r in rows)}/24 chromosome joins verified"
        lines.append(f"| {milestone['label']} | {status} |")
    lines += ['', '## Chromosomes', '', '| Chr | Stage | Source GiB | Joined rows |', '|---|---|---:|---:|']
    for row in rows:
        lines.append(f"| {row['chromosome']} | {row['phase']} | {row['bytes']/1024**3:.2f} / {row['total']/1024**3:.2f} | {row['rows'] if row['rows'] is not None else '—'} |")
    lines += ['', '## Controls and logs', '',
              'Double-click **MVA Pause.command**, **MVA Resume.command**, or **MVA Status.command** in the project folder.', '',
              'Pause remains in force across restarts and automation checks. Wait for “paused” before ejecting/shutting down.', '',
              f"Latest worker log: `{data['log'] or 'no managed run yet'}`", '',
              'Event journal: `data/intermediate/population-events.jsonl`',
              'Checkpoint: `data/intermediate/population-run-state.json`', '',
              'Recovery preserves unfinished stage outputs under `interrupted/`; integrity failures stop for review.',
              'This tracker is derived from checkpoints/files; it is not hand-maintained.']
    text = '\n'.join(lines) + '\n'
    atomic_text(DATA / 'population-tracker.md', text)
    return text
