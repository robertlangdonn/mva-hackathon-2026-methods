"""SSD-only cached-read pilot with guarded, resumable stage boundaries."""
import argparse
import fcntl
import json
import os
import plistlib
import shutil
import signal
import statistics
import subprocess
import sys
import time
import zlib
from pathlib import Path
from scripts.usage_break_checkpoint import ROOT,digest
from scripts.read_prefix_pilot import parse_prefix,compare,DECODE_LIMIT

VOLUME=Path('/Volumes/MVA_WORK')
SSD=VOLUME/'mva-alignment-pilot-20260927'
CONTROL=ROOT/'data/intermediate/ssd-alignment-pilot-control'
CAP=20_000_000_000
RSS_CAP=10*1024**3
COMMIT='b92993c1161e73167181558856567ef2f367e3f0'


def write(path,value):
    tmp=path.with_name(path.name+'.tmp')
    with tmp.open('w') as h:json.dump(value,h,indent=2);h.flush();os.fsync(h.fileno())
    tmp.replace(path)


def identity():
    if not VOLUME.is_mount():raise RuntimeError('SSD missing; reconnect registered drive')
    r=subprocess.run(['diskutil','info','-plist',str(VOLUME)],capture_output=True,check=True)
    expected=json.loads((ROOT/'data/intermediate/population-volume.json').read_text())['uuid']
    if plistlib.loads(r.stdout).get('VolumeUUID')!=expected:raise RuntimeError('wrong SSD identity')


def usage():
    return sum(p.stat().st_size for p in SSD.rglob('*') if p.is_file() and not p.is_symlink())


def guard():
    identity()
    if (CONTROL/'pause').exists():raise RuntimeError('pause requested; partial stage retained')
    if usage()>CAP-1024**3:raise RuntimeError('pilot disk budget reserve reached')
    if shutil.disk_usage(SSD).free<5*1024**3:raise RuntimeError('SSD free-space reserve reached')


def state(stage,**kwargs):
    write(CONTROL/'status.json',{'stage':stage,'updated_unix':time.time(),'controller_pid':os.getpid(),**kwargs})


def run_stage(stage,cmd,cwd,stdout_path=None):
    guard();start=time.time();peak=0
    with (cwd/f'{stage}.log').open('ab') as log:
        output=stdout_path.open('wb') if stdout_path else log
        proc=subprocess.Popen(cmd,cwd=cwd,stdout=output,stderr=log,start_new_session=True)
        try:
            while proc.poll() is None:
                guard()
                r=subprocess.run(['ps','-o','rss=','-p',str(proc.pid)],capture_output=True,text=True)
                rss=int(r.stdout.strip() or 0)*1024;peak=max(peak,rss)
                if rss>RSS_CAP:raise RuntimeError('10 GiB resident-memory cap exceeded')
                if time.time()-start>8*3600:raise RuntimeError('8-hour stage runtime cap exceeded')
                state(stage,child_pid=proc.pid,elapsed_seconds=time.time()-start,peak_rss_bytes=peak,ssd_bytes=usage())
                time.sleep(3)
            if proc.returncode:raise RuntimeError(stage+' failed; inspect SSD stage log locally')
        finally:
            if proc.poll() is None:
                os.killpg(proc.pid,signal.SIGTERM)
                try:proc.wait(timeout=10)
                except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
            if stdout_path:output.close()
    return {'wall_seconds':time.time()-start,'sampled_peak_rss_bytes':peak}


def complete_prefix(raw):
    remaining=raw;chunks=[];size=0
    while remaining:
        decoder=zlib.decompressobj(16+zlib.MAX_WBITS)
        block=decoder.decompress(remaining,DECODE_LIMIT-size+1);size+=len(block)
        if size>DECODE_LIMIT or decoder.unconsumed_tail:raise ValueError('decode cap')
        chunks.append(block)
        if not decoder.eof:break
        remaining=decoder.unused_data
    lines=b''.join(chunks).split(b'\n')[:-1]
    return [b'\n'.join(lines[i:i+4])+b'\n' for i in range(0,len(lines)-3,4)]


def valid_stage(folder,manifest):
    if not manifest.exists():return False
    data=json.loads(manifest.read_text())
    if any(not (folder/n).is_file() or digest(folder/n)!=h for n,h in data['artifacts'].items()):
        raise RuntimeError('completed stage hash mismatch; do not rebuild over it')
    return True


def work():
    CONTROL.mkdir(exist_ok=True);guard()
    source=SSD/'bwa-source';bwa=source/'bwa'
    revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
    if revision!=COMMIT or not bwa.is_file():raise RuntimeError('pinned aligner missing')
    toolhash=digest(bwa)
    ref=ROOT/'data/cache/ensembl-116/Homo_sapiens.GRCh38.dna.primary_assembly.fa'
    expected=json.loads((ROOT/'data/intermediate/znf418-reference-20260926.json').read_text())['sha256']['reference']
    reference=SSD/'reference.fa'
    state('reference_verification')
    if digest(ref)!=expected:raise RuntimeError('reference source changed')
    if not reference.exists():
        partial=SSD/f'reference-{time.time_ns()}.partial'
        with ref.open('rb') as src,partial.open('xb') as dst:
            while block:=src.read(32*1024**2):guard();dst.write(block)
            dst.flush();os.fsync(dst.fileno())
        if digest(partial)!=expected:raise RuntimeError('SSD copy hash mismatch')
        partial.rename(reference)
    if digest(reference)!=expected:raise RuntimeError('SSD reference changed')
    index_marker=SSD/'index-complete.json'
    if index_marker.exists():
        meta=json.loads(index_marker.read_text());index=SSD/meta['attempt']
        if not valid_stage(index,index/'manifest.json'):raise RuntimeError('index completion manifest missing')
        if meta['reference_sha256']!=expected or meta['bwa_sha256']!=toolhash:raise RuntimeError('index provenance mismatch')
    else:
        guard();index=SSD/f'index-{time.time_ns()}';index.mkdir()
        metrics=run_stage('index',[str(bwa),'index','-a','bwtsw','-p',str(index/'grch38'),str(reference)],index)
        required=['grch38'+s for s in ('.amb','.ann','.bwt','.pac','.sa')]
        if any(not (index/n).is_file() or (index/n).stat().st_size==0 for n in required):raise RuntimeError('missing index output')
        write(index/'manifest.json',{'artifacts':{n:digest(index/n) for n in required},'metrics':metrics})
        write(index_marker,{'attempt':index.name,'reference_sha256':expected,'bwa_sha256':toolhash})
    cached=ROOT/'data/intermediate/read-prefix-20260923-multigzip'
    sources=json.loads((cached/'sources.json').read_text());payloads=[];parsed=[]
    for i in (1,2):
        p=cached/f'R{i}.prefix.gz'
        if digest(p)!=sources['sources'][i-1]['prefix_sha256']:raise RuntimeError('cached reads changed')
        raw=p.read_bytes();payloads.append(raw);parsed.append(parse_prefix(raw))
    pairs=compare(*parsed)['matched_read_pairs']
    if (SSD/'pilot-complete.json').exists():
        meta=json.loads((SSD/'pilot-complete.json').read_text());folder=SSD/meta['attempt']
        if not valid_stage(folder,folder/'manifest.json'):raise RuntimeError('pilot completion manifest missing')
        provenance=json.loads((folder/'manifest.json').read_text())
        if provenance['reference_sha256']!=expected or provenance['bwa_sha256']!=toolhash or provenance['cached_sources_sha256']!=digest(cached/'sources.json'):
            raise RuntimeError('completed pilot provenance mismatch')
        state('COMPLETE',summary=meta['summary']);return
    guard();folder=SSD/f'pilot-{time.time_ns()}';folder.mkdir()
    for i,raw in enumerate(payloads,1):
        with (folder/f'R{i}.fastq').open('xb') as h:
            for record in complete_prefix(raw)[:pairs]:h.write(record)
    metrics=run_stage('alignment',[str(bwa),'mem','-t','2',str(index/'grch38'),str(folder/'R1.fastq'),str(folder/'R2.fastq')],folder,folder/'alignment.sam')
    counts={'primary':0,'mapped':0,'proper_pair_reads':0,'MAPQ_ge20':0};inserts=[]
    with (folder/'alignment.sam').open() as h:
        for line in h:
            if line.startswith('@'):continue
            f=line.rstrip().split('\t');flag=int(f[1])
            if flag & (0x100|0x800):continue
            counts['primary']+=1
            if not flag&4:
                counts['mapped']+=1
                if int(f[4])>=20:counts['MAPQ_ge20']+=1
            if flag&2:
                counts['proper_pair_reads']+=1
                if flag&64 and int(f[8])!=0:inserts.append(abs(int(f[8])))
    if counts['primary']!=2*pairs:raise RuntimeError('primary alignment count mismatch')
    guard()
    summary={'pairs':pairs,**counts,**metrics,'proper_pair_insert_observations':len(inserts),
        'median_proper_pair_abs_template_length':statistics.median(inserts) if inserts else None,
        'patient_variant_validation':False,'primary_assembly_only':True,'prefix_not_representative':True}
    write(folder/'manifest.json',{'summary':summary,'reference_sha256':expected,'bwa_sha256':toolhash,
        'index_manifest_sha256':digest(index/'manifest.json'),
        'cached_sources_sha256':digest(cached/'sources.json'),'script_sha256':digest(Path(__file__)),
        'artifacts':{n:digest(folder/n) for n in ('R1.fastq','R2.fastq','alignment.sam','alignment.log')}})
    write(SSD/'pilot-complete.json',{'attempt':folder.name,'summary':summary})
    state('COMPLETE',summary=summary,ssd_bytes=usage())


def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['start','worker','pause','status']);a=p.parse_args()
    CONTROL.mkdir(exist_ok=True)
    if a.action=='pause':(CONTROL/'pause').touch();print('Pause requested; stage restart may be necessary');return
    if a.action=='status':
        print((CONTROL/'status.json').read_text() if (CONTROL/'status.json').exists() else 'not started');return
    if a.action=='start':
        guard_without_pause=CONTROL/'pause'
        if guard_without_pause.exists():guard_without_pause.unlink()
        identity()
        old=json.loads((CONTROL/'status.json').read_text()) if (CONTROL/'status.json').exists() else {}
        pid=old.get('controller_pid')
        if pid:
            cmd=subprocess.run(['ps','-p',str(pid),'-o','command='],capture_output=True,text=True).stdout
            if 'scripts.ssd_alignment_pilot worker' in cmd:raise RuntimeError('worker already active')
        with (CONTROL/'worker.log').open('ab') as log:
            proc=subprocess.Popen([sys.executable,'-m','scripts.ssd_alignment_pilot','worker'],cwd=ROOT,stdout=log,stderr=log,start_new_session=True)
        write(CONTROL/'status.json',{'stage':'STARTING','controller_pid':proc.pid,'updated_unix':time.time()});print('SSD pilot worker started');return
    with (CONTROL/'worker.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        def interrupted(signum,frame):raise RuntimeError('controller interrupted')
        signal.signal(signal.SIGTERM,interrupted)
        try:work()
        except BaseException as error:
            state('STOPPED',reason=str(error));raise


if __name__=='__main__':main()
