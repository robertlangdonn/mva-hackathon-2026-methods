#!/usr/bin/env python3
"""Create a controlled, consequence-first review table for the MVA gene panel."""

from __future__ import annotations

import argparse
import csv
import subprocess
from collections import Counter
from pathlib import Path


HIGH = {"frameshift", "splice_acceptor", "splice_donor", "start_lost", "stop_gained", "stop_lost"}
MODERATE = {"inframe_deletion", "inframe_insertion", "missense", "protein_altering"}


def severity(annotations: str) -> tuple[int, str]:
    terms = {
        term
        for annotation in annotations.split(",")
        for term in annotation.split("|", 1)[0].split("&")
        if term
    }
    high = sorted(terms & HIGH)
    if high:
        return 3, ",".join(high)
    moderate = sorted(terms & MODERATE)
    if moderate:
        return 2, ",".join(moderate)
    return 1, ",".join(sorted(terms))


def genotype_class(gt: str) -> str:
    alleles = gt.replace("|", "/").split("/")
    called = [allele for allele in alleles if allele not in {"", "."}]
    if not called:
        return "missing"
    if len(called) != len(alleles):
        return "partial_missing"
    if len(alleles) > 2:
        return "unsupported_ploidy"
    if any(allele not in {"0", "1"} for allele in called):
        return "other"
    if all(allele == "1" for allele in called):
        return "hom_alt_or_hemizygous"
    if "1" in called and "0" in called:
        return "heterozygous"
    if all(allele == "0" for allele in called):
        return "hom_ref_after_split"
    return "other"


def genes_from_bcsq(annotations: str) -> str:
    genes = set()
    for annotation in annotations.split(","):
        fields = annotation.split("|")
        if len(fields) > 1 and fields[1]:
            genes.add(fields[1])
    return ",".join(sorted(genes))


def population_frequency_status(af_grpmax: str) -> str:
    if af_grpmax in {"", "."}:
        return "absent_from_gnomad_exomes"
    maximum = max(float(value) for value in af_grpmax.split(",") if value != ".")
    if maximum < 0.0001:
        return "ultra_rare_lt_0.0001"
    if maximum < 0.01:
        return "rare_lt_0.01"
    return "common_ge_0.01"


def combined_population_status(exome_af_grpmax: str, genome_af_grpmax: str) -> str:
    values = []
    for raw in (exome_af_grpmax, genome_af_grpmax):
        values.extend(float(value) for value in raw.split(",") if value not in {"", "."})
    if not values:
        return "absent_from_gnomad_exomes_and_genomes"
    maximum = max(values)
    if maximum < 0.0001:
        return "ultra_rare_lt_0.0001"
    if maximum < 0.01:
        return "rare_lt_0.01"
    return "common_ge_0.01"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bcf", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    query = (
        "%CHROM\t%POS\t%REF\t%ALT\t%FILTER\t[%GT\t%DP\t%GQ\t%AD\t%PGT\t%PID]"
        "\t%INFO/BCSQ\t%INFO/ALLELEID\t%INFO/CLNSIG\t%INFO/CLNREVSTAT"
        "\t%INFO/CLNDN\t%INFO/CLNDISDB\t%INFO/GNOMAD_AF"
        "\t%INFO/GNOMAD_AF_grpmax\t%INFO/GNOMAD_AC\t%INFO/GNOMAD_AN"
        "\t%INFO/GNOMAD_nhomalt\t%INFO/GNOMAD_faf95_max"
        "\t%INFO/GNOMAD_GENOMES_AF\t%INFO/GNOMAD_GENOMES_AF_grpmax"
        "\t%INFO/GNOMAD_GENOMES_AC\t%INFO/GNOMAD_GENOMES_AN"
        "\t%INFO/GNOMAD_GENOMES_nhomalt\t%INFO/GNOMAD_GENOMES_faf95_max\n"
    )
    process = subprocess.Popen(
        ["bcftools", "query", "-f", query, str(args.bcf)],
        stdout=subprocess.PIPE,
        text=True,
        encoding="utf-8",
    )
    assert process.stdout is not None
    args.output.parent.mkdir(parents=True, exist_ok=True)
    counts: Counter[str] = Counter()
    fields = [
        "chrom", "pos", "ref", "alt", "filter", "gt", "dp", "gq", "ad", "pgt", "pid",
        "gene", "severity", "consequence", "genotype_class", "phase_status",
        "bcsq_annotations",
        "clinvar_allele_id", "clinvar_significance", "clinvar_review_status",
        "clinvar_disease_names", "clinvar_disease_ids",
        "gnomad_exomes_af", "gnomad_exomes_af_grpmax", "gnomad_exomes_ac",
        "gnomad_exomes_an", "gnomad_exomes_nhomalt", "gnomad_exomes_faf95_max",
        "gnomad_genomes_af", "gnomad_genomes_af_grpmax", "gnomad_genomes_ac",
        "gnomad_genomes_an", "gnomad_genomes_nhomalt", "gnomad_genomes_faf95_max",
        "population_frequency_status",
    ]
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        for line in process.stdout:
            values = line.rstrip("\n").split("\t")
            if len(values) != 29:
                raise ValueError("unexpected bcftools query column count")
            (
                chrom, pos, ref, alt, filt, gt, dp, gq, ad, pgt, pid, annotations,
                allele_id, clin_sig, clin_review, clin_disease, clin_disease_ids,
                gnomad_af, gnomad_af_grpmax, gnomad_ac, gnomad_an,
                gnomad_nhomalt, gnomad_faf95_max,
                genomes_af, genomes_af_grpmax, genomes_ac, genomes_an,
                genomes_nhomalt, genomes_faf95_max,
            ) = values
            level, consequence = severity(annotations)
            gt_class = genotype_class(gt)
            if level < 2 or gt_class in {"missing", "hom_ref_after_split"}:
                continue
            phase_status = "phased" if "|" in gt else "unphased_or_homozygous"
            writer.writerow({
                "chrom": chrom, "pos": pos, "ref": ref, "alt": alt, "filter": filt,
                "gt": gt, "dp": dp, "gq": gq, "ad": ad, "pgt": pgt, "pid": pid,
                "gene": genes_from_bcsq(annotations), "severity": level,
                "consequence": consequence, "genotype_class": gt_class,
                "phase_status": phase_status,
                "bcsq_annotations": annotations,
                "clinvar_allele_id": allele_id,
                "clinvar_significance": clin_sig,
                "clinvar_review_status": clin_review,
                "clinvar_disease_names": clin_disease,
                "clinvar_disease_ids": clin_disease_ids,
                "gnomad_exomes_af": gnomad_af,
                "gnomad_exomes_af_grpmax": gnomad_af_grpmax,
                "gnomad_exomes_ac": gnomad_ac,
                "gnomad_exomes_an": gnomad_an,
                "gnomad_exomes_nhomalt": gnomad_nhomalt,
                "gnomad_exomes_faf95_max": gnomad_faf95_max,
                "gnomad_genomes_af": genomes_af,
                "gnomad_genomes_af_grpmax": genomes_af_grpmax,
                "gnomad_genomes_ac": genomes_ac,
                "gnomad_genomes_an": genomes_an,
                "gnomad_genomes_nhomalt": genomes_nhomalt,
                "gnomad_genomes_faf95_max": genomes_faf95_max,
                "population_frequency_status": combined_population_status(
                    gnomad_af_grpmax, genomes_af_grpmax
                ),
            })
            counts["review_rows"] += 1
            counts[f"severity_{level}"] += 1
            counts[f"genotype_{gt_class}"] += 1
            counts["pass" if filt in {"PASS", "."} else "filtered"] += 1
            counts["clinvar_exact_match" if allele_id != "." else "clinvar_no_exact_match"] += 1
            counts[f"population_{combined_population_status(gnomad_af_grpmax, genomes_af_grpmax)}"] += 1
    if process.wait() != 0:
        raise RuntimeError("bcftools query failed")
    print("controlled review table written")
    for key in sorted(counts):
        print(f"{key}={counts[key]}")


if __name__ == "__main__":
    main()
