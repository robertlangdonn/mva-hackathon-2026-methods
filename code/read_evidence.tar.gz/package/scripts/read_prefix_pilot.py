"""Bounded local FASTQ prefix pilot. No allele queries, uploads or full downloads."""
import argparse
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request
import zlib
from collections import Counter
from pathlib import Path

from scripts.usage_break_checkpoint import ROOT, digest
from scripts.build_review_packet import save

PREFIX_BYTES = 1024 * 1024
DECODE_LIMIT = 16 * 1024 * 1024


class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urllib.parse.urlsplit(newurl)
        host = parsed.hostname or ''
        if parsed.scheme != 'https' or not any(host == d or host.endswith('.' + d) for d in ('huggingface.co', 'hf.co')):
            raise ValueError('redirect destination outside approved download hosts')
        new = super().redirect_request(req, fp, code, msg, headers, newurl)
        if host != urllib.parse.urlsplit(req.full_url).hostname:
            new.remove_header('Authorization')
        return new


def token():
    value = os.environ.get('HF_TOKEN')
    if value:
        return value.strip()
    base = Path(os.environ.get('HF_HOME', str(Path.home() / '.cache/huggingface')))
    path = Path(os.environ.get('HF_TOKEN_PATH', str(base / 'token')))
    return path.read_text().strip() if path.is_file() else None


def request(url, range_header=None):
    headers = {'Accept-Encoding': 'identity'}
    credential = token()
    if credential:
        headers['Authorization'] = 'Bearer ' + credential
    if range_header:
        headers['Range'] = range_header
    return urllib.request.build_opener(SafeRedirect()).open(urllib.request.Request(url, headers=headers), timeout=30)


def check_range(status, headers, count, total):
    if status != 206 or headers.get('Content-Range') != f'bytes 0-{count-1}/{total}':
        raise ValueError('server did not honor exact bounded range; body not read')
    if headers.get('Content-Encoding', 'identity') != 'identity':
        raise ValueError('unexpected HTTP content encoding')


def parse_prefix(compressed):
    remaining = compressed
    chunks = []; size = 0
    while remaining:
        decoder = zlib.decompressobj(16 + zlib.MAX_WBITS)
        chunk = decoder.decompress(remaining, DECODE_LIMIT - size + 1)
        size += len(chunk)
        if size > DECODE_LIMIT or decoder.unconsumed_tail:
            raise ValueError('decompression budget exceeded')
        chunks.append(chunk)
        if not decoder.eof:
            break
        remaining = decoder.unused_data
    raw = b''.join(chunks)
    # Partial gzip suffix/FASTQ record is expected. Never treat this as a complete file.
    lines = raw.split(b'\n')[:-1]
    records = []
    for offset in range(0, len(lines) - 3, 4):
        h, seq, plus, qual = [v.rstrip(b'\r') for v in lines[offset:offset+4]]
        if not h.startswith(b'@') or not plus.startswith(b'+') or not seq or len(seq) != len(qual):
            raise ValueError('invalid FASTQ record')
        if any(b not in b'ACGTNacgtn' for b in seq) or any(not 33 <= b <= 126 for b in qual):
            raise ValueError('unexpected sequence/quality alphabet')
        fields = h[1:].split()
        identifier = fields[0]
        mate = None
        if identifier.endswith((b'/1', b'/2')):
            mate = int(identifier[-1:]); identifier = identifier[:-2]
        if len(fields) > 1 and fields[1][:2] in (b'1:', b'2:'):
            illumina_mate = int(fields[1][:1])
            if mate is not None and mate != illumina_mate:
                raise ValueError('conflicting read mate labels')
            mate = illumina_mate
        records.append((identifier, mate, len(seq)))
    if not records:
        raise ValueError('no complete FASTQ records')
    return records


def compare(left, right):
    n = min(len(left), len(right))
    if not n or any(a[0] != b[0] for a, b in zip(left, right)):
        raise ValueError('prefix read identifiers do not match')
    if any(a[1] not in (None, 1) or b[1] not in (None, 2) for a, b in zip(left, right)):
        raise ValueError('unexpected mate orientation')
    return {'matched_read_pairs': n, 'mate_labels_explicit_for_all': all(a[1] == 1 and b[1] == 2 for a,b in zip(left,right)),
            'R1_length_counts': dict(Counter(r[2] for r in left[:n])),
            'R2_length_counts': dict(Counter(r[2] for r in right[:n]))}


def select_pair(files):
    candidates = []
    by_name = {f['rfilename']: f for f in files}
    for name in sorted(by_name):
        if not name.endswith(('.fastq.gz', '.fq.gz')):
            continue
        match = re.search(r'([._-])R?(1)(?=([._-]|\.f(?:ast)?q\.gz$))', name)
        if match:
            mate = name[:match.start(2)] + '2' + name[match.end(2):]
            if mate in by_name:
                candidates.append((by_name[name], by_name[mate]))
    if not candidates:
        raise ValueError('no filename-paired inputs')
    return candidates[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['readme', 'pilot'])
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--cached-attempt')
    args = parser.parse_args()
    if not args.attempt.isalnum():
        raise ValueError('alphanumeric attempt required')
    if args.cached_attempt and (not args.cached_attempt.isalnum() or args.mode != 'pilot'):
        raise ValueError('cached pilot attempt must be alphanumeric')
    meta = ROOT / 'data/intermediate/read-metadata-refresh-20260921-network/repository.json'
    data = json.loads(meta.read_text())
    out = ROOT / f'data/intermediate/read-prefix-20260923-{args.attempt}'
    out.mkdir(); (out / 'INCOMPLETE').touch()
    base = 'https://huggingface.co/datasets/SageBio/mva-hackathon-2026-data/resolve/' + data['sha'] + '/'
    if args.mode == 'readme':
        with request(base + 'README.md') as response:
            raw = response.read(1_000_001)
        if len(raw) > 1_000_000:
            raise ValueError('README budget exceeded')
        (out / 'README.md').write_bytes(raw)
        result = {'readme_bytes': len(raw), 'readme_sha256': digest(out / 'README.md')}
    else:
        decoded = []; sources = []
        cached = ROOT / f'data/intermediate/read-prefix-20260923-{args.cached_attempt}' if args.cached_attempt else None
        if cached:
            if (cached / 'INCOMPLETE').exists():
                raise ValueError('cannot reuse incomplete attempt')
            cached_sources = json.loads((cached / 'sources.json').read_text())
            if cached_sources['metadata_sha256'] != digest(meta):
                raise ValueError('cached metadata mismatch')
        for index, entry in enumerate(select_pair(data['siblings'])):
            total = entry.get('size') or entry.get('lfs', {}).get('size')
            if not isinstance(total, int) or total < PREFIX_BYTES:
                raise ValueError('missing or insufficient source size')
            url = base + urllib.parse.quote(entry['rfilename'], safe='/')
            if cached:
                cached_path = cached / f'R{index+1}.prefix.gz'
                expected = cached_sources['sources'][index]
                if expected['name'] != entry['rfilename'] or expected['prefix_sha256'] != digest(cached_path):
                    raise ValueError('cached prefix mismatch')
                payload = cached_path.read_bytes()
            else:
                with request(url, f'bytes=0-{PREFIX_BYTES-1}') as response:
                    check_range(response.status, response.headers, PREFIX_BYTES, total)
                    payload = response.read(PREFIX_BYTES)
            if len(payload) != PREFIX_BYTES:
                raise ValueError('short prefix response')
            path = out / f'R{index+1}.prefix.gz'
            path.write_bytes(payload)
            sources.append({'name': entry['rfilename'], 'total_bytes': total, 'prefix_sha256': digest(path)})
            decoded.append(parse_prefix(payload))
        result = compare(*decoded)
        result.update(compressed_bytes_read=2*PREFIX_BYTES, full_file_integrity_verified=False,
                      network_read_bytes=0 if cached else 2*PREFIX_BYTES,
                      sample_identity_verified=False, fragment_length_known=False, phase_established=False)
        save(out / 'sources.json', {'sources': sources, 'metadata_sha256': digest(meta), 'revision': data['sha']})
    result.update(script_sha256=digest(Path(__file__)))
    save(out / 'summary.json', result)
    (out / 'INCOMPLETE').unlink()
    print(json.dumps(result))


if __name__ == '__main__':
    try:
        main()
    except urllib.error.HTTPError as exc:
        raise SystemExit(f'HTTP {exc.code}; no automatic auth changes or retries; preserve incomplete attempt')
    except urllib.error.URLError:
        raise SystemExit('Network unavailable; preserve incomplete attempt')
