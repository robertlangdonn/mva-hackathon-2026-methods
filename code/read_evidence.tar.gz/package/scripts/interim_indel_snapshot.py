"""Private, read-only corrected-snapshot indel review. Aggregate-only stdout."""
from collections import Counter
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import time

from scripts import simple_indel_support as assessor
from scripts.interim_read_support import CONTROL, DATA
from scripts.ssd_alignment_pilot import SSD, identity
from scripts.usage_break_checkpoint import ROOT, digest
from scripts.bounded_read_download import atomic_json


def reference_contexts(path, keys, expected, guard):
    """Hash exact FASTA bytes while extracting only bounded target contexts.

    No unverified FAI, subprocess coordinates, or external transfer.
    """
    regions = {}
    for key in keys:
        chrom,pos,ref,alt = key
        if max(len(ref),len(alt)) > 1000:
            raise RuntimeError('allele-size inventory cap')
        regions[key] = (max(1,pos-64),pos+len(ref)+64)
    chunks = {k: [] for k in keys}
    relevant = []; offset = 0; seen = set(); h = hashlib.sha256()
    carry = b''
    def consume(line):
        nonlocal relevant, offset
        line = line.rstrip(b'\r')
        if line.startswith(b'>'):
            chrom = line[1:].split()[0].decode('ascii')
            relevant = [k for k in keys if k[0] == chrom]
            if relevant and chrom in seen:
                raise RuntimeError('duplicate reference contig')
            seen.add(chrom); offset = 0
            return
        length = len(line)
        for key in relevant:
            lo,hi = regions[key]
            a,b = max(lo-1,offset),min(hi,offset+length)
            if a < b:
                chunks[key].append(line[a-offset:b-offset])
        offset += length
    with path.open('rb') as handle:
        while block := handle.read(8*1024*1024):
            guard(); h.update(block)
            lines = (carry+block).split(b'\n'); carry = lines.pop()
            for line in lines:
                consume(line)
        if carry:
            consume(carry)
    if h.hexdigest() != expected:
        raise RuntimeError('reference hash mismatch')
    return {k:(b''.join(v).decode('ascii').upper(),regions[k][0]) for k,v in chunks.items()}


def inventory(keys, contexts, windows):
    rows=[]; targets={}
    for ordinal,key in enumerate(keys,1):
        chrom,pos,ref,alt=key
        context,start=contexts[key]
        if not context:
            raise RuntimeError('missing reference context')
        target,reason=assessor.prepare(chrom,pos,ref,alt,context,start)
        if target is not None and not any(c==chrom and lo<=target.low and hi>=target.high
                                         for c,lo,hi in windows):
            raise RuntimeError('eligible target outside retained scope')
        if target is not None:
            targets[ordinal]=target
        rows.append(dict(ordinal=ordinal,key=key,eligibility=reason,
                         representation='original unchanged; only anchored non-shiftable simple indels eligible'))
    return rows,targets


def verified_folders(journal, plan, plan_hash, data, guard, byte_cap=250_000_000):
    previous=0; size=0; folders=[]
    if not journal:
        raise RuntimeError('empty journal')
    for receipt in journal:
        guard()
        end=min(previous+plan['chunk_pairs'],plan['total_pairs'])
        if receipt['start_pairs']!=previous or receipt['end_pairs']!=end or end<=previous:
            raise RuntimeError('noncontiguous or invalid chunk boundary')
        name=receipt['folder']
        if not re.fullmatch(r'chunk-\d{6}-\d+',name):
            raise RuntimeError('unsafe folder')
        folder=data/name; manifest_path=folder/'manifest.json'
        if folder.is_symlink() or manifest_path.is_symlink() or digest(manifest_path)!=receipt['manifest_sha256']:
            raise RuntimeError('manifest mismatch')
        manifest=json.loads(manifest_path.read_text())
        if set(manifest['artifacts']) != {'selected.sam.gz','result.json','alignment.log'}:
            raise RuntimeError('incomplete artifact set')
        for name,expected in manifest['artifacts'].items():
            guard(); path=folder/name; size+=path.stat().st_size
            if size>byte_cap:
                raise RuntimeError('snapshot byte cap')
            if path.is_symlink() or digest(path)!=expected:
                raise RuntimeError('artifact mismatch')
        result=json.loads((folder/'result.json').read_text())
        if result['plan_sha256']!=plan_hash or any(result[k]!=receipt[k] for k in ('start_pairs','end_pairs','offsets')):
            raise RuntimeError('chunk provenance mismatch')
        folders.append(folder);previous=end
    return folders,previous


def evaluate(folders, targets, guard):
    results={}
    for ordinal,target in targets.items():
        def lines():
            total=0
            for folder in folders:
                with gzip.open(folder/'selected.sam.gz','rt') as handle:
                    for n,line in enumerate(handle):
                        if n%1024==0:guard()
                        total+=len(line)
                        if total>100_000_000:
                            raise RuntimeError('decompressed per-target cap')
                        if line.startswith('@'):continue
                        # Retained evidence also contains unrelated mates. Only
                        # feed same-contig alignments to the bounded assessor.
                        f=line.split('\t',3)
                        if len(f)<4:raise RuntimeError('truncated SAM')
                        if f[2]==target.chrom:yield line
        results[ordinal]=assessor.summarize(lines(),target)
    return results


def main():
    os.umask(0o077);os.nice(10);started=time.monotonic()
    def guard():
        if time.monotonic()-started>300:raise RuntimeError('five-minute cap')
    identity()
    pins={n:digest(CONTROL/n) for n in ('plan.json','focus.json','scope-contract.json')}
    plan=json.loads((CONTROL/'plan.json').read_text())
    contract=json.loads((CONTROL/'scope-contract.json').read_text())
    if pins['focus.json']!=plan['focus'] or digest(ROOT/'scripts/corrected_pair_alignment.py')!=contract['wrapper_sha256']:
        raise RuntimeError('scope drift')
    for name,expected in plan['sources'].items():
        if Path(name).name!=name or digest(ROOT/'scripts'/name)!=expected:
            raise RuntimeError('alignment source drift')
    focus=json.loads((CONTROL/'focus.json').read_text())
    allkeys={tuple(k) for row in focus for k in row['packet']['members']}
    if len(contract['required_sites'])!=2 or not {tuple(k) for k in contract['required_sites']}<=allkeys:
        raise RuntimeError('lead scope missing')
    keys=sorted(k for k in allkeys if not(len(k[2])==len(k[3])==1 and k[2] in 'ACGT' and k[3] in 'ACGT'))
    if len(keys)!=8:raise RuntimeError('inventory scope changed')
    journal_raw=(CONTROL/'journal.json').read_bytes();journal=json.loads(journal_raw)
    out=ROOT/'data/intermediate'/f'interim-indel-snapshot-{time.time_ns()}'
    out.mkdir();(out/'INCOMPLETE').touch()
    atomic_json(out/'journal-snapshot.json',journal)
    contexts=reference_contexts(SSD/'reference.fa',keys,plan['reference'],guard)
    rows,targets=inventory(keys,contexts,plan['windows'])
    folders,pairs=verified_folders(journal,plan,pins['plan.json'],DATA,guard)
    results=evaluate(folders,targets,guard)
    for row in rows:
        row['evidence']=results.get(row['ordinal'],{'status':'UNASSESSED'})
    guard();identity()
    if any(digest(CONTROL/n)!=v for n,v in pins.items()):raise RuntimeError('control drift during audit')
    summary=dict(sites=len(keys),eligibility=dict(Counter(r['eligibility'] for r in rows)),
                 assessed_sites=len(targets),snapshot_chunks=len(journal),snapshot_pairs=pairs,
                 provisional=True,phase_established=False,ranks_changed=False)
    atomic_json(out/'result.json',dict(summary=summary,sites=rows,pins=pins,
        captured_journal_sha256=hashlib.sha256(journal_raw).hexdigest(),
        reference_sha256=plan['reference'],
        sources={n:digest(ROOT/'scripts'/n) for n in ('interim_indel_snapshot.py','simple_indel_support.py')},
        limitations=['Nonrandom incomplete prefix; no negative causal inference.',
                     'Names are not independent molecules; no phase or clinical classification.',
                     'Overlapping snapshots supersede, never sum. Unsupported sites remain unassessed.']))
    atomic_json(out/'manifest.json',{'artifacts':{n:digest(out/n) for n in ('result.json','journal-snapshot.json')}})
    (out/'INCOMPLETE').unlink()
    print(json.dumps(summary))
    print('private_report',out/'result.json')


if __name__=='__main__':
    # Fail closed without leaking coordinates, sequences or tool stderr.
    try:main()
    except Exception as exc:
        print('AUDIT_STOPPED',type(exc).__name__,'No completed receipt; inspect locally without exposing controlled data.')
        raise SystemExit(1)
