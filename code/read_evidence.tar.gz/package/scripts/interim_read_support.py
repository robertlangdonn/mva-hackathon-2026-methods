"""Read-only snapshot SNV support audit; private results, safe aggregate stdout.

Not a variant caller, duplicate marker, phaser or clinical classifier.
"""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import re
import time
import os
from scripts.bounded_read_download import atomic_json
from scripts.usage_break_checkpoint import ROOT, digest
from scripts.ssd_alignment_pilot import SSD, identity

CONTROL = ROOT/'data/intermediate/corrected-pair-alignment-control'
DATA = SSD/'corrected-pair-20261008'
MQ = 20
BQ = 20


def base_at(fields, target):
    """SAM SEQ is already alignment-oriented; never reverse-complement it again."""
    seq, qual = fields[9:11]
    if seq == '*' or qual == '*':
        return None
    if len(seq) != len(qual):
        raise ValueError('SAM sequence/quality length mismatch')
    tokens = re.findall(r'(\d+)([MIDNSHP=X])', fields[5])
    if not tokens or ''.join(n+op for n, op in tokens) != fields[5] or any(int(n) < 1 for n, _ in tokens):
        raise ValueError('invalid CIGAR')
    if sum(int(n) for n, op in tokens if op in 'MIS=X') != len(seq):
        raise ValueError('CIGAR query length mismatch')
    ref = int(fields[3]); query = 0; found = None
    for n, op in tokens:
        n = int(n)
        if op in 'M=X' and ref <= target < ref+n:
            offset = query+target-ref
            quality = ord(qual[offset])-33
            if not 0 <= quality <= 93:
                raise ValueError('invalid base quality')
            found = (seq[offset].upper(), quality, min(offset, len(seq)-1-offset))
        if op in 'MDN=X':
            ref += n
        if op in 'MIS=X':
            query += n
    return found


def new_site():
    return {'observations': Counter(), 'fragments': {}, 'bq': [], 'mq': [],
            'alt_forward_reads': 0, 'alt_reverse_reads': 0, 'alt_near_read_end': 0,
            'covered_primary_reads': 0, 'filtered_mapq': 0, 'filtered_baseq': 0}


def scan(lines, targets, sites, guard):
    by_chrom = defaultdict(list)
    for k in targets:
        if len(k[2]) == len(k[3]) == 1 and k[2] in 'ACGT' and k[3] in 'ACGT':
            by_chrom[k[0]].append(k)
    for n, line in enumerate(lines):
        if n % 4096 == 0:
            guard()
        if line.startswith('@'):
            continue
        f = line.rstrip('\n').split('\t')
        if len(f) < 11:
            raise ValueError('truncated SAM')
        flag = int(f[1])
        if flag & (4 | 256 | 512 | 1024 | 2048):
            continue
        for key in by_chrom.get(f[2], []):
            obs = base_at(f, key[1])
            if obs is None:
                continue
            site = sites[key]; site['covered_primary_reads'] += 1
            base, quality, end_distance = obs; mq = int(f[4])
            if not MQ <= mq < 255:
                site['filtered_mapq'] += 1; continue
            if quality < BQ:
                site['filtered_baseq'] += 1; continue
            label = 'REF' if base == key[2] else 'ALT' if base == key[3] else 'OTHER'
            site['observations'][label] += 1
            labels = site['fragments'].setdefault(f[0], set()); labels.add(label)
            if len(site['fragments']) > 10_000:
                raise RuntimeError('fragment-name cap exceeded')
            site['bq'].append(quality); site['mq'].append(mq)
            if len(site['bq']) > 50_000:
                raise RuntimeError('observation cap exceeded')
            if label == 'ALT':
                site['alt_reverse_reads' if flag & 16 else 'alt_forward_reads'] += 1
                site['alt_near_read_end'] += end_distance < 5


def summarize(key, site):
    if len(key[2]) != 1 or len(key[3]) != 1 or key[2] not in 'ACGT' or key[3] not in 'ACGT':
        return {'status': 'UNASSESSED_NON_SNV'}
    fragments = Counter(next(iter(v)) if len(v) == 1 else 'CONFLICT' for v in site['fragments'].values())
    if fragments['ALT']:
        status = 'ALT_OBSERVED_PROVISIONAL'
    elif fragments['OTHER'] or fragments['CONFLICT']:
        status = 'AMBIGUOUS_OBSERVATIONS'
    elif fragments['REF']:
        status = 'REF_ONLY_IN_SNAPSHOT'
    else:
        status = 'NO_PASSING_BASE_OBSERVATION'
    return dict(status=status, read_observations=dict(site['observations']),
        fragment_name_counts={k: fragments[k] for k in ('REF', 'ALT', 'OTHER', 'CONFLICT')},
        covered_primary_reads=site['covered_primary_reads'], filtered_mapq=site['filtered_mapq'],
        filtered_baseq=site['filtered_baseq'],
        passing_bq_range=[min(site['bq']), max(site['bq'])] if site['bq'] else None,
        passing_mq_range=[min(site['mq']), max(site['mq'])] if site['mq'] else None,
        alt_forward_read_observations=site['alt_forward_reads'],
        alt_reverse_read_observations=site['alt_reverse_reads'],
        alt_within_five_bases_of_sequenced_read_end=site['alt_near_read_end'])


def main():
    os.umask(0o077)
    os.nice(10)
    started = time.monotonic()
    def guard():
        if time.monotonic()-started > 300:
            raise RuntimeError('five-minute audit cap')
    identity()
    raw = (CONTROL/'journal.json').read_bytes()
    journal = json.loads(raw)
    if not journal:
        raise RuntimeError('no completed chunks')
    plan = json.loads((CONTROL/'plan.json').read_text())
    if digest(CONTROL/'focus.json') != plan['focus']:
        raise RuntimeError('focus hash mismatch')
    contract = json.loads((CONTROL/'scope-contract.json').read_text())
    if digest(ROOT/'scripts/corrected_pair_alignment.py') != contract['wrapper_sha256']:
        raise RuntimeError('scope wrapper drift')
    for name, expected in plan['sources'].items():
        if digest(ROOT/'scripts'/name) != expected:
            raise RuntimeError('alignment source drift')
    focus = json.loads((CONTROL/'focus.json').read_text())
    keys = sorted({tuple(k) for row in focus for k in row['packet']['members']})
    genes = defaultdict(set)
    for row in focus:
        for k in row['packet']['members']:
            genes[tuple(k)].add(row['packet']['gene'])
    leads = {tuple(k) for k in contract['required_sites']}
    if len(leads) != 2 or not leads <= set(keys):
        raise RuntimeError('lead scope missing')
    sites = {k: new_site() for k in keys}
    output = ROOT/'data/intermediate'/f'interim-read-support-{time.time_ns()}'
    output.mkdir(); (output/'INCOMPLETE').touch()
    atomic_json(output/'journal-snapshot.json', journal)
    previous = 0; scanned_bytes = 0
    for receipt in journal:
        guard()
        if receipt['start_pairs'] != previous or not previous < receipt['end_pairs'] <= previous+plan['chunk_pairs']:
            raise RuntimeError('noncontiguous snapshot')
        name = receipt['folder']
        if not re.fullmatch(r'chunk-\d{6}-\d+', name):
            raise RuntimeError('invalid retained folder')
        folder = DATA/name
        if folder.is_symlink() or (folder/'manifest.json').is_symlink() or digest(folder/'manifest.json') != receipt['manifest_sha256']:
            raise RuntimeError('manifest mismatch')
        manifest = json.loads((folder/'manifest.json').read_text())
        if set(manifest['artifacts']) != {'selected.sam.gz', 'result.json', 'alignment.log'}:
            raise RuntimeError('incomplete or unexpected artifact set')
        for artifact, expected in manifest['artifacts'].items():
            path = folder/artifact
            scanned_bytes += path.stat().st_size
            if scanned_bytes > 250_000_000:
                raise RuntimeError('250 MB snapshot input cap')
            if path.is_symlink() or digest(path) != expected:
                raise RuntimeError('retained artifact mismatch')
        result = json.loads((folder/'result.json').read_text())
        if result['plan_sha256'] != digest(CONTROL/'plan.json') or any(result[k] != receipt[k] for k in ('start_pairs', 'end_pairs', 'offsets')):
            raise RuntimeError('chunk provenance mismatch')
        with gzip.open(folder/'selected.sam.gz', 'rt') as handle:
            scan(handle, keys, sites, guard)
        previous = receipt['end_pairs']
    results = [dict(key=k, genes=sorted(genes[k]), **summarize(k, sites[k])) for k in keys]
    statuses = dict(Counter(r['status'] for r in results))
    summary = dict(snapshot_chunks=len(journal), snapshot_pairs=previous, total_pairs=plan['total_pairs'],
        sites=len(keys), site_statuses=statuses, provisional=True, phase_established=False,
        duplicate_marking_performed=False, ranks_changed=False)
    policy = dict(mapq_min=MQ, mapq_255_excluded=True, baseq_min=BQ,
        excluded_flags=[4, 256, 512, 1024, 2048],
        overlap_policy='same QNAME at same site counted once; disagreeing passing observations become CONFLICT',
        non_snv='unassessed, never counted as unsupported',
        limitations=['Nonrandom incomplete prefix; no negative causal inference.',
            'Fragment names are not independent molecules; no PCR/optical duplicate discovery.',
            'No indel realignment, phase, genotype likelihoods or statistical strand-bias test.',
            'Hard/soft clipping and alternate reference representations remain limitations.',
            'Existing duplicate flags are excluded; BWA alone does not mark duplicates.'])
    atomic_json(output/'result.json', dict(summary=summary, policy=policy, sites=results,
        plan_sha256=digest(CONTROL/'plan.json'), scope_sha256=digest(CONTROL/'scope-contract.json'),
        captured_journal_sha256=hashlib.sha256(raw).hexdigest(), script_sha256=digest(Path(__file__))))
    atomic_json(output/'manifest.json', {'artifacts': {n: digest(output/n) for n in ('result.json', 'journal-snapshot.json')}})
    (output/'INCOMPLETE').unlink()
    print(json.dumps(summary))
    print('private_report',str(output/'result.json'))
    for ordinal, key in enumerate(sorted(leads), 1):
        print(json.dumps(dict(gene='BUB1B', site_ordinal=ordinal, **summarize(key, sites[key]))))


if __name__ == '__main__':
    main()
