"""Ranking-only process controls. Resume restarts incomplete attempts, preserving them."""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import uuid

from scripts import population_runtime as rt
from scripts.population_control import group_members
from scripts.run_ranking import sha

STATE = rt.DATA / 'ranking-control.json'
LOCK = rt.DATA / 'ranking-supervisor.lock'
WORKER = rt.DATA / 'ranking-managed-worker.json'
BASE = rt.DATA / 'ranking-20260912.json'


def live():
    try:
        with rt.exclusive(LOCK):
            return False
    except BlockingIOError:
        return True


def started(pid):
    return subprocess.check_output(['ps', '-p', str(pid), '-o', 'lstart='], text=True).strip()


def stop_child(meta):
    """Never signal a reused PID. Orphan groups require a known input anchor."""
    pgid = meta.get('pid')
    if not pgid:
        return
    members = group_members(pgid)
    if not members:
        return
    leader = next((cmd for pid, cmd in members if pid == pgid), None)
    if leader:
        if (started(pgid) != meta['started'] or 'scripts.run_ranking' not in leader
                or meta['contract'] not in leader):
            raise RuntimeError('unrecognized ranking PID; refusing signal')
    elif not any(meta['bcf'] in cmd for _, cmd in members):
        raise RuntimeError('unrecognized orphan group; review required')
    allowed = {'Python', 'python3', 'python3.14', 'bcftools', 'caffeinate'}
    if any(Path(cmd.split()[0]).name not in allowed for _, cmd in members):
        raise RuntimeError('unexpected process in ranking group')
    for sig, limit in ((signal.SIGINT, 6), (signal.SIGTERM, 4), (signal.SIGKILL, 2)):
        if not group_members(pgid):
            return
        os.killpg(pgid, sig)
        deadline = time.monotonic() + limit
        while time.monotonic() < deadline:
            if not group_members(pgid):
                return
            time.sleep(.1)
    raise RuntimeError('ranking child group did not stop')


def verify_complete(output):
    output = Path(output)
    if (output / 'INCOMPLETE').exists() or not (output / 'manifest.json').exists():
        return False
    manifest = json.loads((output / 'manifest.json').read_text())
    if manifest['status'] != 'complete_review_not_causal_validation':
        raise ValueError('unexpected completion status')
    required = {'audit.jsonl', 'stability.json', 'configurations/review.jsonl', 'configurations/manifest.json'}
    if set(manifest['artifacts']) != required:
        raise ValueError('incomplete artifact inventory')
    for name, digest in manifest['artifacts'].items():
        if sha(output / name) != digest:
            raise ValueError('completed output hash mismatch')
    return True


def stop_reason(paused, mounted, same_device, free):
    if paused:
        return 'paused'
    if not mounted or not same_device:
        return 'ssd_disconnected'
    if free < 10 * 1024**3:
        return 'low_disk_space'
    return None


def render():
    state = rt.read_json(STATE)
    active = live()
    status = state.get('status', 'not_started')
    if not active and status in ('running', 'starting'):
        status = 'interrupted; Resume restarts safely'
    progress = rt.read_json(Path(state['progress'])) if state.get('progress') else {}
    rows, total = progress.get('rows'), progress.get('total_rows')
    fraction = f'{rows:,} / {total:,} ({100*rows/total:.1f}%)' if total and rows is not None else str(rows or 'not yet available')
    text = '\n'.join(['# MVA ranking tracker', '', f'Updated: {time.strftime("%Y-%m-%d %H:%M:%S")}',
        f'Status: {status}', f'Supervisor live: {active}', f'Pause requested: {state.get("paused", False)}',
        f'Stage: {progress.get("stage", "waiting for worker")}',
        f'Stage rows: {fraction}', f'Stage chromosomes done: {progress.get("chromosomes_done", "—")} / 24',
        f'Progress timestamp (Unix): {progress.get("updated_unix", "—")}',
        f'Attempt: {state.get("attempt", "—")}', f'Log: {state.get("log", "—")}', '',
        'Percent is stage-local, not total time. Hashing/pair enumeration have no reliable percent.',
        'Resume preserves partial attempts and restarts computation; it does not reuse partial rankings.',
        'Use MVA Ranking Pause / Resume / Status.command. Do not eject until PAUSED.',
        'Shutdown requires manual Resume after login and reconnect. No AI or network calls.']) + '\n'
    rt.atomic_text(rt.DATA / 'ranking-tracker.md', text)
    return text


def supervise():
    with rt.exclusive(LOCK):
        meta = {}
        try:
            state = rt.read_json(STATE)
            if state.get('paused'):
                return
            rt.ensure_volume()
            device = rt.VOLUME.stat().st_dev
            contract = json.loads(Path(state['contract']).read_text())
            env = dict(os.environ, PATH='/opt/homebrew/bin:' + os.environ.get('PATH', ''),
                       MVA_RANK_PROGRESS=state['progress'])
            with Path(state['log']).open('xb') as log:
                child = subprocess.Popen(['/usr/bin/caffeinate', '-i', sys.executable, '-m',
                    'scripts.run_ranking', '--contract', state['contract']], cwd=rt.ROOT,
                    stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                    start_new_session=True, env=env)
            # caffeinate execs Python; allow that transition before saving identity.
            time.sleep(.2)
            meta = {'pid': child.pid, 'started': started(child.pid), 'contract': state['contract'],
                    'bcf': contract['bcf']['path']}
            rt.atomic_json(WORKER, meta)
            def interrupt(signum, frame):
                raise KeyboardInterrupt
            signal.signal(signal.SIGTERM, interrupt)
            signal.signal(signal.SIGINT, interrupt)
            reason = None
            while child.poll() is None:
                current = rt.read_json(STATE)
                mounted = rt.VOLUME.is_mount()
                reason = stop_reason(current.get('paused'), mounted,
                    mounted and rt.VOLUME.stat().st_dev == device, shutil.disk_usage(rt.DATA).free)
                if reason:
                    stop_child(meta)
                    child.wait()
                    break
                render()
                time.sleep(2)
            if not reason:
                reason = 'complete' if child.returncode == 0 and verify_complete(state['output']) else 'failed_requires_review'
            with rt.exclusive(rt.DATA / 'ranking-state.lock'):
                current = rt.read_json(STATE)
                current.update(status=reason, exit_code=child.returncode, updated_unix=time.time())
                rt.atomic_json(STATE, current)
        except BaseException as exc:
            if meta:
                stop_child(meta)
            with rt.exclusive(rt.DATA / 'ranking-state.lock'):
                current = rt.read_json(STATE)
                current.update(status='interrupted' if isinstance(exc, KeyboardInterrupt) else 'failed_requires_review',
                               error_type=type(exc).__name__)
                rt.atomic_json(STATE, current)
        finally:
            render()


def pause():
    with rt.exclusive(rt.DATA / 'ranking-state.lock'):
        state = rt.read_json(STATE)
        state.update(paused=True)
        rt.atomic_json(STATE, state)
    deadline = time.monotonic() + 20
    while live() and time.monotonic() < deadline:
        time.sleep(.2)
    if live():
        raise RuntimeError('still stopping; do not eject yet')
    stop_child(rt.read_json(WORKER))
    print('PAUSED. Ranking processes stopped; partial attempts retained.')
    render()


def resume():
    if live():
        print('Already running; no duplicate started.')
        return
    stop_child(rt.read_json(WORKER))
    rt.ensure_volume()
    if shutil.disk_usage(rt.DATA).free < 10 * 1024**3:
        raise RuntimeError('less than 10 GiB free; review retained attempts')
    old = rt.read_json(STATE)
    if old.get('output') and verify_complete(old['output']):
        old.update(status='complete', paused=False)
        rt.atomic_json(STATE, old)
        print('Completed output verified; no rerun.')
        return
    original = json.loads(BASE.read_text())
    if verify_complete(original['output']):
        rt.atomic_json(STATE, {'status': 'complete', 'paused': False, 'output': original['output']})
        print('Original completed result verified; no rerun.')
        return
    attempt = time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8]
    directory = rt.DATA / 'ranking-attempts' / attempt
    directory.mkdir(parents=True)
    original['output'] = str(directory / 'result')
    contract = directory / 'contract.json'
    rt.atomic_json(contract, original)
    state = {'status': 'starting', 'paused': False, 'attempt': attempt, 'contract': str(contract),
             'output': original['output'], 'progress': str(directory / 'progress.json'),
             'log': str(directory / 'worker.log'), 'updated_unix': time.time()}
    rt.atomic_json(STATE, state)
    with (directory / 'supervisor.log').open('xb') as log:
        proc = subprocess.Popen([sys.executable, '-m', 'scripts.ranking_control', 'supervise'],
            cwd=rt.ROOT, stdout=log, stderr=log, stdin=subprocess.DEVNULL, start_new_session=True)
    deadline = time.monotonic() + 5
    while not live() and proc.poll() is None and time.monotonic() < deadline:
        time.sleep(.1)
    if not live():
        raise RuntimeError('supervisor did not start; inspect local log')
    with rt.exclusive(rt.DATA / 'ranking-state.lock'):
        state = rt.read_json(STATE)
        if state['status'] == 'starting':
            state['status'] = 'running'
            rt.atomic_json(STATE, state)
    print('Ranking started under managed controls.')
    render()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['status', 'pause', 'resume', 'supervise'])
    parser.add_argument('--watch', action='store_true')
    args = parser.parse_args()
    if args.action == 'status':
        while True:
            print(('\033[2J\033[H' if args.watch else '') + render(), flush=True)
            if not args.watch:
                return
            time.sleep(2)
    elif args.action == 'supervise':
        supervise()
    else:
        with rt.exclusive(rt.DATA / 'ranking-controller.lock'):
            (pause if args.action == 'pause' else resume)()


if __name__ == '__main__':
    main()
