"""Configuration-level review and within-lane sensitivity, not causal scoring."""
from collections import defaultdict
from itertools import combinations
import json

from scripts.ranking_adapter import ordered_views

FREQUENCY = ['observed_below_cutoff', 'frequency_unresolved', 'observed_at_or_above_cutoff']


def configurations(rows, max_pairs=1000000):
    groups = defaultdict(list)
    singles, pairs = [], 0
    for row in rows:
        if row['reasons'] or not row['gene']:
            continue
        singles.append(dict(row, configuration='single', members=[row['stable_id']]))
        if row['model'] == 'heterozygous_hypothesis':
            groups[(row['setting'], row['transcript_view'], row['gene'], row['transcript'])].append(row)
    for group in groups.values():
        for left, right in combinations(sorted(group, key=lambda r: r['stable_id']), 2):
            a, b = json.loads(left['stable_id']), json.loads(right['stable_id'])
            if a[:2] == b[:2] or a[0] != b[0]:
                continue
            pairs += 1
            if pairs > max_pairs:
                raise ValueError('pair budget exceeded; no silent truncation')
            lane = ('filtered' if 'filtered' in (left['filter_lane'], right['filter_lane']) else
                    'not_evaluated' if 'not_evaluated' in (left['filter_lane'], right['filter_lane']) else 'pass')
            members = sorted([left['stable_id'], right['stable_id']])
            singles.append(dict(left, stable_id=json.dumps(members), members=members,
                                configuration='possible_pair', model='possible_compound_heterozygous',
                                filter_lane=lane, phase='unresolved',
                                severity=min(left['severity'], right['severity']),
                                frequency_lane=FREQUENCY[max(FREQUENCY.index(left['frequency_lane']),
                                                            FREQUENCY.index(right['frequency_lane']))],
                                population_limitations=sorted(set(left['population_limitations'] +
                                                                  right['population_limitations']))))
    return sorted(singles, key=lambda r: (r['setting'], r['transcript_view'], r['stable_id']))


def stability(rows, hpo_views, settings=None):
    views = ordered_views(rows, hpo_views)
    lanes = defaultdict(dict)
    for phenotype, ordered in views.items():
        for row in ordered:
            lane = (row['transcript_view'], row['model'], row['filter_lane'])
            run = row['setting'] + ':' + phenotype
            genes = lanes[lane].setdefault(run, {})
            if row['gene'] not in genes:
                genes[row['gene']] = {'rank': len(genes) + 1, 'configuration': row['stable_id']}
    output = []
    runs = [setting + ':' + phenotype for setting in (settings or {r['setting'] for r in rows})
            for phenotype in views]
    for lane, observed in sorted(lanes.items()):
        for run in runs:
            observed.setdefault(run, {})
        baseline = observed.get('baseline:disabled', {})
        genes = set().union(*(set(x) for x in observed.values()))
        summary = {}
        for gene in sorted(genes):
            ranks = [r[gene]['rank'] for r in observed.values() if gene in r]
            summary[gene] = {'min_rank': min(ranks), 'max_rank': max(ranks),
                             'absent_runs': sorted(k for k, r in observed.items() if gene not in r)}
        overlaps = {}
        for run, ranking in observed.items():
            overlaps[run] = {}
            for n in (20, 100):
                a = {g for g, r in baseline.items() if r['rank'] <= n}
                b = {g for g, r in ranking.items() if r['rank'] <= n}
                overlaps[run][str(n)] = {'intersection': len(a & b), 'union': len(a | b),
                                         'jaccard': len(a & b) / len(a | b) if a | b else None}
        output.append({'lane': lane, 'gene_ranks': summary, 'runs': observed, 'overlaps': overlaps})
    return output
