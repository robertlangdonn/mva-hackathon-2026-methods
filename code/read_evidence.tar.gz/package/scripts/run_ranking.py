"""Guarded local ranking. Run as python3 -m scripts.run_ranking --contract PATH.

Requires a separately audited, hash-pinned controlled contract. No default
patient paths, implicit metadata assumptions or early partial-genome run.
"""
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import subprocess

from scripts.ranking_adapter import CHROMS, ROOT, aligned, adapt, write_bundle
from scripts.ranking_configurations import configurations, stability
from scripts.ranking_export import export, transcript_metadata
from scripts.ranking_policy import transcript_effects
from scripts.ranking_progress import report


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(8 * 1024**2), b''):
            h.update(block)
    return h.hexdigest()


def pinned(item):
    path = Path(item['path']).resolve(strict=True)
    if sha(path) != item['sha256']:
        raise ValueError('input hash mismatch')
    return path


def coverage_gate(chromosomes):
    if set(chromosomes) != set(CHROMS):
        raise ValueError('all 24 chromosome joins are required')
    expected, verified = {}, {}
    for chrom in CHROMS:
        item = chromosomes[chrom]
        path, manifest_path = pinned(item['output']), pinned(item['manifest'])
        meta = json.loads(manifest_path.read_text())
        if meta['status'] != 'joined_match_counts_oracle_verified' or sha(path) != meta['output_sha256']:
            raise ValueError('join integrity gate failed')
        count = meta['counts']['rows']
        if type(count) is not int or count < 0:
            raise ValueError('invalid coverage count')
        if set(meta['inputs']) != {'patient', 'exomes', 'genomes'}:
            raise ValueError('incomplete join provenance')
        for source in ('exomes', 'genomes'):
            matches = sum(meta['counts'].get(source + '_' + status, 0) for status in
                          ('matched_af_available', 'matched_af_missing', 'matched_multiple_records'))
            if meta['counts'][source + '_independent_isec_matches'] != matches:
                raise ValueError('independent join count gate failed')
        for source in meta['inputs'].values():
            pinned(source)
        expected[chrom], verified[chrom] = count, path
    return expected, verified


def hpo_views(data):
    terms = data['terms']
    if len(set(terms)) != len(terms) or not terms or set(data['leave_one_out']) != set(terms):
        raise ValueError('incomplete phenotype sensitivity inputs')
    return {'all_terms': data['all_terms'],
            **{'omit_' + term: scores for term, scores in data['leave_one_out'].items()}}


def validate_intervals(metadata):
    if metadata['build'] != 'GRCh38' or not metadata['audit_note'] or not metadata['source']:
        raise ValueError('audited GRCh38 ploidy contract required')
    previous = {}
    for row in sorted(metadata['intervals'], key=lambda r: (r['chrom'], r['start'])):
        if (row['chrom'] not in CHROMS or type(row['start']) is not int
                or type(row['end']) is not int or type(row['ploidy']) is not int
                or row['ploidy'] not in (1, 2) or row['start'] < 1 or row['end'] < row['start']
                or row['start'] <= previous.get(row['chrom'], 0)):
            raise ValueError('invalid or overlapping ploidy metadata')
        previous[row['chrom']] = row['end']
    return metadata['intervals']


def run(contract_path):
    report('verifying_inputs')
    controlled = (ROOT / 'data/intermediate').resolve()
    contract_path = Path(contract_path).resolve(strict=True)
    if not contract_path.is_relative_to(controlled):
        raise ValueError('contract must remain controlled')
    original_contract_hash = sha(contract_path)
    contract = json.loads(contract_path.read_text())
    if contract['schema'] != 'mva-ranking-inputs-v1':
        raise ValueError('unknown input contract')
    expected, populations = coverage_gate(contract['chromosomes'])
    inputs = {name: pinned(contract[name]) for name in ('bcf', 'bcf_index', 'gff', 'policy', 'ploidy', 'hpo')}
    if inputs['bcf_index'] != Path(str(inputs['bcf']) + '.csi'):
        raise ValueError('pinned BCF CSI must be the index used by the query')
    if not inputs['bcf'].is_relative_to(controlled):
        raise ValueError('BCF must remain controlled')
    if any(not p.is_relative_to(controlled) for p in populations.values()):
        raise ValueError('population results must remain controlled')
    intervals = validate_intervals(json.loads(inputs['ploidy'].read_text()))
    phenotypes = hpo_views(json.loads(inputs['hpo'].read_text()))
    policy = json.loads(inputs['policy'].read_text())
    # Prevent accidental policy schema drift while this implementation is v1.
    frozen = ROOT / 'config/ranking-policy-v1.json'
    if inputs['policy'].read_bytes() != frozen.read_bytes():
        raise ValueError('policy differs from implemented v1')
    report('loading_transcripts')
    transcripts = transcript_metadata(inputs['gff'])
    target = Path(contract['output']).resolve()
    if target == controlled or not target.is_relative_to(controlled):
        raise ValueError('output must remain controlled')
    target.mkdir()
    (target / 'INCOMPLETE').touch(exist_ok=False)
    counts, audit = Counter(), Counter()
    def population():
        for chrom in CHROMS:
            with populations[chrom].open() as handle:
                for line in handle:
                    row = json.loads(line)
                    if row['chrom'] != chrom:
                        raise ValueError('population chromosome mismatch')
                    yield row
    review = []
    with (target / 'export.log').open('x') as log:
        variants = export(inputs['bcf'], target / 'consequences.sqlite', log, counts)
        with (target / 'audit.jsonl').open('x') as audit_file:
            for variant, pop in aligned(variants, population()):
                audit['source_filter_' + ('PASS' if variant['filter'] == 'PASS' else
                      'missing' if variant['filter'] == '.' else 'failed')] += 1
                if not all(set(variant[f]) <= set('ACGTN') for f in ('ref', 'alt')):
                    audit['unsupported_allele_class'] += 1
                effects = transcript_effects(variant['bcsq'])
                if not effects:
                    audit['no_resolved_protein_altering_effect'] += 1
                    continue
                for row in adapt([variant], [pop], policy, transcripts, intervals):
                    audit_file.write(json.dumps(row) + '\n')
                    audit['review_rows'] += 1
                    if not row['reasons']:
                        review.append(row)
                        if len(review) > 1000000:
                            raise ValueError('review memory budget exceeded')
            audit_file.flush()
            os.fsync(audit_file.fileno())
    if {c: counts[c] for c in CHROMS} != expected:
        raise ValueError('canonical coverage does not reconcile')
    report('enumerating_configurations', review_rows=len(review))
    configs = configurations(review)
    report('phenotype_sensitivity', configurations=len(configs))
    summaries = stability(configs, phenotypes, ['baseline', *policy['sensitivity_overrides']])
    # Detect source changes during export; immutable source hashes stay pinned.
    report('final_integrity_checks')
    if sha(contract_path) != original_contract_hash:
        raise ValueError('contract changed during execution')
    for name in inputs:
        pinned(contract[name])
    for item in contract['chromosomes'].values():
        pinned(item['output'])
        pinned(item['manifest'])
    provenance = {'contract_sha256': original_contract_hash, 'counts': dict(counts),
                  'audit': dict(audit), 'inputs': {n: contract[n] for n in inputs},
                  'code_sha256': {p.name: sha(p) for p in (ROOT / 'scripts').glob('ranking_*.py')},
                  'runner_sha256': sha(Path(__file__)),
                  'bcftools': subprocess.check_output(['bcftools', '--version'], text=True).splitlines()[0]}
    report('writing_results')
    write_bundle(target / 'configurations', configs, provenance)
    with (target / 'stability.json').open('x') as handle:
        json.dump(summaries, handle, allow_nan=False)
        handle.flush()
        os.fsync(handle.fileno())
    manifest = {'status': 'complete_review_not_causal_validation', 'provenance': provenance,
                'artifacts': {name: sha(target / name) for name in
                              ('audit.jsonl', 'stability.json', 'configurations/review.jsonl',
                               'configurations/manifest.json')}}
    with (target / 'manifest.json').open('x') as handle:
        json.dump(manifest, handle)
        handle.flush()
        os.fsync(handle.fileno())
    (target / 'INCOMPLETE').unlink()
    report('complete', canonical_rows=sum(counts.values()))
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--contract', type=Path, required=True)
    args = parser.parse_args()
    run(args.contract)
