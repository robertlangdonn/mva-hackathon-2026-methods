"""Deterministic local manual-review packet. No clinical classification or network."""
import argparse
from collections import Counter
import json
import os
from pathlib import Path

from scripts import population_runtime as rt
from scripts.ranking_control import verify_complete
from scripts.run_ranking import pinned, sha


def identity(row):
    members = sorted({tuple(json.loads(m)[:4]) for m in row['members']})
    expected = 2 if row['configuration'] == 'possible_pair' else 1
    if len(members) != expected:
        raise ValueError('invalid member cardinality')
    return json.dumps([row['gene'], row['model'], members], separators=(',', ':'))


def selected(row):
    return (row['setting'] == 'baseline' and row['filter_lane'] == 'pass'
            and row['frequency_lane'] in ('observed_below_cutoff', 'frequency_unresolved'))


def records(path):
    with path.open() as handle:
        for line in handle:
            yield json.loads(line)


def save(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.flush()
        os.fsync(handle.fileno())


def build(output):
    output = output.resolve()
    if output == rt.DATA.resolve() or not output.is_relative_to(rt.DATA.resolve()):
        raise ValueError('new controlled output required')
    state = rt.read_json(rt.DATA / 'ranking-control.json')
    root = Path(state['output']).resolve()
    if not root.is_relative_to(rt.DATA.resolve()) or not verify_complete(root):
        raise ValueError('verified controlled ranking required')
    contract_path = Path(state['contract'])
    contract_hash = sha(contract_path)
    contract = json.loads(contract_path.read_text())
    source_hash = sha(root / 'manifest.json')
    output.mkdir()
    (output / 'INCOMPLETE').touch()
    rt.atomic_json(output / 'progress.json', {'stage':'selecting_baseline_queue'})
    packets = {}
    review = root / 'configurations/review.jsonl'
    for row in records(review):
        if selected(row):
            key = identity(row)
            if key not in packets:
                gene, model, members = json.loads(key)
                packets[key] = {'gene':gene,'model':model,'members':members,
                                'evidence_rows':[], 'gene_sensitivity':[],
                                'phase':'unresolved','manual_status':'not_reviewed'}
    rt.atomic_json(output / 'progress.json', {'stage':'attaching_sensitivity','configurations':len(packets)})
    for row in records(review):
        key = identity(row)
        if key in packets:
            packets[key]['evidence_rows'].append(row)
    # Keep winning configuration IDs: a gene rank change is not necessarily the same pair moving.
    stability = json.loads((root / 'stability.json').read_text())
    for packet in packets.values():
        for lane in stability:
            if lane['lane'][1] != packet['model'] or lane['lane'][2] != 'pass':
                continue
            gene = packet['gene']
            packet['gene_sensitivity'].append({'lane':lane['lane'],
                'ranks':{run:genes.get(gene) for run,genes in lane['runs'].items()},
                'caution':'Gene-level ranks; winning configuration may differ from this packet.'})
    keys = {tuple(member) for p in packets.values() for member in p['members']}
    population = {}
    rt.atomic_json(output / 'progress.json', {'stage':'attaching_population','alleles':len(keys)})
    for item in contract['chromosomes'].values():
        path = pinned(item['output'])
        for row in records(path):
            key = tuple(row[n] for n in ('chrom','pos','ref','alt'))
            if key in keys:
                if key in population:
                    raise ValueError('duplicate population allele')
                population[key] = row
    if set(population) != keys:
        raise ValueError('missing selected population evidence')
    for packet in packets.values():
        packet['member_population'] = [population[tuple(m)] for m in packet['members']]
    # Preserve exceptions rather than silently treating them as negative findings.
    exceptions = []
    for row in records(root / 'audit.jsonl'):
        if row['setting']=='baseline' and row['transcript_view']=='all_annotated' and row['reasons']:
            exceptions.append(row)
    summary = {'configurations':len(packets),'distinct_alleles':len(keys),
               'models':dict(Counter(p['model'] for p in packets.values())),
               'exception_effect_rows':len(exceptions), 'manual_review_complete':False}
    # Allele-level source limitations and AF thresholds, not a clinical frequency assertion.
    summary['population_limited_alleles'] = sum(bool(r['limitations']) for r in population.values())
    summary['observed_af_bins'] = dict(Counter('unknown' if r['max_observed_af_grpmax'] is None else
        'lt_0.0001' if r['max_observed_af_grpmax'] < .0001 else
        '0.0001_to_lt_0.001' if r['max_observed_af_grpmax'] < .001 else
        '0.001_to_lt_0.01' if r['max_observed_af_grpmax'] < .01 else 'ge_0.01'
        for r in population.values()))
    save(output/'packets.json', list(packets.values()))
    save(output/'exceptions.json', exceptions)
    save(output/'summary.json', summary)
    if sha(contract_path)!=contract_hash or sha(root/'manifest.json')!=source_hash or not verify_complete(root):
        raise ValueError('source changed during packet creation')
    save(output/'manifest.json', {'status':'complete_packet_not_manual_validation',
        'source_manifest_sha256':source_hash,'contract_sha256':contract_hash,'builder_sha256':sha(Path(__file__)),
        'selection':'baseline PASS below-cutoff or unresolved frequency; all model/transcript views',
        'not_selected':'Above-cutoff and filtered configurations remain in original ranking; exceptions retained separately.',
        'artifacts':{name:sha(output/name) for name in ('packets.json','exceptions.json','summary.json')}})
    (output/'INCOMPLETE').unlink()
    rt.atomic_json(output/'progress.json', {'stage':'complete'})
    print(json.dumps(summary))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True,type=Path)
    build(parser.parse_args().output)
