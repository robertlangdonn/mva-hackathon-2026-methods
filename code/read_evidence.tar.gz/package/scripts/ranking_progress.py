"""Aggregate-only progress, enabled by the managed runner environment."""
import os
from pathlib import Path
import time
from scripts.population_runtime import atomic_json, DATA


def report(stage, **counts):
    raw = os.environ.get('MVA_RANK_PROGRESS')
    if not raw:
        return
    path = Path(raw).resolve()
    if not path.is_relative_to(DATA.resolve()):
        raise ValueError('progress must remain controlled')
    atomic_json(path, {'stage': stage, 'updated_unix': time.time(), **counts})
