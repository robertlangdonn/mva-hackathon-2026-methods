"""Full canonical BCF export with disk-backed BCSQ link resolution."""
from contextlib import contextmanager
import gzip
import json
import sqlite3
import subprocess

from scripts.gene_regions import parse_attributes
from scripts.ranking_adapter import CHROMS
from scripts.ranking_progress import report

FORMAT = '%CHROM\t%POS\t%REF\t%ALT\t%FILTER\t[%GT\t%DP\t%GQ\t%AD]\t%INFO/BCSQ\n'


@contextmanager
def query(bcf, chrom, log):
    proc = subprocess.Popen(['bcftools', 'query', '-r', chrom, '-f', FORMAT, str(bcf)],
                            stdout=subprocess.PIPE, stderr=log, text=True)
    try:
        yield proc.stdout
        if proc.wait() != 0:
            raise ValueError('BCF query failed; inspect controlled log')
    finally:
        proc.stdout.close()
        if proc.poll() is None:
            proc.terminate()
            proc.wait()


def parse(line):
    fields = line.rstrip('\n').split('\t')
    if len(fields) != 10:
        raise ValueError('expected single-sample complete BCF schema')
    chrom, pos, ref, alt, filt, gt, dp, gq, ad, bcsq = fields
    return dict(chrom=chrom, pos=int(pos), ref=ref, alt=alt, filter=filt,
                gt=gt, dp=dp, gq=gq, ad=ad, bcsq=bcsq)


class Consequences:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.execute('CREATE TABLE effects (chrom TEXT, pos INTEGER, value TEXT)')
        self.db.execute('CREATE INDEX positions ON effects(chrom,pos)')

    def add(self, row):
        if row['bcsq'] != '.':
            self.db.execute('INSERT INTO effects VALUES (?,?,?)',
                            (row['chrom'], row['pos'], row['bcsq']))

    def resolve(self, row):
        token = f"{row['pos']}{row['ref']}>{row['alt']}"
        def expand(raw, visited):
            result = []
            for effect in raw.split(','):
                if not effect.startswith('@'):
                    result.append(effect)
                    continue
                pos = int(effect[1:])
                if pos in visited:
                    raise ValueError('cyclic consequence reference')
                records = self.db.execute('SELECT value FROM effects WHERE chrom=? AND pos=?',
                                          (row['chrom'], pos)).fetchall()
                if not records:
                    raise ValueError('missing consequence reference')
                linked = [e for (value,) in records for e in expand(value, visited | {pos})
                          if token in e.split('|')[-1].split('+')]
                if not linked:
                    raise ValueError('consequence reference lacks matching allele')
                result.extend(linked)
            return result
        return ','.join(sorted(set(expand(row['bcsq'], set()))))

    def close(self):
        self.db.close()


def export(bcf, scratch, log, counts):
    """Two passes permit forward as well as backward BCSQ links; no raw prints."""
    samples = subprocess.run(['bcftools', 'query', '-l', str(bcf)],
                             stdout=subprocess.PIPE, stderr=log, text=True, check=True)
    if len(samples.stdout.splitlines()) != 1:
        raise ValueError('single-sample input required')
    resolver = Consequences(scratch)
    try:
        indexed = 0
        for index, chrom in enumerate(CHROMS):
            report('indexing_consequences', chromosomes_done=index, rows=indexed)
            with query(bcf, chrom, log) as lines:
                for line in lines:
                    resolver.add(parse(line))
                    indexed += 1
                    if indexed % 50000 == 0:
                        report('indexing_consequences', chromosomes_done=index, rows=indexed)
        resolver.db.commit()
        for index, chrom in enumerate(CHROMS):
            report('ranking_variants', chromosomes_done=index, rows=sum(counts.values()), total_rows=indexed)
            with query(bcf, chrom, log) as lines:
                for line in lines:
                    row = parse(line)
                    row['bcsq'] = resolver.resolve(row)
                    counts[chrom] += 1
                    if sum(counts.values()) % 50000 == 0:
                        report('ranking_variants', chromosomes_done=index, rows=sum(counts.values()), total_rows=indexed)
                    yield row
    finally:
        resolver.close()


def transcript_metadata(path):
    """Resolve GFF gene parents, not gene names inferred from transcript labels."""
    genes, pending, result = {}, [], {}
    opener = gzip.open if str(path).endswith('.gz') else open
    with opener(path, 'rt') as handle:
        for line in handle:
            if line.startswith('#'):
                continue
            fields = line.rstrip('\n').split('\t')
            if len(fields) != 9:
                raise ValueError('invalid GFF record')
            attrs = parse_attributes(fields[8])
            if fields[2] == 'gene' and 'ID' in attrs:
                gid = attrs['ID']
                name = attrs.get('Name')
                if gid in genes and genes[gid] != name:
                    raise ValueError('conflicting gene metadata')
                genes[gid] = name
            if fields[2] in ('mRNA', 'transcript') and 'transcript_id' in attrs:
                pending.append(attrs)
    for attrs in pending:
        gene = genes.get(attrs.get('Parent'))
        if not gene:
            continue  # Unknown stays unknown in preferred-transcript view.
        tags = set(attrs.get('tag', '').split(','))
        value = {'gene': gene, 'preferred': bool(tags & {'MANE_Select', 'gencode_primary'})}
        tx = attrs['transcript_id']
        if tx in result and result[tx] != value:
            raise ValueError('conflicting transcript metadata')
        result[tx] = value
    return result
