"""Pure review-policy helpers. No patient IO, clinical scores or phase inference."""
import math
from itertools import combinations

from scripts.genomewide_screen import consequence_evidence


def qc_reasons(gt, dp, gq, ad, settings, expected_ploidy=None):
    """Expected ploidy must come from an audited context, never the GT alone."""
    alleles = gt.replace('|', '/').split('/')
    if any(a not in {'0', '1'} for a in alleles) or len(alleles) not in (1, 2):
        return ['missing_or_unsupported_gt']
    if '1' not in alleles:
        return ['no_alt']
    if expected_ploidy is None or len(alleles) != expected_ploidy:
        return ['ploidy_unresolved_or_mismatch']
    try:
        depth, quality = float(dp), float(gq)
        depths = [int(x) for x in ad.split(',')]
        if (not math.isfinite(depth) or not math.isfinite(quality)
                or depth < 0 or quality < 0 or len(depths) != 2
                or min(depths) < 0 or sum(depths) == 0):
            raise ValueError
    except (ValueError, TypeError, AttributeError):
        return ['invalid_or_missing_qc']
    balance = depths[1] / sum(depths)
    het = len(set(alleles)) == 2
    ok = (settings['het_ab_min'] <= balance <= settings['het_ab_max'] if het
          else balance >= settings['alt_ab_min'])
    return ([ 'low_dp' ] if depth < settings['min_dp'] else []) + (
        ['low_gq'] if quality < settings['min_gq'] else []) + (
        ['allelic_balance'] if not ok else [])


def frequency_lane(combined, cutoff):
    """Low observed AF with limitations stays unresolved; high AF stays visible."""
    value = combined['max_observed_af_grpmax']
    if not math.isfinite(cutoff) or not 0 < cutoff <= 1:
        raise ValueError('invalid cutoff')
    if value is not None:
        if not math.isfinite(value) or not 0 <= value <= 1:
            raise ValueError('invalid frequency')
        if value >= cutoff:
            return 'observed_at_or_above_cutoff'
    if value is None or combined['limitations']:
        return 'frequency_unresolved'
    return 'observed_below_cutoff'


def transcript_effects(bcsq):
    """Per-transcript severity: another gene's severe effect cannot transfer."""
    effects = {}
    for row in consequence_evidence(bcsq):
        if row['severity'] >= 2 and row['transcript'] not in ('', '.'):
            key = (row['gene'], row['transcript'])
            effects[key] = max(effects.get(key, 0), row['severity'])
    return effects


def possible_pairs(rows):
    """Enumerate distinct heterozygous alleles sharing a transcript, unphased.

    Input keys are normalized (chrom, pos, ref, alt). No clinical trans claim
    can follow from this function, even if GT contains a pipe.
    """
    seen, groups = set(), {}
    for row in rows:
        key = tuple(row['key'])
        if key in seen:
            raise ValueError('duplicate normalized allele')
        seen.add(key)
        if row['gt'].replace('|', '/') not in ('0/1', '1/0'):
            continue
        for gene_tx in transcript_effects(row['bcsq']):
            groups.setdefault(gene_tx, []).append(key)
    result = []
    for (gene, tx), keys in sorted(groups.items()):
        for left, right in combinations(sorted(keys), 2):
            if left[:2] == right[:2]:
                continue  # Split alternatives at one locus need separate interpretation.
            result.append({'gene': gene, 'transcript': tx, 'alleles': [left, right],
                           'phase': 'unresolved'})
    return result


def review_sort_key(row):
    """Within a declared model/transcript/QC lane; not a pathogenicity score."""
    lanes = {'observed_below_cutoff': 0, 'frequency_unresolved': 1,
             'observed_at_or_above_cutoff': 2}
    return (lanes[row['frequency_lane']], -row['severity'], row['stable_id'])
