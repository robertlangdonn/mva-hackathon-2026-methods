"""Static local-import closure only; never import workflow modules or export data."""
import ast
import hashlib
import json
from pathlib import Path

ENTRIES = ('genomewide_screen', 'prepare_ranking_inputs', 'run_ranking', 'build_review_packet',
           'corrected_pair_alignment', 'interim_read_support', 'interim_indel_snapshot',
           'consolidate_read_snapshot', 'validate_submission', 'select_remaining_alternatives',
           'audit_shortlist_splice', 'review_shortlist_conditions', 'review_shortlist_splice_frequency',
           'reconcile_long_alleles', 'review_long_allele_frequency', 'review_mc3r_study',
           'match_mc3r_tables', 'review_alternative_clinvar')


def imports(source):
    found = set()
    for node in ast.walk(ast.parse(source)):
        if isinstance(node, ast.Import):
            found.update(a.name for a in node.names if a.name.startswith('scripts.'))
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                raise ValueError('relative import needs manual resolution')
            if node.module == 'scripts':
                found.update('scripts.' + a.name for a in node.names)
            elif node.module and node.module.startswith('scripts.'):
                found.add(node.module)
    return found


def closure(root, entries):
    pending = {'scripts.' + e for e in entries}; result = {}
    while pending:
        module = min(pending); pending.remove(module)
        if module in result: continue
        path = root.joinpath(*module.split('.')).with_suffix('.py')
        if not path.is_file(): raise ValueError('unresolved local module: ' + module)
        data = path.read_bytes(); source = data.decode(); deps = imports(source)
        result[module] = dict(path=str(path.relative_to(root)),
            sha256=hashlib.sha256(data).hexdigest(), local_imports=sorted(deps),
            host_path_reference=('/Users/' in source or '/Volumes/' in source),
            subprocess_reference=('subprocess' in source),
            dynamic_import_reference=('import_module' in source or '__import__' in source))
        pending.update(deps - result.keys())
    return result


def main():
    root = Path(__file__).resolve().parents[1]
    rows = closure(root, ENTRIES)
    print(json.dumps(dict(entries=ENTRIES, module_count=len(rows), modules=rows,
        caveat='Review inventory, not release clearance. Does not resolve runtime files, direct-script fallback imports, binaries, resources, initializers or test fixtures.'), indent=2))


if __name__ == '__main__': main()
