"""Explicit, bounded read-evidence snapshot contract; no alignment or acquisition."""
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
from scripts.consolidate_read_snapshot import merge
from scripts import consolidate_read_snapshot
from scripts.export_reference import streaming_digest, MAX_REFERENCE_BYTES

INPUTS = {'journal','complete','plan','scope','reference','snv','indel','snv_snapshot','indel_snapshot'}
ARTIFACTS = {'manifest.json','result.json','selected.sam.gz','alignment.log'}
MAX_BYTES = 100 * 1024**2  # deliberately bounded export demonstration, not production-scale replay


def digest(path):
    with path.open('rb') as handle:return hashlib.file_digest(handle,'sha256').hexdigest()


def absolute(value):
    p=Path(value)
    if not p.is_absolute() or '..' in p.parts:raise ValueError('absolute non-traversing path required')
    if p.is_symlink():raise ValueError('symlink rejected')
    return p.resolve()


class Pins(dict):
    reference_limits=None

    def check(self):
        for p,h in self.items():
            if self.reference_limits is not None and p==self.reference_limits[0]:
                actual=streaming_digest(p,byte_limit=self.reference_limits[1],expected_bytes=self.reference_limits[2])
            else:
                if p.stat().st_size>MAX_BYTES:raise ValueError('bounded input grew beyond budget')
                actual=digest(p)
            if actual!=h:raise ValueError('input drift during verification')


def verify(contract_path, output, *, assessment=False):
    contract_path=absolute(contract_path);contract_hash=digest(contract_path)
    contract=json.loads(contract_path.read_text())
    scaled=assessment or contract.get('schema')=='mva-read-evidence-export-v2'
    fields={'schema','controlled_root','inputs','chunks','merge_source_sha256'}
    if scaled:fields.add('reference_budget')
    if assessment:fields.update(('targets','assessment_sources'))
    schemas=('mva-read-assessment-export-v1',) if assessment else ('mva-read-evidence-export-v1','mva-read-evidence-export-v2')
    if set(contract)!=fields or contract['schema'] not in schemas:
        raise ValueError('unknown read-evidence contract')
    reference_budget=contract.get('reference_budget')
    if scaled and (set(reference_budget)!={'max_bytes','expected_bytes'} or
        type(reference_budget['max_bytes']) is not int or type(reference_budget['expected_bytes']) is not int or
        not 0<reference_budget['expected_bytes']<=reference_budget['max_bytes']<=MAX_REFERENCE_BYTES):
        raise ValueError('invalid explicit reference budget')
    root=absolute(contract['controlled_root']);output=absolute(output)
    if root==Path('/') or not root.is_dir() or not contract_path.is_relative_to(root):
        raise ValueError('dedicated controlled directory required')
    if output==root or not output.is_relative_to(root) or output.exists():
        raise ValueError('fresh controlled output required')
    expected_inputs=INPUTS-{'snv','indel','snv_snapshot','indel_snapshot'} if assessment else INPUTS
    if set(contract['inputs'])!=expected_inputs:raise ValueError('exact input set required')
    merge_path=Path(consolidate_read_snapshot.__file__)
    if digest(merge_path)!=contract['merge_source_sha256']:raise ValueError('merge implementation drift')
    pins=Pins({contract_path:contract_hash,merge_path:contract['merge_source_sha256']});budget=0
    def pin(row,is_reference=False):
        nonlocal budget
        if set(row)!={'path','sha256'} or not re.fullmatch('[0-9a-f]{64}',row['sha256']):
            raise ValueError('invalid file pin')
        p=absolute(row['path'])
        if not p.is_relative_to(root) or not p.is_file():raise ValueError('input outside controlled storage')
        for parent in [p.parent,*p.parents]:
            if parent==root.parent:break
            if (parent/'INCOMPLETE').exists():raise ValueError('incomplete input')
        if scaled and is_reference:
            actual=streaming_digest(p,byte_limit=reference_budget['max_bytes'],expected_bytes=reference_budget['expected_bytes'])
            pins.reference_limits=(p,reference_budget['max_bytes'],reference_budget['expected_bytes'])
        else:
            actual=None
        if p not in pins and not (scaled and is_reference):
            budget+=p.stat().st_size
            if budget>MAX_BYTES:raise ValueError('bounded export input budget exceeded')
        if (actual if actual is not None else digest(p))!=row['sha256']:raise ValueError('input hash mismatch')
        if p in pins and pins[p]!=row['sha256']:raise ValueError('conflicting pin')
        pins[p]=row['sha256'];return p
    paths={n:pin(row,n=='reference') for n,row in contract['inputs'].items()}
    if len(set(paths.values()))!=len(paths):raise ValueError('aliased input paths')
    data={n:json.loads(p.read_text()) for n,p in paths.items() if n!='reference'}
    journal=data['journal'];complete=data['complete'];plan=data['plan'];scope=data['scope']
    if complete['journal_sha256']!=pins[paths['journal']] or complete['chunks']!=len(journal):
        raise ValueError('completion journal mismatch')
    if not journal or len(contract['chunks'])!=len(journal):raise ValueError('chunk inventory mismatch')
    if not assessment and (data['snv_snapshot']!=journal or data['indel_snapshot']!=journal):
        raise ValueError('saved snapshot mismatch')
    if plan['reference']!=pins[paths['reference']]:raise ValueError('reference lineage mismatch')
    end=0;seen=set()
    for entry,files in zip(journal,contract['chunks']):
        if set(files)!=ARTIFACTS:raise ValueError('chunk artifact set mismatch')
        chunk={n:pin(row) for n,row in files.items()}
        if len({p.parent for p in chunk.values()})!=1:raise ValueError('split chunk folder')
        folder=chunk['result.json'].parent
        if folder in seen or folder.name!=entry['folder']:raise ValueError('duplicate or mismatched chunk')
        seen.add(folder)
        if any(p.name!=n for n,p in chunk.items()):raise ValueError('artifact filename mismatch')
        manifest=json.loads(chunk['manifest.json'].read_text())
        if pins[chunk['manifest.json']]!=entry['manifest_sha256']:raise ValueError('chunk manifest mismatch')
        if manifest['artifacts']!={n:pins[p] for n,p in chunk.items() if n!='manifest.json'}:
            raise ValueError('retained artifact mismatch')
        result=json.loads(chunk['result.json'].read_text())
        if result['plan_sha256']!=pins[paths['plan']] or any(result[n]!=entry[n] for n in ('start_pairs','end_pairs','offsets')):
            raise ValueError('chunk lineage mismatch')
        if type(entry['start_pairs']) is not int or type(entry['end_pairs']) is not int or entry['start_pairs']!=end or entry['end_pairs']<=end:
            raise ValueError('noncontiguous journal')
        end=entry['end_pairs']
    if end!=complete['total_pairs'] or end!=plan['total_pairs']:raise ValueError('incomplete pair census')
    if assessment:
        pins.check()
        return output,contract,paths,data,pins,budget
    snv,indel=data['snv'],data['indel']
    if snv['plan_sha256']!=pins[paths['plan']] or snv['scope_sha256']!=pins[paths['scope']]:
        raise ValueError('report source lineage mismatch')
    required={tuple(k) for k in scope['required_sites']}
    if not required or not required<={tuple(s['key']) for s in snv['sites']}:
        raise ValueError('required scope lost')
    if any(not any(k[0]==c and lo<=k[1]<=hi for c,lo,hi in plan['windows']) for k in required):
        raise ValueError('required scope outside retention plan')
    rows=merge(snv,indel,complete)
    pins.check()
    return output,rows,pins,complete,budget


def run(contract,output):
    os.umask(0o077)
    output,rows,pins,complete,budget=verify(contract,output)
    output.mkdir();(output/'INCOMPLETE').touch()
    summary=dict(sites=len(rows),site_statuses=dict(Counter(r['combined_status'] for r in rows)),
        snapshot_pairs=complete['total_pairs'],snapshot_chunks=complete['chunks'],
        phase_established=False,causality_established=False,old_counts_pooled=False,ranks_changed=False)
    (output/'result.json').write_text(json.dumps(dict(summary=summary,sites=rows),sort_keys=True))
    pins.check()
    (output/'manifest.json').write_text(json.dumps(dict(artifacts={'result.json':digest(output/'result.json')},
        input_pins={str(p):h for p,h in pins.items()},script_sha256=digest(Path(__file__)),verified_bytes=budget,
        separately_verified_reference_bytes=pins.reference_limits[2] if pins.reference_limits else 0,
        assessment_recomputed=False,scope='verified consolidation only; supplied assessment reports not regenerated'),indent=2))
    (output/'INCOMPLETE').unlink()
    print(json.dumps(summary))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--contract',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args();run(args.contract,args.output)
