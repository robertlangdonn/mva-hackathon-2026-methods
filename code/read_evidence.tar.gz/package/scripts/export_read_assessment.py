"""Generate local bounded assessments from an explicit verified retained snapshot."""
import argparse
from collections import Counter
import gzip
import json
import os
from pathlib import Path
import time
from scripts import interim_read_support as snv
from scripts import interim_indel_snapshot as indel
from scripts import simple_indel_support
from scripts.export_read_evidence import verify, digest, merge

METHODS={'snv':snv,'indel':indel,'simple_indel':simple_indel_support}


def run(contract, output):
    os.umask(0o077)
    output,spec,paths,data,pins,budget=verify(contract,output,assessment=True)
    if set(spec['assessment_sources'])!=set(METHODS):
        raise ValueError('exact assessment source pins required')
    for name,module in METHODS.items():
        path=Path(module.__file__)
        if digest(path)!=spec['assessment_sources'][name]:raise ValueError('assessment source drift')
        pins[path]=spec['assessment_sources'][name]
    targets=spec['targets']
    if not isinstance(targets,list) or not 0<len(targets)<=100:raise ValueError('target count cap')
    keys=[]
    for k in targets:
        if (not isinstance(k,list) or len(k)!=4 or not isinstance(k[0],str) or not k[0]
            or type(k[1]) is not int or k[1]<1 or any(not isinstance(a,str) or not 0<len(a)<=1000 for a in k[2:])):
            raise ValueError('invalid target')
        keys.append(tuple(k))
    if len(set(keys))!=len(keys):raise ValueError('duplicate target')
    plan=data['plan'];required={tuple(k) for k in data['scope']['required_sites']}
    if not required or not required<=set(keys):raise ValueError('required scope lost')
    if any(not any(k[0]==c and lo<=k[1]<=hi for c,lo,hi in plan['windows']) for k in keys):
        raise ValueError('target outside retention plan')
    started=time.monotonic()
    def guard():
        if time.monotonic()-started>300:raise RuntimeError('assessment time cap')
    folders=[Path(chunk['selected.sam.gz']['path']).resolve().parent for chunk in spec['chunks']]
    def lines():
        total=0
        for folder in folders:
            with gzip.open(folder/'selected.sam.gz','rt') as handle:
                while True:
                    line=handle.readline(1_000_001)
                    if not line:break
                    guard();total+=len(line)
                    if len(line)>1_000_000 or total>100_000_000:raise RuntimeError('decompressed input cap')
                    yield line
    sites={k:snv.new_site() for k in keys}
    snv.scan(lines(),keys,sites,guard)
    non_snv=[k for k in keys if not(len(k[2])==len(k[3])==1 and k[2] in 'ACGT' and k[3] in 'ACGT')]
    contexts=indel.reference_contexts(paths['reference'],non_snv,pins[paths['reference']],guard)
    rows,eligible=indel.inventory(non_snv,contexts,plan['windows'])
    evidence=indel.evaluate(folders,eligible,guard)
    for row in rows:row['evidence']=evidence.get(row['ordinal'],{'status':'UNASSESSED'})
    common=dict(captured_journal_sha256=pins[paths['journal']],summary=dict(
        snapshot_pairs=data['complete']['total_pairs'],snapshot_chunks=data['complete']['chunks']))
    snv_report=dict(**common,plan_sha256=pins[paths['plan']],scope_sha256=pins[paths['scope']],
        sites=[dict(key=list(k),**snv.summarize(k,sites[k])) for k in keys])
    indel_report=dict(**common,pins={'plan.json':pins[paths['plan']],'scope-contract.json':pins[paths['scope']]},sites=rows)
    merged=merge(snv_report,indel_report,data['complete'])
    guard();pins.check()
    output.mkdir();(output/'INCOMPLETE').touch()
    summary=dict(sites=len(merged),site_statuses=dict(Counter(r['combined_status'] for r in merged)),
        snapshot_pairs=common['summary']['snapshot_pairs'],snapshot_chunks=common['summary']['snapshot_chunks'],
        phase_established=False,causality_established=False,old_counts_pooled=False,ranks_changed=False)
    artifacts={'snv.json':snv_report,'indel.json':indel_report,'result.json':dict(summary=summary,sites=merged)}
    for name,value in artifacts.items():(output/name).write_text(json.dumps(value,sort_keys=True))
    pins.check()
    (output/'manifest.json').write_text(json.dumps(dict(assessment_recomputed=True,
        artifacts={name:digest(output/name) for name in artifacts},input_pins={str(p):h for p,h in pins.items()},
        script_sha256=digest(Path(__file__)),verified_bytes=budget,alignment_recomputed=False),indent=2))
    (output/'INCOMPLETE').unlink()
    print(json.dumps(summary))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--contract',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args();run(args.contract,args.output)
