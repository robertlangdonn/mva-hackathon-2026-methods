"""Real assessment functions over invented SAM, then exported consolidation."""
import gzip
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import unittest
from scripts import interim_read_support as snv
from scripts import interim_indel_snapshot as indel
from scripts.export_read_evidence import digest
from scripts.export_read_assessment import METHODS
from scripts.inventory_release_dependencies import closure
from tests import test_export_read_evidence as contract_fixture

REFERENCE='ACGTCAGTACGATCGT'


def line(chrom,name,seq=REFERENCE,cigar='16M',mq=60,qual=None,flag=0):
    return '\t'.join([name,str(flag),chrom,'1',str(mq),cigar,'*','0','0',seq,
                      qual if qual is not None else 'I'*len(seq)])+'\n'


class ReadEvidenceReplay(unittest.TestCase):
    def test_generated_assessments_through_export_cli(self):
        fixture=contract_fixture.ReadExportTests()
        fixture.setUp();self.addCleanup(fixture.doCleanups)
        root=fixture.root;paths=fixture.paths;folder=fixture.folder
        keys=[('SNV',5,'C','T'),('INS',5,'C','CTT'),('DEL',5,'CAG','C'),
              ('NONE',5,'C','CTT'),('REPEAT',6,'A','AA')]
        references={c:REFERENCE for c in ('SNV','INS','DEL','NONE')}
        references['REPEAT']='CCCGAAAAATCGGCCC'
        fixture.reference.write_text(''.join(f'>{c}\n{s}\n' for c,s in references.items()))
        alt=REFERENCE[:4]+'T'+REFERENCE[5:]
        lines=[line('SNV','same-alt-name',alt),line('SNV','same-alt-name',alt,flag=16),
               line('SNV','ref'),line('SNV','low-quality',alt,qual='!'*16),
               line('SNV','unknown-mapq',alt,mq=255),
               line('INS','insertion','ACGTCTTAGTACGATCGT','5M2I11M'),line('INS','ref-ins'),
               line('DEL','deletion','ACGTCTACGATCGT','5M2D9M'),line('DEL','ref-del')]
        (folder/'selected.sam.gz').write_bytes(gzip.compress((''.join(lines)).encode(),mtime=0))
        plan=dict(reference=digest(fixture.reference),total_pairs=10,chunk_pairs=10,
                  windows=[[c,1,len(seq)] for c,seq in references.items()])
        paths['plan'].write_text(json.dumps(plan))
        paths['scope'].write_text(json.dumps({'required_sites':[list(k) for k in keys]}))
        result=json.loads((folder/'result.json').read_text());result['plan_sha256']=digest(paths['plan'])
        (folder/'result.json').write_text(json.dumps(result))
        (folder/'manifest.json').write_text(json.dumps({'artifacts':{n:digest(folder/n)
            for n in ('selected.sam.gz','result.json','alignment.log')}}))
        journal=json.loads(paths['journal'].read_text());journal[0]['manifest_sha256']=digest(folder/'manifest.json')
        for name in ('journal','snv_snapshot','indel_snapshot'):paths[name].write_text(json.dumps(journal))
        complete=dict(journal_sha256=digest(paths['journal']),total_pairs=10,chunks=1)
        paths['complete'].write_text(json.dumps(complete))
        # Use the real reference extractor, chunk verifier and assessment functions.
        guard=lambda:None
        folders,pairs=indel.verified_folders(journal,plan,digest(paths['plan']),root,guard)
        sites={k:snv.new_site() for k in keys}
        for chunk in folders:
            with gzip.open(chunk/'selected.sam.gz','rt') as handle:snv.scan(handle,keys,sites,guard)
        snv_rows=[dict(key=list(k),**snv.summarize(k,sites[k])) for k in keys]
        contexts=indel.reference_contexts(fixture.reference,keys[1:],plan['reference'],guard)
        indel_rows,targets=indel.inventory(keys[1:],contexts,plan['windows'])
        evidence=indel.evaluate(folders,targets,guard)
        for row in indel_rows:row['evidence']=evidence.get(row['ordinal'],{'status':'UNASSESSED'})
        common=dict(captured_journal_sha256=digest(paths['journal']),summary=dict(snapshot_pairs=pairs,snapshot_chunks=len(folders)))
        paths['snv'].write_text(json.dumps(dict(**common,plan_sha256=digest(paths['plan']),scope_sha256=digest(paths['scope']),sites=snv_rows)))
        paths['indel'].write_text(json.dumps(dict(**common,pins={'plan.json':digest(paths['plan']),'scope-contract.json':digest(paths['scope'])},sites=indel_rows)))
        for n,p in paths.items():fixture.spec['inputs'][n]['sha256']=digest(p)
        for n in fixture.spec['chunks'][0]:fixture.spec['chunks'][0][n]['sha256']=digest(folder/n)
        fixture.save()
        code=root/'relocated';code.mkdir();source=Path(__file__).resolve().parents[1]
        for item in closure(source,('export_read_assessment',)).values():
            dest=code/item['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/item['path'],dest)
        (code/'scripts/__init__.py').touch()
        bootstrap="import runpy,sys;sys.path.insert(0,sys.argv.pop(1));sys.argv[0]='scripts.export_read_evidence';runpy.run_module('scripts.export_read_evidence',run_name='__main__')"
        env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','MVA_RANK_PROGRESS')}
        p=subprocess.run([sys.executable,'-I','-B','-c',bootstrap,str(code),'--contract',str(fixture.contract),'--output',str(fixture.output)],
            cwd=code,env=env,capture_output=True,text=True,timeout=30)
        self.assertEqual(p.returncode,0,p.stderr)
        merged=json.loads((fixture.output/'result.json').read_text())
        self.assertEqual([r['combined_status'] for r in merged['sites']],
            ['ALT_OBSERVED_PROVISIONAL']*3+['NO_INFORMATIVE_OBSERVATION','UNASSESSED_REPEAT_OR_UNSUPPORTED'])
        # Duplicate names are not independent molecules; two ALT records become one name.
        self.assertEqual(sites[keys[0]]['observations']['ALT'],2)
        self.assertEqual(len(sites[keys[0]]['fragments']),2)
        self.assertEqual(sites[keys[0]]['filtered_baseq'],1)
        self.assertEqual(sites[keys[0]]['filtered_mapq'],1)
        for row in merged['sites'][1:3]:
            self.assertEqual(row['indel_review']['evidence']['fragment_name_counts'],{'ALT':1,'REF':1})
        self.assertFalse(merged['summary']['phase_established'])
        self.assertFalse(merged['summary']['old_counts_pooled'])
        # Consolidator truthfully remains a consumer even though this test generated its inputs.
        self.assertFalse(json.loads((fixture.output/'manifest.json').read_text())['assessment_recomputed'])
        # Same assessment path under explicit v2 reference budgeting, not just a unit helper.
        fixture.spec.update(schema='mva-read-evidence-export-v2',reference_budget={
            'max_bytes':4096,'expected_bytes':fixture.reference.stat().st_size})
        fixture.save();scaled_output=root/'scaled-output'
        p=subprocess.run([sys.executable,'-I','-B','-c',bootstrap,str(code),'--contract',str(fixture.contract),'--output',str(scaled_output)],
            cwd=code,env=env,capture_output=True,text=True,timeout=30)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertEqual(json.loads((scaled_output/'result.json').read_text()),merged)
        self.assertEqual(json.loads((scaled_output/'manifest.json').read_text())['separately_verified_reference_bytes'],fixture.reference.stat().st_size)
        # A real standalone CLI now regenerates both reports; no supplied assessments.
        fixture.spec.update(schema='mva-read-assessment-export-v1',targets=[list(k) for k in keys],
            assessment_sources={n:digest(Path(m.__file__)) for n,m in METHODS.items()})
        for name in ('snv','indel','snv_snapshot','indel_snapshot'):del fixture.spec['inputs'][name]
        fixture.save()
        assessment_bootstrap=bootstrap.replace('scripts.export_read_evidence','scripts.export_read_assessment')
        def execute(out):
            return subprocess.run([sys.executable,'-I','-B','-c',assessment_bootstrap,str(code),
                '--contract',str(fixture.contract),'--output',str(out)],cwd=code,env=env,
                capture_output=True,text=True,timeout=30)
        generated=root/'generated-assessments';p=execute(generated)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertEqual(json.loads((generated/'result.json').read_text()),merged)
        self.assertTrue(json.loads((generated/'manifest.json').read_text())['assessment_recomputed'])
        self.assertFalse((generated/'INCOMPLETE').exists())
        self.assertNotEqual(execute(generated).returncode,0)
        for field,value in [('targets',[list(keys[0])]),('assessment_sources',{n:'0'*64 for n in METHODS})]:
            previous=fixture.spec[field];fixture.spec[field]=value;fixture.save()
            failed=root/('reject-'+field);p=execute(failed)
            self.assertNotEqual(p.returncode,0)
            self.assertFalse(failed.exists())
            fixture.spec[field]=previous
        fixture.save()
        (folder/'alignment.log').write_text('synthetic drift')
        self.assertNotEqual(execute(root/'reject-drift').returncode,0)
