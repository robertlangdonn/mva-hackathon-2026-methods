import hashlib
from pathlib import Path
import tempfile
import unittest
from scripts.export_reference import streaming_digest
from scripts.export_read_evidence import verify
from tests import test_export_read_evidence as fixtures


class ReferenceTests(unittest.TestCase):
    def test_streaming_matches_independent_digest(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'invented.fa';raw=b'>toy\n'+b'ACGT'*600000+b'\n';p.write_bytes(raw)
            self.assertEqual(streaming_digest(p,byte_limit=len(raw),expected_bytes=len(raw)),hashlib.sha256(raw).hexdigest())

    def test_budget_size_and_timeout(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'toy';p.write_bytes(b'ACGT')
            for args in ({'byte_limit':3},{'byte_limit':10,'expected_bytes':5},{'byte_limit':10,'seconds':-1}):
                with self.subTest(args=args),self.assertRaises(ValueError):streaming_digest(p,**args)

    def test_v2_explicit_budget(self):
        f=fixtures.ReadExportTests();f.setUp();self.addCleanup(f.doCleanups)
        f.spec.update(schema='mva-read-evidence-export-v2',reference_budget={'max_bytes':100,'expected_bytes':f.reference.stat().st_size});f.save()
        _,_,pins,_,_=verify(f.contract,f.output)
        self.assertEqual(pins.reference_limits[0],f.reference)
        f.reference.write_text('changed')
        with self.assertRaises(ValueError):pins.check()

    def test_v2_requires_budget(self):
        f=fixtures.ReadExportTests();f.setUp();self.addCleanup(f.doCleanups)
        f.spec['schema']='mva-read-evidence-export-v2';f.save()
        with self.assertRaises(ValueError):verify(f.contract,f.output)

    def test_v1_does_not_accept_increased_budget(self):
        f=fixtures.ReadExportTests();f.setUp();self.addCleanup(f.doCleanups)
        f.spec['reference_budget']={'max_bytes':100,'expected_bytes':12};f.save()
        with self.assertRaises(ValueError):verify(f.contract,f.output)
