import gzip
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from scripts.export_read_evidence import digest,verify
from scripts import consolidate_read_snapshot
from scripts.inventory_release_dependencies import closure


class ReadExportTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name).resolve();self.output=self.root/'output'
        self.paths={}
        def put(name,value):
            p=self.root/(name+'.json');p.write_text(json.dumps(value));self.paths[name]=p;return p
        self.reference=self.root/'reference.fa';self.reference.write_text('>1\nACGTACGT\n')
        put('plan',{'reference':digest(self.reference),'total_pairs':10,'windows':[['1',1,8]]})
        put('scope',{'required_sites':[['1',2,'C','T']]})
        self.folder=self.root/'chunk-000000-1';self.folder.mkdir()
        (self.folder/'selected.sam.gz').write_bytes(gzip.compress(b'@HD\tVN:1.6\n',mtime=0))
        (self.folder/'alignment.log').write_text('invented alignment log\n')
        result=dict(start_pairs=0,end_pairs=10,offsets=[100,100],plan_sha256=digest(self.paths['plan']))
        (self.folder/'result.json').write_text(json.dumps(result))
        (self.folder/'manifest.json').write_text(json.dumps({'artifacts':{n:digest(self.folder/n)
            for n in ('selected.sam.gz','alignment.log','result.json')}}))
        journal=[dict(start_pairs=0,end_pairs=10,offsets=[100,100],folder=self.folder.name,
            manifest_sha256=digest(self.folder/'manifest.json'))]
        put('journal',journal);put('snv_snapshot',journal);put('indel_snapshot',journal)
        put('complete',dict(journal_sha256=digest(self.paths['journal']),chunks=1,total_pairs=10))
        common=dict(captured_journal_sha256=digest(self.paths['journal']),summary=dict(snapshot_pairs=10,snapshot_chunks=1))
        put('snv',dict(**common,plan_sha256=digest(self.paths['plan']),scope_sha256=digest(self.paths['scope']),sites=[
            dict(key=['1',2,'C','T'],status='ALT_OBSERVED_PROVISIONAL'),
            dict(key=['1',3,'G','GA'],status='UNASSESSED_NON_SNV')]))
        put('indel',dict(**common,pins={'plan.json':digest(self.paths['plan']),'scope-contract.json':digest(self.paths['scope'])},
            sites=[dict(key=['1',3,'G','GA'],eligibility='READY',evidence={'fragment_name_counts':{'REF':2}})]))
        self.paths['reference']=self.reference
        pin=lambda p:dict(path=str(p),sha256=digest(p))
        self.spec=dict(schema='mva-read-evidence-export-v1',controlled_root=str(self.root),
            inputs={n:pin(p) for n,p in self.paths.items()},
            chunks=[{n:pin(self.folder/n) for n in ('manifest.json','result.json','selected.sam.gz','alignment.log')}],
            merge_source_sha256=digest(Path(consolidate_read_snapshot.__file__)))
        self.contract=self.root/'contract.json';self.save()

    def save(self):self.contract.write_text(json.dumps(self.spec))

    def change(self,name,fn):
        p=self.paths[name];data=json.loads(p.read_text());fn(data);p.write_text(json.dumps(data))
        self.spec['inputs'][name]['sha256']=digest(p);self.save()

    def test_real_cli_after_relocation(self):
        code=self.root/'code';code.mkdir()
        source=Path(__file__).resolve().parents[1]
        for item in closure(source,('export_read_evidence',)).values():
            dest=code/item['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/item['path'],dest)
        (code/'scripts/__init__.py').touch()
        bootstrap="import runpy,sys;sys.path.insert(0,sys.argv.pop(1));sys.argv[0]='scripts.export_read_evidence';runpy.run_module('scripts.export_read_evidence',run_name='__main__')"
        env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','MVA_RANK_PROGRESS')}
        p=subprocess.run([sys.executable,'-I','-B','-c',bootstrap,str(code),'--contract',str(self.contract),'--output',str(self.output)],
            cwd=code,env=env,capture_output=True,text=True,timeout=30)
        self.assertEqual(p.returncode,0,p.stderr)
        result=json.loads((self.output/'result.json').read_text())
        self.assertEqual(result['summary']['site_statuses'],{'ALT_OBSERVED_PROVISIONAL':1,'REF_ONLY_IN_SNAPSHOT':1})
        self.assertEqual(result['sites'][1]['indel_review']['evidence']['fragment_name_counts'],{'REF':2})
        self.assertFalse(result['summary']['phase_established'])
        self.assertFalse((self.output/'INCOMPLETE').exists())
        with self.assertRaises(ValueError):verify(self.contract,self.output)

    def test_retained_tamper_rejected(self):
        (self.folder/'selected.sam.gz').write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'hash mismatch'):verify(self.contract,self.output)
        self.assertFalse(self.output.exists())

    def test_incomplete_rejected(self):
        (self.folder/'INCOMPLETE').touch()
        with self.assertRaisesRegex(ValueError,'incomplete'):verify(self.contract,self.output)

    def test_snapshot_mismatch(self):
        self.change('indel_snapshot',lambda d:d.clear())
        with self.assertRaisesRegex(ValueError,'snapshot mismatch'):verify(self.contract,self.output)

    def test_report_lineage_mismatch(self):
        self.change('snv',lambda d:d.update(plan_sha256='0'*64))
        with self.assertRaisesRegex(ValueError,'lineage mismatch'):verify(self.contract,self.output)

    def test_missing_and_duplicate_indel_rejected(self):
        for sites in ([],json.loads(self.paths['indel'].read_text())['sites']*2):
            self.change('indel',lambda d:d.update(sites=sites))
            with self.assertRaises((ValueError,KeyError)):verify(self.contract,self.output)

    def test_unsupported_preserved(self):
        self.change('indel',lambda d:d['sites'][0].update(eligibility='REPEAT_SHIFT_AMBIGUITY'))
        _,rows,_,_,_=verify(self.contract,self.output)
        self.assertEqual(rows[1]['combined_status'],'UNASSESSED_REPEAT_OR_UNSUPPORTED')

    def test_outside_output_rejected(self):
        with self.assertRaisesRegex(ValueError,'controlled output'):verify(self.contract,self.root.parent/'not-allowed')

    def test_scope_omission_rejected(self):
        self.change('scope',lambda d:d.update(required_sites=[['1',7,'G','T']]))
        self.change('snv',lambda d:d.update(scope_sha256=digest(self.paths['scope'])))
        with self.assertRaisesRegex(ValueError,'required scope'):verify(self.contract,self.output)

    def test_completion_mismatch(self):
        self.change('complete',lambda d:d.update(total_pairs=11))
        with self.assertRaisesRegex(ValueError,'pair census'):verify(self.contract,self.output)

    def test_merge_source_drift(self):
        self.spec['merge_source_sha256']='0'*64;self.save()
        with self.assertRaisesRegex(ValueError,'implementation drift'):verify(self.contract,self.output)

    def test_budget_rejected_before_hashing_large_file(self):
        with self.reference.open('r+b') as handle:handle.truncate(101*1024**2)
        with self.assertRaisesRegex(ValueError,'budget'):verify(self.contract,self.output)

    def test_missing_retained_artifact_pin(self):
        del self.spec['chunks'][0]['selected.sam.gz'];self.save()
        with self.assertRaisesRegex(ValueError,'artifact set'):verify(self.contract,self.output)
