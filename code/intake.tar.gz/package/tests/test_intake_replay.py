"""Relocated real intake CLIs on invented VCF and minimal Word XML fixtures."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile
from xml.etree import ElementTree as ET
from tests.test_intake import vcf_text


class IntakeReplayTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)/'relocated';self.root.mkdir()
        (self.root/'scripts').mkdir()
        source=Path(__file__).resolve().parents[1]
        for name in ('intake.py','phenotype_intake.py'):
            shutil.copyfile(source/'scripts'/name,self.root/'scripts'/name)
        self.raw=self.root/'data/raw';self.raw.mkdir(parents=True)
        self.out=self.root/'data/intermediate';self.out.mkdir()
        self.vcf=self.raw/'invented.vcf'
        self.vcf.write_text(vcf_text(reference='GRCh38',chr1_length=248956422))
        self.doc=self.raw/'invented.docx';self.document()

    def document(self,hpo='HP:0000001'):
        ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
        root=ET.Element('{'+ns+'}document');body=ET.SubElement(root,'{'+ns+'}body')
        table=ET.SubElement(body,'{'+ns+'}tbl')
        for values in (['Clinical feature','HPO term','HPO ID','Presentation / notes'],
                       ['Invented fixture','All',hpo,'Not a patient observation']):
            row=ET.SubElement(table,'{'+ns+'}tr')
            for value in values:
                cell=ET.SubElement(row,'{'+ns+'}tc');p=ET.SubElement(cell,'{'+ns+'}p')
                run=ET.SubElement(p,'{'+ns+'}r');ET.SubElement(run,'{'+ns+'}t').text=value
        with zipfile.ZipFile(self.doc,'w') as archive:
            archive.writestr('word/document.xml',ET.tostring(root))

    def cli(self,name,*args):
        env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME')}
        env['PATH']=''  # Explicit missing-tool branch, no host binary probing.
        return subprocess.run([sys.executable,'-B',str(self.root/'scripts'/name),*map(str,args)],
            cwd=self.temp.name,env=env,capture_output=True,text=True,timeout=20)

    def intake(self,*args):
        return self.cli('intake.py','--vcf',self.vcf,'--phenotype',self.doc,*args)

    def test_real_clis_relocate_and_pin_sources(self):
        p=self.intake();self.assertEqual(p.returncode,0,p.stderr)
        manifest=json.loads((self.out/'intake_manifest.json').read_text())
        self.assertEqual(manifest['vcf_header_audit']['reference_inference']['build'],'GRCh38')
        self.assertTrue(all(not v['available'] for v in manifest['tools'].values()))
        self.assertFalse(manifest['shareable'])
        for row in manifest['files']:
            self.assertEqual(row['sha256'],hashlib.sha256((self.raw/row['name']).read_bytes()).hexdigest())
        p=self.cli('phenotype_intake.py','--phenotype',self.doc)
        self.assertEqual(p.returncode,0,p.stderr)
        phenotype=json.loads((self.out/'phenotype.json').read_text())
        self.assertEqual(phenotype['hpo_term_count'],1)
        self.assertEqual(phenotype['source']['sha256'],hashlib.sha256(self.doc.read_bytes()).hexdigest())
        self.assertNotIn('SAMPLE_NAME',p.stdout)

    def test_path_boundaries(self):
        outside=Path(self.temp.name)/'outside.vcf';shutil.copyfile(self.vcf,outside)
        p=self.cli('intake.py','--vcf',outside,'--phenotype',self.doc)
        self.assertNotEqual(p.returncode,0)
        for name,args in [('intake.py',['--vcf',self.vcf,'--phenotype',self.doc]),
                          ('phenotype_intake.py',['--phenotype',self.doc])]:
            destination=Path(self.temp.name)/'outside.json'
            self.assertNotEqual(self.cli(name,*args,'--output',destination).returncode,0)
            self.assertFalse(destination.exists())

    def test_conflicting_build_is_not_success(self):
        self.vcf.write_text(vcf_text(reference='GRCh38',chr1_length=249250621))
        self.assertEqual(self.intake().returncode,2)
        r=json.loads((self.out/'intake_manifest.json').read_text())
        self.assertEqual(r['vcf_header_audit']['reference_inference']['status'],'conflict')

    def test_invalid_hpo_is_rejected(self):
        self.document('invalid-synthetic-id')
        p=self.cli('phenotype_intake.py','--phenotype',self.doc)
        self.assertNotEqual(p.returncode,0)
        self.assertFalse((self.out/'phenotype.json').exists())
