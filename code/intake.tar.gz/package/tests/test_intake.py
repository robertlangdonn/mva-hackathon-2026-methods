from __future__ import annotations

import gzip
import importlib.util
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "intake.py"
SPEC = importlib.util.spec_from_file_location("intake", SCRIPT)
assert SPEC and SPEC.loader
intake = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(intake)


def vcf_text(*, reference: str, chr1_length: int) -> str:
    return "\n".join(
        [
            "##fileformat=VCFv4.2",
            f"##reference={reference}",
            f"##contig=<ID=chr1,length={chr1_length}>",
            '##INFO=<ID=AF,Number=A,Type=Float,Description="Allele frequency">',
            '##FORMAT=<ID=GT,Number=1,Type=String,Description="Genotype">',
            '##FILTER=<ID=PASS,Description="All filters passed">',
            '##GATKCommandLine=<ID=HaplotypeCaller,CommandLine="redacted",Version="4.2.4.0",Date="test">',
            "##source=HaplotypeCaller",
            "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tSAMPLE_NAME",
            "chr1\t100\t.\tA\tG\t50\tPASS\tAF=0.1\tGT\t0/1",
            "",
        ]
    )


class HeaderAuditTests(unittest.TestCase):
    def test_grch38_plain_vcf(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sample.vcf"
            path.write_text(
                vcf_text(reference="GRCh38", chr1_length=intake.GRCH38_CHR1_LENGTH)
            )
            audit = intake.audit_vcf_header(path)
        self.assertEqual(audit["reference_inference"]["build"], "GRCh38")
        self.assertEqual(audit["sample_count"], 1)
        self.assertEqual(audit["info_ids"], ["AF"])
        self.assertEqual(audit["format_ids"], ["GT"])
        self.assertEqual(audit["source_ids"], ["HaplotypeCaller"])
        self.assertEqual(
            audit["callers"], [{"id": "HaplotypeCaller", "version": "4.2.4.0"}]
        )

    def test_grch37_bgzf_compatible_gzip(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sample.vcf.gz"
            with gzip.open(path, "wt") as handle:
                handle.write(
                    vcf_text(reference="hg19", chr1_length=intake.GRCH37_CHR1_LENGTH)
                )
            audit = intake.audit_vcf_header(path)
        self.assertEqual(audit["reference_inference"]["build"], "GRCh37")

    def test_chr22_only_vcf_with_extra_contig_metadata(self) -> None:
        text = "\n".join(
            [
                "##fileformat=VCFv4.2",
                "##contig=<ID=chr22,assembly=b37,length=51304566>",
                "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO",
                "chr22\t100\t.\tA\tG\t50\tPASS\t.",
                "",
            ]
        )
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "chr22.vcf"
            path.write_text(text)
            audit = intake.audit_vcf_header(path)
        self.assertEqual(audit["reference_inference"]["build"], "GRCh37")
        self.assertIn("chr22_length=51304566", audit["reference_inference"]["evidence"])

    def test_conflicting_reference_evidence_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sample.vcf"
            path.write_text(
                vcf_text(reference="GRCh38", chr1_length=intake.GRCH37_CHR1_LENGTH)
            )
            audit = intake.audit_vcf_header(path)
        self.assertEqual(audit["reference_inference"]["status"], "conflict")
        self.assertIsNone(audit["reference_inference"]["build"])

    def test_missing_column_header_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.vcf"
            path.write_text("##fileformat=VCFv4.2\nchr1\t100\t.\tA\tG\n")
            with self.assertRaisesRegex(ValueError, "#CHROM"):
                intake.audit_vcf_header(path)


if __name__ == "__main__":
    unittest.main()
