# Private intake CLI demonstration

Run python3 -I -B verify_and_test.py from a clean extracted directory.
Python >=3.11 is required by the package verifier; no third-party Python modules.
Nine tests exercise header inference and two unchanged intake CLIs after copying
them into a fresh temporary workspace. Invented VCF and minimal Word XML archive
fixtures are created there, never drawn from patient data. The Word fixture tests
the table extractor, not complete Word rendering or arbitrary document support.

Use script-file invocation, not module mode:
python3 scripts/intake.py --vcf <root>/data/raw/source.vcf --phenotype <root>/data/raw/source.docx --output <root>/data/intermediate/intake.json
python3 scripts/phenotype_intake.py --phenotype <root>/data/raw/source.docx --output <root>/data/intermediate/phenotype.json
Root is the directory containing scripts. These paths and outputs are controlled.
The phenotype CLI has a direct-script intake import; module mode is not supported.

Limitations: header inference is not whole-reference validation. Intake records
source hashes but does not validate VCF body/index correspondence or make an input
immutable. Existing output files may be replaced by these historical CLIs: use
fresh outputs. Build conflict writes an audit manifest and exits 2; never consume
it as a successful intake. No downstream stage is automatically started.
Missing tools are deliberately exercised with empty PATH; available-tool version
probing is not covered here. The shared packager separately records samtools and
bcftools versions; binaries and resources are not bundled. The ranking policy
file is included by the shared builder, not used by these tests.

Public resource acquisition, ontology validity, real clinical extraction, ranking,
alignment and submission are outside this package. No downloads or patient reads.
PRIVATE REVIEW ONLY; no privacy/license clearance or publication approval.
