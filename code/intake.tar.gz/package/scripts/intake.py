#!/usr/bin/env python3
"""Create a privacy-safe local intake manifest for controlled challenge files."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import BinaryIO, TextIO


ROOT = Path(__file__).resolve().parents[1]
RAW_DIR = (ROOT / "data" / "raw").resolve()
INTERMEDIATE_DIR = (ROOT / "data" / "intermediate").resolve()
GRCH37_CONTIG_LENGTHS = {"1": 249_250_621, "22": 51_304_566}
GRCH38_CONTIG_LENGTHS = {"1": 248_956_422, "22": 50_818_468}
GRCH37_CHR1_LENGTH = GRCH37_CONTIG_LENGTHS["1"]
GRCH38_CHR1_LENGTH = GRCH38_CONTIG_LENGTHS["1"]
META_ID = re.compile(r"^##(?P<kind>INFO|FORMAT|FILTER)=<ID=(?P<id>[^,>]+)")
CONTIG = re.compile(r"^##contig=<(?P<body>.*)>$")
CONTIG_ID = re.compile(r"(?:^|,)ID=(?P<id>[^,>]+)")
CONTIG_LENGTH = re.compile(r"(?:^|,)length=(?P<length>\d+)(?:,|$)")
GATK_COMMAND = re.compile(
    r'^##GATKCommandLine=<ID=(?P<id>[^,>]+).*?,Version="(?P<version>[^"]+)"'
)


def within(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent)
        return True
    except ValueError:
        return False


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def is_gzip(path: Path) -> bool:
    with path.open("rb") as handle:
        return handle.read(2) == b"\x1f\x8b"


def open_vcf_text(path: Path) -> TextIO:
    if is_gzip(path):
        return gzip.open(path, mode="rt", encoding="utf-8", errors="strict")
    return path.open(mode="rt", encoding="utf-8", errors="strict")


def infer_reference(reference: str | None, contigs: dict[str, int | None]) -> dict[str, object]:
    evidence: list[str] = []
    candidates: set[str] = set()
    reference_lower = (reference or "").lower()

    if any(token in reference_lower for token in ("grch38", "hg38", "b38")):
        candidates.add("GRCh38")
        evidence.append(f"reference={reference}")
    if any(token in reference_lower for token in ("grch37", "hg19", "b37")):
        candidates.add("GRCh37")
        evidence.append(f"reference={reference}")

    for raw_name, observed_length in contigs.items():
        canonical_name = raw_name.removeprefix("chr")
        if observed_length == GRCH38_CONTIG_LENGTHS.get(canonical_name):
            candidates.add("GRCh38")
            evidence.append(f"{raw_name}_length={observed_length}")
        elif observed_length == GRCH37_CONTIG_LENGTHS.get(canonical_name):
            candidates.add("GRCh37")
            evidence.append(f"{raw_name}_length={observed_length}")

    if len(candidates) == 1:
        status = "identified"
        build = next(iter(candidates))
    elif len(candidates) > 1:
        status = "conflict"
        build = None
    else:
        status = "unknown"
        build = None

    return {"status": status, "build": build, "evidence": evidence}


def audit_vcf_header(path: Path) -> dict[str, object]:
    fileformat: str | None = None
    reference: str | None = None
    contigs: dict[str, int | None] = {}
    metadata: dict[str, list[str]] = {"INFO": [], "FORMAT": [], "FILTER": []}
    source_ids: list[str] = []
    callers: list[dict[str, str]] = []
    sample_count: int | None = None
    saw_header = False

    with open_vcf_text(path) as handle:
        for line in handle:
            line = line.rstrip("\r\n")
            if line.startswith("##fileformat="):
                fileformat = line.partition("=")[2]
            elif line.startswith("##reference="):
                reference = line.partition("=")[2]
            elif line.startswith("##source="):
                source_ids.append(line.partition("=")[2])
            else:
                gatk_match = GATK_COMMAND.match(line)
                if gatk_match:
                    callers.append(gatk_match.groupdict())
                contig_match = CONTIG.match(line)
                if contig_match:
                    body = contig_match.group("body")
                    id_match = CONTIG_ID.search(body)
                    length_match = CONTIG_LENGTH.search(body)
                    if id_match:
                        contigs[id_match.group("id")] = (
                            int(length_match.group("length")) if length_match else None
                        )
                meta_match = META_ID.match(line)
                if meta_match:
                    metadata[meta_match.group("kind")].append(meta_match.group("id"))

            if line.startswith("#CHROM\t"):
                columns = line.split("\t")
                sample_count = max(0, len(columns) - 9)
                saw_header = True
                break
            if not line.startswith("#"):
                break

    if not saw_header:
        raise ValueError("VCF column header (#CHROM) was not found before the first record")

    return {
        "fileformat": fileformat,
        "reference_declared": reference,
        "reference_inference": infer_reference(reference, contigs),
        "source_ids": sorted(set(source_ids)),
        "callers": callers,
        "contig_count": len(contigs),
        "contig_naming": (
            "chr-prefixed" if any(name.startswith("chr") for name in contigs) else "unprefixed"
        ),
        "sample_count": sample_count,
        "info_ids": sorted(set(metadata["INFO"])),
        "format_ids": sorted(set(metadata["FORMAT"])),
        "filter_ids": sorted(set(metadata["FILTER"])),
    }


def tool_record(name: str) -> dict[str, object]:
    executable = shutil.which(name)
    if not executable:
        return {"available": False}
    path = Path(executable).resolve()
    result = subprocess.run(
        [str(path), "--version"], check=True, capture_output=True, text=True
    )
    first_line = (result.stdout or result.stderr).splitlines()[0]
    return {
        "available": True,
        "path": str(path),
        "version": first_line,
        "sha256": sha256_file(path),
    }


def file_record(path: Path, role: str) -> dict[str, object]:
    stat = path.stat()
    return {
        "role": role,
        "name": path.name,
        "size_bytes": stat.st_size,
        "sha256": sha256_file(path),
    }


def write_json_atomic(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
        Path(temporary).replace(path)
    except BaseException:
        Path(temporary).unlink(missing_ok=True)
        raise


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--vcf", type=Path, required=True)
    parser.add_argument("--index", type=Path)
    parser.add_argument("--phenotype", type=Path, required=True)
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "data" / "intermediate" / "intake_manifest.json",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    inputs = [args.vcf, args.phenotype] + ([args.index] if args.index else [])
    for path in inputs:
        resolved = path.resolve()
        if not within(resolved, RAW_DIR):
            raise SystemExit(f"controlled input must be inside {RAW_DIR}: {resolved}")
        if not resolved.is_file():
            raise SystemExit(f"input file not found: {resolved}")

    output = args.output.resolve()
    if not within(output, INTERMEDIATE_DIR):
        raise SystemExit(f"manifest output must be inside {INTERMEDIATE_DIR}: {output}")

    header = audit_vcf_header(args.vcf.resolve())
    payload: dict[str, object] = {
        "schema_version": 1,
        "controlled": True,
        "shareable": False,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "files": [
            file_record(args.vcf.resolve(), "source_vcf"),
            *(
                [file_record(args.index.resolve(), "source_vcf_index")]
                if args.index
                else []
            ),
            file_record(args.phenotype.resolve(), "source_phenotype"),
        ],
        "vcf_header_audit": header,
        "tools": {name: tool_record(name) for name in ("vcfkit", "bcftools", "samtools")},
    }
    write_json_atomic(output, payload)

    inference = header["reference_inference"]
    assert isinstance(inference, dict)
    print(f"manifest={output}")
    print(f"reference_status={inference['status']}")
    print(f"reference_build={inference['build'] or 'unknown'}")
    print(f"sample_count={header['sample_count']}")
    print(f"info_fields={len(header['info_ids'])}")
    print(f"format_fields={len(header['format_ids'])}")
    return 0 if inference["status"] == "identified" else 2


if __name__ == "__main__":
    raise SystemExit(main())
