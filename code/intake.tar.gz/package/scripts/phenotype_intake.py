#!/usr/bin/env python3
"""Extract an organizer-provided HPO table into ignored controlled JSON."""

from __future__ import annotations

import argparse
import json
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree

from intake import INTERMEDIATE_DIR, RAW_DIR, sha256_file, within, write_json_atomic


WORD_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
HPO_ID = re.compile(r"^HP:\d{7}$")


def cell_text(cell: ElementTree.Element) -> str:
    chunks = [node.text or "" for node in cell.iter(f"{{{WORD_NS}}}t")]
    return "".join(chunks).strip()


def extract_hpo_rows(path: Path) -> list[dict[str, str]]:
    with zipfile.ZipFile(path) as archive:
        root = ElementTree.fromstring(archive.read("word/document.xml"))

    for table in root.iter(f"{{{WORD_NS}}}tbl"):
        rows = [
            [cell_text(cell) for cell in row.findall(f"{{{WORD_NS}}}tc")]
            for row in table.findall(f"{{{WORD_NS}}}tr")
        ]
        if not rows:
            continue
        headers = [value.casefold() for value in rows[0]]
        if "hpo id" not in headers:
            continue
        required = ["clinical feature", "hpo term", "hpo id", "presentation / notes"]
        if any(name not in headers for name in required):
            raise ValueError("phenotype table is missing one or more required columns")
        positions = {name: headers.index(name) for name in required}
        extracted: list[dict[str, str]] = []
        for row in rows[1:]:
            if len(row) <= max(positions.values()):
                raise ValueError("phenotype table contains a short row")
            hpo_id = row[positions["hpo id"]].strip()
            if not HPO_ID.fullmatch(hpo_id):
                raise ValueError(f"invalid HPO identifier in phenotype table: {hpo_id!r}")
            extracted.append(
                {
                    "clinical_feature": row[positions["clinical feature"]],
                    "hpo_term": row[positions["hpo term"]],
                    "hpo_id": hpo_id,
                    "presentation_notes": row[positions["presentation / notes"]],
                }
            )
        if not extracted:
            raise ValueError("phenotype table contains no HPO rows")
        return extracted
    raise ValueError("no table with an HPO ID column was found")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phenotype", type=Path, required=True)
    parser.add_argument(
        "--output",
        type=Path,
        default=INTERMEDIATE_DIR / "phenotype.json",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    source = args.phenotype.resolve()
    output = args.output.resolve()
    if not within(source, RAW_DIR) or not source.is_file():
        raise SystemExit(f"phenotype input must be a file inside {RAW_DIR}: {source}")
    if not within(output, INTERMEDIATE_DIR):
        raise SystemExit(f"phenotype output must be inside {INTERMEDIATE_DIR}: {output}")

    rows = extract_hpo_rows(source)
    write_json_atomic(
        output,
        {
            "schema_version": 1,
            "controlled": True,
            "shareable": False,
            "source": {"name": source.name, "sha256": sha256_file(source)},
            "hpo_term_count": len(rows),
            "phenotypes": rows,
        },
    )
    print(f"phenotype_manifest={output}")
    print(f"hpo_term_count={len(rows)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
